# ETERNAL — correções (crash, identidade visual, ABI)

## Estado de verificação (leia primeiro)
Nada aqui foi compilado nem rodado em aparelho: o ambiente onde estas mudanças foram feitas não tem Android SDK, Gradle
nem acesso à rede. O **stack trace do PASSO 1 não foi capturado** (não há `adb` nem aparelho); por isso a causa raiz abaixo
é **hipótese**, não confirmação. O app agora se auto-diagnostica (ver "Diagnóstico sem adb").

## Crash ao pesquisar
Revisão do código real (que difere do roteiro: ids são `urlInput`/`tabsButton`, não `urlBar`; já havia `TabManager`):
- `loadUri` era chamado direto do callback do teclado, sem checar sessão aberta, e o `clearFocus()` disparava `setText` dentro do IME.
  → agora `MainActivity.navigate()` → `TabManager.load()`: main thread garantida, reabre a sessão se fechada, tudo em try/catch,
  `clearFocus/hideKeyboard` adiados com `post`.
- Processo de conteúdo do Gecko que morre ao carregar uma página real (`onCrash`/`onKill` não tratados) deixava a aba inutilizável.
  → `TabManager.recover()` fecha, reabre e recarrega a sessão.
- `GeckoRuntime.create` falhando derrubava o app em `lateinit`. → `EternalApplication.isReady()`; a Activity avisa em vez de crashar.
- Extensão do modo noturno rodava em `<all_urls>` com `document_start`; agora só `http(s)` e à prova de exceção.
- Manifest: `largeHeap="true"`, `launchMode="singleTop"` (evita recriação). `hardwareAccelerated` e `configChanges` já estavam corretos.
- `extractNativeLibs` **não** foi posto no manifest: `packaging.jniLibs.useLegacyPackaging = true` já faz o AGP gerar `extractNativeLibs=true`
  (declarar nos dois lugares gera erro/aviso no AGP 9). `usesCleartextTraffic` também não: não afeta o Gecko, que faz a própria rede.

### Diagnóstico sem adb
- Exceção Java não tratada → `CrashReporter` grava o stack trace e o app o mostra (com botão Copiar) na próxima abertura.
- Morte nativa (Gecko) → `Prefs.navBreadcrumb` guarda o endereço que estava carregando; na próxima abertura o app informa.
- Se ainda assim cair: `adb logcat -c && adb logcat | grep -iE "eternal|gecko|AndroidRuntime|FATAL"` e envie a saída.

## Visual
- Paleta só preto/branco/cinzas (`colors.xml`; nomes antigos mantidos, valores neutros). Sem ciano/roxo/rosa, sem gradiente neon.
- Barra: campo de URL com cantos 8dp e borda cinza (sem pílula); ícones outline com traço 2dp; abas com cantos 8dp.
- Splash: "E" desenhado em branco sobre preto, 800 ms. Ícone do launcher (adaptativo + monocromático): "E" branco sobre preto.
- Página inicial = dashboard em grade 2 colunas com cartões `#141414`, cantos 16dp. Cartões: Pesquisar, Nova aba, Abas, Downloads,
  Extensões, Importar extensão (.xpi), Configurações. Os links `eternal://…` só funcionam a partir da página inicial.
- **Favoritos e Histórico não existem no app**, então não ganharam cartão (seriam botões mortos). Implementá-los é trabalho à parte.
- Fonte: Roboto do sistema (`sans-serif`). Não foi baixada fonte para `res/font/` (sem rede).
- Restam menções a "Firefox/Mozilla" apenas no texto legal de "Sobre" (exigência da MPL 2.0).

## ABI
Estratégia **E**: 3 APKs — `arm64-v8a`, `armeabi-v7a` e `universal` (arm64 + arm32). Motivo: um APK pequeno por aparelho moderno/antigo
e um universal de reserva, sem `abiFilters` (que conflitaria com `splits`). `x86_64` foi removido (só emulador).
Para um único arquivo, deixe só o `universal`; para forçar uma ABI, ajuste `include(...)` em `app/build.gradle.kts`.
Checar no aparelho: `adb shell dumpsys package com.eternal.browser | grep primaryCpuAbi`.

## Para compilar e validar
`./gradlew clean assembleRelease` (ou GitHub Actions: `.github/workflows/build.yml`). APKs em `app/build/outputs/apk/release/`.
Testes pendentes (todos): 20 pesquisas variadas sem fechar, importar `.xpi` (a instalação por `file://` do cache não foi testada),
girar a tela, trocar de aba, abrir menu, comparar visualmente com o Firefox.

## Atualização — vídeo do crash (20:29)
No vídeo (build com o "E" na splash): a página inicial aparece **branca** (deveria ser preta), e ao tocar na barra o teclado abre,
a área do GeckoView fica preta e o app volta para a tela inicial **sem nenhuma pesquisa ter sido enviada**. Ou seja, o crash
acontece ao abrir o teclado, não ao pesquisar. Suspeita: o teclado redimensionava a superfície do Gecko (padding de IME no root +
`adjustResize`). Mudanças: teclado não redimensiona mais o GeckoView (só a barra sobe), `adjustNothing`, `coverUntilFirstPaint(preto)`.
**Não verificado**: causa continua sendo hipótese até haver stack trace.
Ícone do launcher: voltou ao original (PNGs de `drawable-nodpi`); troquei antes porque o roteiro pedia ícone novo.

## Atualização — log "MODO SEGURO / SIGNALED status=9" (13/10)
Achado no código: `EternalApplication.onCreate` rodava em **todos** os processos do app, inclusive nos filhos do Gecko
(`:tab`, `:gpu`, `:socket`, `:extensions`). Efeitos: (1) cada processo filho tentava criar um segundo `GeckoRuntime`;
(2) como o processo principal já tinha posto `startPending = true`, o filho lia isso e ligava o **modo seguro** sozinho,
sem nenhuma queda real (por isso o aviso de modo seguro aparecia sempre).
Correção: `isMainProcess()` — processos filhos retornam logo no início do `onCreate`.
Observação sobre o log enviado: o trecho "Log recente" é do processo NOVO (21:37:43, depois da morte às 21:37:42), então
não mostra a causa da queda. O motivo gravado pelo Android (SIGNALED/status=9, rss=0) indica morte por SIGKILL vinda de fora
do app (no seu aparelho Xiaomi/MIUI isso costuma ser o gerenciador de memória/bateria). **Não verificado em aparelho.**
Se ainda cair: ajuste Bateria > ETERNAL > "Sem restrições" e envie `adb logcat` do momento da queda.

## Atualização — modo seguro só manual
- Removida a ativação automática (`startPending` → `safeMode`). Agora só o menu liga/desliga o modo seguro.
- Migração única (`safeModeReset`): desliga o modo seguro que a lógica antiga deixou gravado no aparelho.
- Removido do relatório de queda o texto "MODO SEGURO ligado…".
- Não aplicado do roteiro (de propósito): troca do `EternalApplication` (perderia a guarda de processo, o CrashReporter e o bloqueio de
  rastreadores; além disso usa `javascriptEnabled`, que não existe — o nome é `javaScriptEnabled`); serviço em primeiro plano
  (exige permissões FOREGROUND_SERVICE* e o tipo dataSync é limitado no Android 15, risco de crash novo); `onTrimMemory` com
  `setActive(false)` (apagaria a página com o app aberto); `extractNativeLibs` no manifest (conflita com `useLegacyPackaging`);
  `readerMode.activate()` e `contentBlockingController.settings` (não existem nessa forma no GeckoView).

## Atualização — novas telas e funções (sem mexer no ícone do APK)
- **Favoritos** e **Histórico** (`LibraryStore`, `LibrarySheet`): bottom sheet com duas abas, toque abre a página, botão remove, "Limpar" no histórico. Menu: Adicionar/Remover favorito, Favoritos, Histórico.
- **Aba anônima**: sessão privada do Gecko, sem histórico, não é salva ao fechar o app, bloqueia captura de tela (FLAG_SECURE) e a barra mostra "Aba anônima". Links abertos a partir dela também são anônimos.
- **Dashboard** (página inicial): 10 cartões (Pesquisar, Nova aba, Anônima, Abas, Favoritos, Histórico, Downloads, Extensões, Importar, Configurações).
- Lista de abas marca as anônimas. Ícone do launcher (mipmap/drawable-nodpi) **não foi alterado**.
- Não incluído: modo leitor (o GeckoView não expõe API pública para ativá-lo) — fica para quando houver uma alternativa.
- Não compilado nem testado em aparelho: se o build do GitHub acusar erro, envie o log.

## Atualização — animações e estilo do dashboard
A página inicial é HTML (GeckoView), não Compose; por isso as animações foram feitas em CSS/JS (só opacity, translate, scale; 150–350 ms).
- Entrada em sequência (cabeçalho, saudação por hora do dia, busca, rótulos, cartões com stagger de 50 ms, linhas da biblioteca vindo da direita).
- Press: cartões escalam para 0,95 com fundo/borda mais claros; linhas dão "nudge" de 6 px; micro-interações (+ gira 90°, máscara pisca, estrela se desenha).
- Visual: fundo com gradiente radial sutil em preto, borda em gradiente, sombra suave na busca, ícones em círculo de 36 px, rótulos com traço, cabeçalho que encolhe ao rolar, botão "voltar ao topo".
- Respeita "remover animações" do sistema (prefers-reduced-motion). Badge de abas: escala 1,2.
- Não feito (exige dados ou trabalho maior): "Continuar de onde parou" e sites frequentes com favicon (a página não tem ponte com o app), pull-to-refresh, blur atrás de sheets, haptics configuráveis, modo tablet com split view.

## Atualização — ferramentas de desenvolvedor
Acesso: menu (⋮) > "Ferramentas de desenvolvedor" ou cartão "Ferramentas" na página inicial. Na primeira vez aparece o aviso legal (checkbox obrigatório).
- **Ver código-fonte** (`ViewSourceActivity`): HTML, CSS, JS, Imagens, Tudo; Copiar e Salvar (Download/eternal_sites/fonte/). Baixa a URL de novo, então não mostra o que depende de login/cookies.
- **Clonar site** (`SiteCloner`): somente esta página / site inteiro (mesmo domínio, até 100 páginas) / personalizado (profundidade, máx. páginas, externos, imagens, CSS, JS, fontes, vídeos). Reescreve links para caminhos locais, mostra progresso, é cancelável e entrega um **.zip** em Download/eternal_sites/.
- **Inspecionar requisições** (`NetworkActivity` + extensão embutida `assets/devtools`): método, URL, status, tipo, tempo, tamanho e cabeçalhos; filtros Todos/XHR/JS/CSS/IMG/Font. Não funciona no modo seguro (a extensão não carrega).
- **Cookies** (`StorageActivity`): lista, copia valor, remove um ou todos. Também via extensão.
- **Extrair assets** (`AssetsActivity`): lista por categoria com checkbox e baixa em Download/eternal_assets/<site>/<tipo>/.
- **DevTools remoto (USB)**: liga/desliga a depuração remota do Gecko (desligada por padrão) para usar o inspetor/console completos pelo Firefox do PC (about:debugging).
### Não implementado (limitações reais do GeckoView)
- `about:devtools-toolbox` não existe no GeckoView Android, e `GeckoSession.evaluateJS` / `webRequestDelegate` não existem: por isso Elementos/Console no próprio app ficaram de fora (use o DevTools remoto) e a rede vem de uma extensão com a API webRequest.
- localStorage/sessionStorage/IndexedDB (exigiriam content script com mensagens por aba), WARC, escolha de pasta, tela de configurações do modo desenvolvedor, user agent customizado.
- Não compilado nem testado em aparelho. Pontos de risco: a extensão devtools (webRequest/cookies) e os layouts novos; se o build acusar erro, envie o log.

## Extensões só por ZIP/URL, extensões em nova aba e wallpaper nas páginas de pesquisa

- **Instalação de extensões** apenas por arquivo `.zip` (seletor filtrado + validação) ou por URL; lista de recomendadas removida;
  `manifest.json` precisa de `manifest_version` válido (3 é o esperado; 2 ainda é tolerado). `service_worker` vira `background.scripts` para o Gecko.
- **Tela de transição ao pesquisar: removida** por completo (Activity, layout, tema, animações, configurações e chaves `SEARCH_TRANSITION_*`).
  Pesquisar carrega direto.
- **Extensões em nova aba**: popup, página de opções, painel lateral, `about:addons` e os ícones da barra abrem em aba normal.
  Removidas `ExtensionPopupActivity`, `ExtensionOptionsActivity`, `ExtensionSidebarActivity`, `AboutAddonsActivity`, seus layouts e o tema
  `Theme.Eternal.Transparent`. O popup é a `GeckoSession` que o Gecko pede (`onOpenPopup`), adotada como aba (`TabManager.adoptSession`);
  essas abas de popup não são salvas ao fechar o app.
- **Wallpaper da pesquisa** (`SearchWallpaperManager` + extensão embutida `assets/searchwallpaper`): Ajustes › "Wallpaper da pesquisa"
  (ativar, importar com permissão persistente, miniatura 120x68dp, restaurar padrão, escurecimento 0–80%). Chaves `SEARCH_WALLPAPER_*`.
  O GeckoView não tem `evaluateJS`; a injeção usa content script (mesmo esquema do modo noturno). Override genérico, sem cores do Google.
- **Limpeza**: strings, cores e drawables órfãos removidos (`popup_bg`, `eternal_splash`, `eternal_accent`, textos de about:addons/opções etc.).
