# Avisos de terceiros

ETERNAL **não é afiliado, endossado ou patrocinado pela Mozilla**. "Firefox" e "Mozilla" são marcas da Mozilla Foundation.

| Componente | Licença | Origem |
|---|---|---|
| GeckoView (motor de renderização) | Mozilla Public License 2.0 | https://github.com/mozilla/gecko-dev · https://mozilla.github.io/geckoview/ |
| AndroidX (core, appcompat, recyclerview, core-splashscreen) | Apache License 2.0 | https://developer.android.com/jetpack/androidx |
| Material Components for Android | Apache License 2.0 | https://github.com/material-components/material-components-android |
| Ícones de interface (formas Material Icons) | Apache License 2.0 | https://fonts.google.com/icons |

Texto da MPL 2.0: https://www.mozilla.org/MPL/2.0/ — o GeckoView é distribuído em forma binária (AAR); o código-fonte
correspondente está disponível no repositório da Mozilla acima. Ao distribuir o ETERNAL, mantenha este arquivo
e a tela "Sobre / Licenças" do app.

Extensões instaladas pelo usuário (ex.: uBlock Origin — GPLv3; Dark Reader — MIT) pertencem aos respectivos autores e
são baixadas diretamente de addons.mozilla.org; **não** são redistribuídas dentro do APK.
