# ETERNAL — alterações e validação

## Resultado desta execução

As alterações foram feitas em uma cópia de trabalho extraída de `eternal-browser-atualizado.zip`; o ZIP original não foi modificado.

### GeckoView e bibliotecas nativas

- Declarado `android:extractNativeLibs="true"` na aplicação e `android:hardwareAccelerated="true"` na `MainActivity`.
- (Removido depois: `android.bundle.enableUncompressedNativeLibs` foi eliminada no AGP 8.1 e quebra o AGP 9; o padrão já é `true`.)
- Mantido `useLegacyPackaging = true`.
- Desativados minificação e shrink de recursos no build `release` enquanto o carregamento do motor estiver em diagnóstico.
- Mantida a estratégia existente de `splits.abi` com APK universal (`arm64-v8a` + `armeabi-v7a`), sem acrescentar `abiFilters`.
- Mantida a versão GeckoView Nightly já configurada no projeto (`158.0.20260924093433`); a lógica existente que cria o runtime e a configuração de extensões não foi substituída.
- Se o runtime não inicializar, o diálogo e o log agora incluem ABIs suportadas, diretório nativo, caminho do APK e a causa capturada.

### Organização e Configurações

- Criado `core/storage/` para `Prefs`, `PrefsKeys`, `PrefsManager` e `LibraryStore`. O acesso direto a `SharedPreferences` ficou centralizado em `PrefsManager`.
- Movido `TabManager` para `core/engine/`.
- Movidos a atividade e o registro para `features/settings/`; as 14 categorias têm arquivos próprios em `features/settings/sections/`.
- Ampliada a tela com filtro em tempo real, controles persistidos, sliders para brilho/contraste noturnos, campo de URL de busca personalizada (`{query}` ou `%s`), seleção entre oito mecanismos, restauração de abas, controle de notificação de downloads, exportação/importação JSON e reset com confirmação por checkbox.
- Mantida a UI nativa já usada pelo projeto (Views/Material), pois o build original não inclui Compose. Opções cuja implementação não existe no app — por exemplo, sincronização de conta e alguns controles avançados de privacidade — são apresentadas como limitações informativas, não como switches sem efeito.
- Alinhados os cinzas do dashboard e os recursos visuais à paleta monocromática especificada.

## Verificações realizadas

- XML: **40 arquivos** analisados pelo parser XML do Python, sem erros de sintaxe.
- Cores hexadecimais de seis dígitos nos recursos/código verificados: **nenhuma fora da paleta permitida**.
- Referências Kotlin importadas entre pacotes do projeto: **nenhuma referência interna ausente** na verificação estática.
- Arquivos de seção: **14**, com 14 chamadas no registro central.
- `getSharedPreferences()` em código Kotlin: **somente em `PrefsManager`**.
- O projeto usa a estratégia de ABI `splits` sem `abiFilters` explícitos e conserva `useLegacyPackaging = true`.

## Validação que permanece pendente

Este ambiente não dispõe de `adb`, `gradle`, `gradlew`, `kotlinc`, Android SDK, `sdkmanager` ou `aapt`. Além disso, o ZIP recebido contém apenas o código-fonte: não há APK/AAB, diretório de outputs nem bibliotecas `.so`. Portanto, não foi possível compilar, listar as `.so` do APK universal, instalar o app, obter ABI do aparelho, verificar a extração pós-instalação ou confirmar que o motor abre. **Não há APK novo nem logcat real anexado a este resultado.**

Para terminar o diagnóstico em um computador com Android SDK/ADB e o APK universal compilado, execute e envie os resultados:

```bash
adb shell getprop ro.product.cpu.abi
adb shell getprop ro.product.cpu.abilist
unzip -l app/build/outputs/apk/release/app-universal-release.apk | grep '\.so$'
adb shell run-as com.eternal.browser ls -la /data/data/com.eternal.browser/lib/ 2>&1
adb uninstall com.eternal.browser
adb install app/build/outputs/apk/release/app-universal-release.apk
adb shell dumpsys package com.eternal.browser | grep primaryCpuAbi
adb logcat -c
# Abra o app, reproduza a falha, e então capture o log abaixo.
adb logcat -d | grep -iE 'GeckoLibLoad|GeckoRuntime|GeckoThread|libmozglue|libxul|UnsatisfiedLink|dlopen|FATAL|Eternal|signal'
```

Depois de gerar o APK, instale-o no dispositivo ARM64, abra o ETERNAL, reproduza a falha (se houver) e capture o logcat. A confirmação final de inicialização só pode ser feita no aparelho.

## Repositório e commit

O ZIP original não contém diretório `.git`, Gradle Wrapper nem histórico. Por isso, não criei um commit artificial nem declarei build concluído. O ZIP de entrega contém a cópia do código-fonte atualizado e este relatório; o APK e a validação em aparelho continuam pendentes.
