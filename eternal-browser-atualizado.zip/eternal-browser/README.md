# ETERNAL — navegador Android sobre GeckoView

Navegador Android (Kotlin, Material 3) com o motor **GeckoView** (Mozilla, sem Chromium):
extensões WebExtensions, bloqueio de anúncios/rastreadores/pop-ups, modo noturno, tema dark preto e branco (dashboard)
e barra de endereço configurável (embaixo ou em cima). Package: `com.eternal.browser`.

> **Estado honesto do projeto:** as chamadas ao GeckoView foram conferidas, uma a uma, no javadoc atual
> (mozilla-central, versão 158), mas o projeto **ainda não foi compilado nem testado em aparelho** (o ambiente onde foi
> gerado não tinha Android SDK). Se o primeiro build no GitHub Actions acusar erro, cole o log para corrigir.

## 1. Pré-requisitos
- Android Studio recente, JDK 17, Android SDK 34, Git. Windows, macOS ou Linux.
- 8 GB de RAM (16 GB recomendado) e espaço livre em disco (GeckoView é um AAR grande).

## 2. Compilar pelo GitHub Actions (recomendado)
1. Suba esta pasta para um repositório do GitHub (branch `main`). O arquivo `.github/workflows/build.yml` já está pronto.
2. (Opcional, mas necessário para o app poder receber atualizações) crie em *Settings → Secrets and variables → Actions*:
   `KEYSTORE_BASE64` (`base64 -w0 eternal-release-key.jks`), `KEYSTORE_PASSWORD` e `KEY_ALIAS`.
   Sem eles, o workflow assina com uma chave **temporária** (o APK instala, mas cada build tem uma assinatura diferente).
3. O build roda a cada push, ou manualmente em *Actions → Build ETERNAL → Run workflow*.
4. Baixe os APKs no artefato **ETERNAL-apks** (`arm64-v8a`, `armeabi-v7a` e `universal`; aparelhos de 2017 em diante: `arm64-v8a`).

Versões: GeckoView **158.0.20261007201254** (release mais recente do Maven da Mozilla em 13/10/2026), Gradle 9.3.1, AGP 9.1.1,
Kotlin 2.4.20, JDK 17, compileSdk 37 / targetSdk 35. Para atualizar o motor depois, mude `geckoViewVersion` em `gradle.properties`
(veja o campo `<release>` em <https://maven.mozilla.org/maven2/org/mozilla/geckoview/geckoview/maven-metadata.xml>).
**Mantenha o GeckoView sempre atualizado:** ele é o motor do navegador e recebe correções de segurança frequentes.

## 2b. Compilar localmente
Android Studio + JDK 17: abra a pasta (ele cria o wrapper) ou rode `gradle wrapper --gradle-version 9.3.1` e depois
`./gradlew assembleDebug`. APKs em `app/build/outputs/apk/`.

## 3. Release assinado
```bash
keytool -genkey -v -keystore signing/eternal-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias eternal
cp keystore.properties.example keystore.properties   # edite as senhas
./gradlew assembleRelease
```
Os APKs saem em `app/build/outputs/apk/release/` (arm64-v8a, armeabi-v7a e universal). As senhas ficam em
`keystore.properties`, ignorado pelo Git (no roteiro original estavam escritas dentro do `build.gradle.kts`).
Guarde o `.jks` com backup: sem ele não há como publicar atualizações.

## 4. O que está implementado
| Recurso | Como |
|---|---|
| Motor GeckoView, abas | `TabManager` — 1 `GeckoSession` por aba, só a atual fica ativa; abas restauradas ao reabrir |
| Extensões | `ExtensionManager` — instalar só por arquivo .zip ou URL (Manifest V3), listar, ativar/desativar, remover, tela de permissões |
| Atalhos de instalação | uBlock Origin e Dark Reader (baixados do addons.mozilla.org na hora) |
| Bloqueio | Proteção contra rastreamento STRICT do Gecko (anúncios, analytics, social, fingerprinting, cryptomining) + pop-ups negados em `PromptHandler` |
| Extensões em nova aba | `ExtensionActionManager` — popup, página de opções, painel lateral e `about:addons` abrem em **nova aba normal** (como o Kiwi), com a URL visível; o popup é a `GeckoSession` do Gecko adotada pelo `TabManager.adoptSession` |
| Wallpaper da pesquisa | `SearchWallpaperManager` + extensão embutida `assets/searchwallpaper`: nas páginas de resultados (Google, Bing, DuckDuckGo, Brave, Ecosia, Startpage, Qwant) troca o fundo pelo wallpaper escolhido em Ajustes, com override genérico (qualquer fundo grande vira transparente, sem cores do site) e escurecimento ajustável. O URI é salvo em preferências; a imagem vira data URL (base64) em cache |
| Modo noturno | `NightModeController` + extensão embutida `assets/nightmode`: `prefers-color-scheme: dark`, inversão inteligente (ignora páginas já escuras, preserva imagens/vídeo), brilho e contraste ajustáveis |
| Tema | Material 3 escuro, somente preto/branco/cinzas, cantos 8dp; ripple nos botões; animação dos itens e do contador de abas; fade na troca de aba |
| Splash animada | `AnimatedVectorDrawable` do ∞ se desenhando + `core-splashscreen` |
| Página inicial | `assets/start/index.html` (animada) |
| Barra | URL/busca, voltar, avançar, recarregar/parar, progresso, cadeado, abas, menu; **embaixo ou em cima** (menu) |
| Outros | Motor de busca selecionável, downloads (DownloadManager), alert/confirm/prompt, tela cheia, navegador padrão (http/https) |

## 5. Pendente / limitações
- **Extensões com interface** (ícone/popup de barra de ferramentas, páginas de opções): exigem `ActionDelegate` e
  `TabDelegate` por extensão. Hoje funcionam as que atuam sozinhas (uBlock Origin com regras padrão, content scripts);
  o painel do uBO e as opções do Dark Reader não abrem.
- Blur (RenderEffect) não foi aplicado; miniaturas de abas não existem (`GeckoSession.capturePixels()` serve).
- Sem modo privado, histórico, favoritos, senhas, busca na página, permissões de câmera/localização
  (o `PermissionDelegate` não está implementado: esses pedidos são negados).
- Downloads usam o `DownloadManager` (refaz a requisição GET; não cobre POST/cookies de sessão).
- Piscada branca breve ao ligar o modo noturno em páginas que já são escuras (a checagem acontece no DOM pronto).
- Sem testes automatizados. A lista de testes manuais está na seção 7.

## 6. Riscos conhecidos (revise na primeira compilação)
1. **Assinaturas do GeckoView mudam entre versões** (ao passar da 126 para a 158 já mudaram `onInstallPromptRequest`,
   que ganhou `dataCollectionPermissions`, e `PermissionPromptResponse`, que ganhou um 3º argumento). Não conferi
   no javadoc: `GeckoSession.isOpen()`, `exitFullScreen()`, `SecurityInformation.isSecure` e o tipo de `WebResponse.headers`.
   Javadoc: <https://mozilla.github.io/geckoview/javadoc/mozilla-central/>.
2. **Comunicação app ↔ extensão:** usa `connectNative("eternal")`. Se o modo noturno não reagir, veja o `logcat`
   (`adb logcat | grep -i -E "gecko|eternal"`) e confirme que `ensureBuiltIn` carregou a extensão.
3. **Play Store:** as exigências de `targetSdk` mudam todo ano; o projeto usa 35 (com *edge-to-edge* tratado), o que serve
   para instalar o APK direto. Para publicar na loja, confira o mínimo vigente.

## 7. Roteiro de testes manuais
1. Abre com a splash animada e a página inicial; digitar `exemplo.com` e uma busca com espaços.
2. Abas: abrir várias, trocar, fechar a atual, fechar a última (deve abrir uma nova); link `target=_blank` abre aba.
3. Barra: alternar embaixo/em cima no menu; voltar/avançar; recarregar/parar; cadeado correto em HTTPS.
4. Extensões: instalar uBlock Origin → confirmar a tela de permissões → visitar um site cheio de anúncios; desativar e remover.
5. Modo noturno: ligar no menu, testar em página clara (inverte, fotos normais) e em página escura (não inverte); mexer nos sliders.
6. Pop-ups: página de teste de pop-up deve mostrar "Pop-up bloqueado".
7. Rotação, tela cheia de vídeo, download de arquivo, definir como navegador padrão.

## 8. Mudanças em relação ao roteiro original (e por quê)
- `session.contentBlockingController` **não existe**: o bloqueio é configurado no `GeckoRuntimeSettings` (`ContentBlocking.Settings`).
- `.install(...).accept{}.reject{}` **não existe** em `GeckoResult`: usa-se `accept(onValue, onError)`.
- `extensionsWebAPIEnabled` exige um `PromptDelegate` — sem ele nenhuma extensão instala.
- `uninstall(id)` na verdade recebe o objeto `WebExtension`.
- `contentProcessHint(...)` e `ALLOW_TRACKING_PROTECTION` **não existem**; o desempenho vem de ETP, R8, ABI splits, sessões suspensas.
- `aboutConfigEnabled(true)` e `remoteDebuggingEnabled(true)` ficam **só no debug** (no release seriam brechas).
- `allowBackup="false"` (o perfil do navegador não deve ir para backups de nuvem); `READ_EXTERNAL_STORAGE` removida; `WRITE_EXTERNAL_STORAGE` só até Android 9.
- `onBackPressed()` direto fechava o app em páginas sem histórico; substituído por `OnBackPressedCallback`.
- Compose, Lottie e coroutines removidos (não eram usados); `core-splashscreen` adicionado (necessário ao tema de splash).
- `Theme.Material3.Dark` → `...NoActionBar`.
- O ZIP não inclui o `gradlew` (o workflow instala o Gradle) nem chave de assinatura.
- Atualizado: GeckoView 126 → 158, AGP 8.5 → 8.7, Kotlin 1.9 → 2.0, SDK 34 → 35.

## 9. Licenças e marcas
Veja `THIRD_PARTY_NOTICES.md`. Resumo: GeckoView é MPL 2.0 (mantenha os avisos; modificações em arquivos MPL devem
ser publicadas sob MPL). Não use "Firefox"/"Mozilla" no nome, ícones ou textos de marketing. Extensões seguem as
licenças de seus autores. Defina a licença do **seu** código antes de publicar (nenhuma foi imposta aqui).
