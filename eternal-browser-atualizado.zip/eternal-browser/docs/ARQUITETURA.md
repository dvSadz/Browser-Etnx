# Arquitetura

```
EternalApplication  → cria o GeckoRuntime único (ETP strict, extensões, tema)
MainActivity        → UI (barra, menu) e GeckoView; implementa TabManager.Listener
 ├─ TabManager      → abas = GeckoSession + delegates (progresso, navegação, conteúdo, prompts)
 │   └─ PromptHandler → alert/confirm/prompt e bloqueio de pop-ups
 ├─ ExtensionManager→ WebExtensionController: instalar/listar/ativar/remover + tela de permissões
 ├─ SearchWallpaperManager → extensão embutida (assets/searchwallpaper) via mensagem nativa "eternal": wallpaper nas páginas de busca
 ├─ NightModeController → tema do Gecko + extensão embutida (assets/nightmode) via mensagem nativa "eternal"
 └─ TabSwitcherSheet→ bottom sheet de abas
Prefs / UrlUtils    → preferências e normalização de URL/busca
CrashReporter       → grava stack trace de exceções Java e mostra no próximo start
TabManager.load()   → único caminho de navegação digitada (main thread, reabre sessão, try/catch)
```
Fluxo do modo noturno: menu → `Prefs.nightMode` → `NightModeController.apply()` →
`GeckoRuntimeSettings.setPreferredColorScheme` + `port.postMessage(JSON)` → `background.js` grava em
`storage.local` → `content.js` (em cada página) reage a `storage.onChanged` e aplica/remove o CSS.
