import java.util.Properties
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val geckoViewVersion: String by project
val geckoViewChannel: String by project
// "release" usa o artefato "geckoview"; nightly/beta usam "geckoview-<canal>".
val geckoViewArtifact = if (geckoViewChannel == "release") "geckoview" else "geckoview-$geckoViewChannel"

// Assinatura lida de keystore.properties (fora do Git). Sem o arquivo, o release sai sem assinar.
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "com.eternal.browser"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.eternal.browser"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildFeatures {
        buildConfig = true
    }

    signingConfigs {
        if (keystoreProps.containsKey("storeFile")) {
            create("release") {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            // Mantidos desligados até confirmar a inicialização do GeckoView no aparelho.
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfigs.findByName("release")?.let { signingConfig = it }
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    // ABI: ESTRATÉGIA ÚNICA (não misturar com ndk.abiFilters) — 3 APKs: arm64-v8a, armeabi-v7a e universal
    // (universal = arm64-v8a + armeabi-v7a). x86/x86_64 ficam de fora: só servem a emuladores.
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a")
            isUniversalApk = true
        }
    }

    packaging {
        jniLibs { useLegacyPackaging = true } // GeckoView carrega libs nativas extraídas
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    implementation("org.mozilla.geckoview:$geckoViewArtifact:$geckoViewVersion")

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.google.android.material:material:1.12.0")
    // Removidos em relação ao roteiro (peso sem uso): Compose, Lottie, coroutines.
}
