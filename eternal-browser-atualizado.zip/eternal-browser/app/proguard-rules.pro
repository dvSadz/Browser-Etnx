# GeckoView usa JNI/reflexão intensamente.
-keep class org.mozilla.geckoview.** { *; }
-keep class org.mozilla.gecko.** { *; }
-dontwarn org.mozilla.**
-keepattributes *Annotation*, SourceFile, LineNumberTable

# Remove logs de debug no release
-assumenosideeffects class android.util.Log {
    public static int d(...);
    public static int v(...);
}
