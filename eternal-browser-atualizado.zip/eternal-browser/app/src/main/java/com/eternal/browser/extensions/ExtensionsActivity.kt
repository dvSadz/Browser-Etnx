package com.eternal.browser.extensions

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.eternal.browser.EternalApplication
import com.eternal.browser.R
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.mozilla.geckoview.WebExtension

/** Tela "Gerenciar extensões": lista, liga/desliga, remove e abre popup, opções e painel lateral. */
class ExtensionsActivity : AppCompatActivity() {
    companion object {
        /** Extra do resultado devolvido à MainActivity: "install" abre o seletor de instalação. */
        const val RESULT_ACTION = "action"
        private const val PLAY_COOLDOWN_MS = 2500L
        private const val PLAY_LOADING_MS = 700L
    }

    private lateinit var adapter: ExtensionsAdapter
    private lateinit var actions: ExtensionActionManager
    private lateinit var empty: TextView
    private val refresh: () -> Unit = { loadExtensions() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_extensions)

        actions = ExtensionActionManager.get(this) ?: run { finish(); return }
        empty = findViewById(R.id.extEmpty)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnImport).setOnClickListener {
            setResult(Activity.RESULT_OK, Intent().putExtra(RESULT_ACTION, "install"))
            finish()
        }
        findViewById<View>(R.id.btnAboutAddons).setOnClickListener {
            if (actions.openAddons()) finish() else toast(getString(R.string.ext_toggle_fail))
        }

        val list = findViewById<RecyclerView>(R.id.extensionsList)
        list.layoutManager = LinearLayoutManager(this)
        adapter = ExtensionsAdapter(
            actions = actions,
            // Tudo abre em nova aba do navegador; esta tela fecha para o usuário cair direto nela.
            onPlay = { ext -> play(ext) },
            onOpenOptions = { ext ->
                if (actions.openOptions(ext)) finish() else toast(getString(R.string.ext_no_options))
            },
            onOpenSidebar = { ext ->
                if (actions.openSidebar(ext)) finish() else toast(getString(R.string.ext_no_sidebar))
            },
            onToggle = { ext, on -> actions.setEnabled(ext, on) { ok -> if (!ok) toast(getString(R.string.ext_toggle_fail)); loadExtensions() } },
            onRemove = { ext -> confirmRemove(ext) },
        )
        list.adapter = adapter
        actions.addListener(refresh)
    }

    override fun onResume() {
        super.onResume()
        loadExtensions()
    }

    override fun onDestroy() {
        if (::actions.isInitialized) loading.dismiss()
        if (::actions.isInitialized) actions.removeListener(refresh)
        super.onDestroy()
    }

    private var lastPlayAt = 0L
    private var playing = false
    private val loading by lazy { LoadingPopup(this) }

    /** Play: cooldown anti-spam + mini loading no centro, depois abre popup → opções → painel (o que existir). */
    private fun play(ext: WebExtension) {
        val now = SystemClock.uptimeMillis()
        if (playing || now - lastPlayAt < PLAY_COOLDOWN_MS) return
        lastPlayAt = now
        playing = true
        loading.show()
        Handler(Looper.getMainLooper()).postDelayed({
            actions.openAnyUi(ext) { ok ->
                loading.dismiss()
                playing = false
                if (ok) finish()
                else toast(getString(R.string.ext_no_popup) + (actions.lastFailure?.let { "\n($it)" } ?: ""))
            }
        }, PLAY_LOADING_MS)
    }

    private fun confirmRemove(ext: WebExtension) {
        val name = try { ext.metaData?.name } catch (_: Throwable) { null } ?: ext.id
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.ext_remove_title, name))
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(R.string.ext_remove) { _, _ ->
                actions.uninstall(ext) { ok ->
                    toast(getString(if (ok) R.string.ext_removed else R.string.ext_toggle_fail))
                    loadExtensions()
                }
            }
            .show()
    }

    private fun loadExtensions() {
        if (!EternalApplication.isReady()) return
        actions.listInstalledExtensions { extensions ->
            if (isFinishing || isDestroyed) return@listInstalledExtensions
            adapter.submitList(extensions)
            empty.visibility = if (extensions.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    override fun finish() {
        super.finish()
        ExtensionTransitions.slideOut(this)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
