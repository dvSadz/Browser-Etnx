package com.eternal.browser

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Requisições http(s) capturadas pela extensão embutida (método, URL, status, tipo, tempo, tamanho, cabeçalhos). */
class NetworkActivity : ToolActivity() {
    private var filter = "all"
    private val handler = Handler(Looper.getMainLooper())
    private var pending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        animateRows = true
        setTitleText("Rede")
        setAction1("Limpar") { DevToolsHub.clear() }
        addChip("Todos") { filter = "all"; refresh() }
        addChip("XHR") { filter = "xhr"; refresh() }
        addChip("JS") { filter = "js"; refresh() }
        addChip("CSS") { filter = "css"; refresh() }
        addChip("IMG") { filter = "img"; refresh() }
        addChip("Font") { filter = "font"; refresh() }
        onRowClick = { row -> (row.tag as? DevToolsHub.Req)?.let { details(it) } }
    }

    override fun onStart() {
        super.onStart()
        DevToolsHub.listener = {
            if (!pending) {
                pending = true
                handler.postDelayed({ pending = false; if (!isFinishing && !isDestroyed) refresh() }, 300)
            }
        }
        refresh()
    }

    override fun onStop() {
        DevToolsHub.listener = null
        super.onStop()
    }

    private fun matches(r: DevToolsHub.Req) = when (filter) {
        "xhr" -> r.type == "xmlhttprequest" || r.type == "fetch" || r.type == "ping"
        "js" -> r.type == "script"
        "css" -> r.type == "stylesheet"
        "img" -> r.type == "image" || r.type == "imageset"
        "font" -> r.type == "font"
        else -> true
    }

    private fun size(b: Long) = when {
        b <= 0 -> "—"
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> "${b / 1024} KB"
        else -> String.format("%.1f MB", b / 1048576.0)
    }

    private fun refresh() {
        setStatus(if (DevToolsHub.connected) "Capturando requisições (a lista zera ao abrir uma nova página)" else "Extensão de rede não conectada")
        val list = DevToolsHub.snapshot().asReversed().filter { matches(it) }.take(300).map {
            ToolRow(
                title = "${it.method} ${UrlUtils.display(it.url).ifBlank { it.url }}",
                sub = "${it.type} · ${it.ms} ms · ${size(it.size)}",
                right = if (it.status == 0) "ERR" else it.status.toString(),
                tag = it,
            )
        }
        showRows(
            list,
            if (DevToolsHub.connected) "Nenhuma requisição. Abra uma página no navegador e volte aqui."
            else "Sem dados. As ferramentas de rede não funcionam no modo seguro: desligue-o no menu e reabra o app."
        )
    }

    private fun details(r: DevToolsHub.Req) {
        val msg = buildString {
            append(r.method).append(' ').append(r.url).append("\n\n")
            append("Status: ").append(if (r.status == 0) "erro ${r.error}" else r.status).append('\n')
            append("Tipo: ").append(r.type).append('\n')
            append("Tempo: ").append(r.ms).append(" ms\n")
            append("Tamanho: ").append(size(r.size)).append("\n\nCabeçalhos da resposta:\n")
            if (r.headers.isEmpty()) append("(nenhum)") else r.headers.forEach { append(it.first).append(": ").append(it.second).append('\n') }
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Requisição")
            .setMessage(msg)
            .setPositiveButton("Copiar URL") { _, _ -> copyToClipboard("url", r.url) }
            .setNegativeButton("Fechar", null)
            .show()
    }
}
