package com.eternal.browser.features.settings.sections

import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.Prefs
object AdvancedSection {
    fun build(prefs: Prefs) = SettingSection("AVANÇADO", listOf(
        SettingItem.Action("reset", "Redefinir configurações", "Volta as opções registradas aos valores padrão"),
        SettingItem.Action("restart", "Reiniciar o ETERNAL", "Recarrega opções do motor marcadas para reiniciar"),
    ))
}
