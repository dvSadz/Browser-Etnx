package com.eternal.browser.features.settings.sections

import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.PrefsKeys
import com.eternal.browser.core.storage.Prefs
object AppearanceSection {
    fun build(prefs: Prefs) = SettingSection("APARÊNCIA", listOf(
        SettingItem.Toggle(PrefsKeys.BAR_BOTTOM, "Barra de endereço embaixo", "Desligado posiciona a barra no topo", true),
        SettingItem.Toggle(PrefsKeys.NIGHT_MODE, "Modo noturno", "Aplica o modo escuro às páginas", false),
        SettingItem.Range(PrefsKeys.NIGHT_BRIGHTNESS, "Brilho do modo noturno", "Ajuste aplicado às páginas escurecidas", 50, 150, 95, "%"),
        SettingItem.Range(PrefsKeys.NIGHT_CONTRAST, "Contraste do modo noturno", null, 50, 150, 105, "%"),
    ))
}
