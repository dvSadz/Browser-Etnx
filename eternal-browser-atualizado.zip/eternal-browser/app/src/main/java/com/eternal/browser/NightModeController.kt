package com.eternal.browser

import org.json.JSONObject
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.WebExtension

import com.eternal.browser.core.storage.Prefs
/**
 * Modo noturno do ETERNAL, em duas camadas:
 *  1. prefers-color-scheme: dark para sites que já têm tema escuro (nativo do Gecko);
 *  2. extensão embutida (assets/nightmode) que inverte páginas claras, preserva imagens/vídeos
 *     e ajusta brilho/contraste. Páginas já escuras não são invertidas.
 * O app fala com a extensão por mensagem nativa (porta "eternal").
 */
class NightModeController(
    private val runtime: GeckoRuntime,
    private val prefs: Prefs,
) {
    companion object {
        const val EXTENSION_URI = "resource://android/assets/nightmode/"
        const val EXTENSION_ID = "nightmode@eternal.browser"
        const val NATIVE_APP = "eternal"
    }

    private var port: WebExtension.Port? = null

    /** Chamado quando a extensão embutida foi carregada. */
    fun bind(extension: WebExtension) {
        extension.setMessageDelegate(object : WebExtension.MessageDelegate {
            override fun onConnect(port: WebExtension.Port) {
                this@NightModeController.port = port
                port.setDelegate(object : WebExtension.PortDelegate {
                    override fun onDisconnect(port: WebExtension.Port) {
                        if (this@NightModeController.port === port) this@NightModeController.port = null
                    }
                })
                push()
            }
        }, NATIVE_APP)
    }

    /** Aplica a configuração atual (tema do Gecko + extensão). */
    fun apply() {
        runtime.settings.setPreferredColorScheme(
            if (prefs.nightMode) GeckoRuntimeSettings.COLOR_SCHEME_DARK
            else GeckoRuntimeSettings.COLOR_SCHEME_SYSTEM
        )
        push()
    }

    private fun push() {
        port?.postMessage(
            JSONObject()
                .put("enabled", prefs.nightMode)
                .put("brightness", prefs.nightBrightness)
                .put("contrast", prefs.nightContrast)
        )
    }
}
