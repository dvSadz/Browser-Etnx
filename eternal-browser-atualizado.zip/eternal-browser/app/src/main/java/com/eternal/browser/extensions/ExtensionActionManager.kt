package com.eternal.browser.extensions

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.eternal.browser.EternalApplication
import java.util.Collections
import java.util.WeakHashMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController

/**
 * Ponte entre as extensões instaladas e a UI do ETERNAL.
 *
 * API real do GeckoView (conferida no Javadoc 158):
 *  - não existe metaData.browserActionPopupUrl nem sidebarUrl; o popup é aberto por action.click(),
 *    e o delegate recebe onOpenPopup/onTogglePopup e devolve a GeckoSession onde o popup é carregado;
 *  - toda UI de extensão (popup, opções, painel lateral, about:addons) abre em NOVA ABA normal, como no Kiwi:
 *    páginas por URL (openUrl) e o popup adotando a GeckoSession que o Gecko pede (openExtensionSession);
 *  - o ActionDelegate é registrado POR EXTENSÃO (WebExtension.setActionDelegate), não no controller;
 *  - a página de opções vem em metaData.optionsPageUrl;
 *  - o GeckoView não implementa sidebar_action: o painel lateral só funciona de forma experimental
 *    (ver sidebarUrl).
 */
class ExtensionActionManager private constructor(
    private val app: Context,
    private val runtime: GeckoRuntime,
) {
    companion object {
        private const val TAG = "ExtActionManager"
        private const val SIDEBAR_PREFS = "eternal_ext_sidebar"
        private const val POPUP_PREFS = "eternal_ext_popup"
        private const val OPTIONS_PREFS = "eternal_ext_options"
        /** Se o Gecko não pedir o popup neste prazo após o click(), abre o popup.html do manifest em nova aba
         *  (ou reporta que não há popup, se também não houver fallback conhecido). Checado em passos curtos
         *  para não atrasar o caso comum, em que o Gecko responde quase na hora. */
        private const val POPUP_FALLBACK_MS = 900L
        private const val POPUP_POLL_MS = 60L

        /** Extra do Intent enviado à MainActivity quando não há uma instância dela para abrir a aba direto. */
        const val EXTRA_OPEN_URL_NEW_TAB = "open_url_new_tab"

        @Volatile private var instance: ExtensionActionManager? = null

        /** Null enquanto o GeckoRuntime não existe (falha de inicialização). */
        fun get(context: Context): ExtensionActionManager? {
            if (!EternalApplication.isReady()) return null
            return instance ?: synchronized(this) {
                instance ?: ExtensionActionManager(context.applicationContext, EternalApplication.runtime)
                    .also { instance = it }
            }
        }
    }

    /** Quem sabe abrir abas (a MainActivity). Sempre chamado na main thread. */
    interface TabHost {
        fun openUrl(url: String)
        /** Aba para a sessão do popup que o Gecko vai preencher. */
        fun openExtensionSession(extensionId: String, session: GeckoSession)
        /** Se já existe a aba do popup desta extensão, seleciona e devolve true. */
        fun focusExtensionTab(extensionId: String): Boolean
    }

    @Volatile var tabHost: TabHost? = null

    private val main = Handler(Looper.getMainLooper())
    private val controller: WebExtensionController get() = runtime.webExtensionController

    /** Ação padrão (browser action) de cada extensão, entregue pelo Gecko depois que o delegate é registrado. */
    private val actions = ConcurrentHashMap<String, WebExtension.Action>()
    private val actionKeys = ConcurrentHashMap<String, String>()
    /** Última vez que o Gecko pediu o popup de cada extensão (onOpenPopup/onTogglePopup). */
    private val popupRequestedAt = ConcurrentHashMap<String, Long>()

    /** Motivo da última falha de [openPopup], para a UI mostrar em vez de uma mensagem genérica. */
    @Volatile var lastFailure: String? = null
        private set
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val attached: MutableSet<WebExtension> = Collections.newSetFromMap(WeakHashMap())

    fun addListener(l: () -> Unit) { listeners.addIfAbsent(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    private fun notifyChanged() { main.post { listeners.forEach { runCatching(it) } } }

    // ---------- delegates ----------

    private val actionDelegate = object : WebExtension.ActionDelegate {
        override fun onBrowserAction(extension: WebExtension, session: GeckoSession?, action: WebExtension.Action) {
            // Só a ação padrão (session == null); ações por aba não entram na barra.
            Log.i(TAG, "onBrowserAction ext=${extension.id} session=${session != null} enabled=${action.enabled}")
            if (session != null) return
            actions[extension.id] = action
            // Só avisa a UI quando algo que muda a barra mudou (evita repintar a cada badge do uBlock).
            val key = "${action.enabled}"
            if (actionKeys.put(extension.id, key) != key) notifyChanged()
        }

        override fun onTogglePopup(extension: WebExtension, action: WebExtension.Action): GeckoResult<GeckoSession>? {
            Log.i(TAG, "onTogglePopup ext=${extension.id}")
            return createPopup(extension)
        }

        override fun onOpenPopup(extension: WebExtension, action: WebExtension.Action): GeckoResult<GeckoSession>? {
            Log.i(TAG, "onOpenPopup ext=${extension.id}")
            return createPopup(extension)
        }
    }

    private val tabDelegate = object : WebExtension.TabDelegate {
        // runtime.openOptionsPage() chamado pela própria extensão (ex.: botão "Configurações" do popup).
        override fun onOpenOptionsPage(source: WebExtension) {
            openOptions(source)
        }

        /**
         * tabs.create() chamado pela própria extensão (comum em extensões cujo action.onClicked abre a
         * própria interface como uma aba, em vez de usar popup). Sem isto, a chamada falha calada: o
         * padrão da API (ver Javadoc) é "se o retorno for nulo, a extensão recebe falha e nada abre" —
         * é a causa real de extensões "estilo Kiwi" que abrem página não abrirem nada no ETERNAL.
         */
        override fun onNewTab(source: WebExtension, createDetails: WebExtension.CreateTabDetails): GeckoResult<GeckoSession>? {
            Log.i(TAG, "onNewTab ext=${source.id} url=${createDetails.url} active=${createDetails.active}")
            val host = tabHost
            if (host == null) {
                Log.w(TAG, "onNewTab: tabHost nulo (MainActivity não registrada) ext=${source.id}")
                return null
            }
            return try {
                val s = GeckoSession()
                s.open(runtime)
                // Não é preciso carregar createDetails.url manualmente: o Gecko navega a sessão devolvida.
                host.openExtensionSession(source.id, s)
                Log.i(TAG, "onNewTab: aba criada para ${source.id}")
                GeckoResult.fromValue(s)
            } catch (t: Throwable) {
                Log.e(TAG, "Erro ao criar aba (tabs.create) de ${source.id}", t)
                null
            }
        }
    }

    /** Registra os delegates numa extensão. Seguro para chamar várias vezes. */
    fun attach(ext: WebExtension) {
        if (ext.isBuiltIn) return
        // setTabDelegate é @UiThread.
        if (Looper.myLooper() != Looper.getMainLooper()) { main.post { attach(ext) }; return }
        synchronized(attached) { if (!attached.add(ext)) return }
        Log.i(TAG, "attach delegates em ${ext.id}")
        try {
            ext.setActionDelegate(actionDelegate)
            ext.setTabDelegate(tabDelegate)
        } catch (t: Throwable) {
            Log.e(TAG, "Erro ao registrar delegates de ${ext.id}", t)
        }
    }

    /** Popup em nova aba: se a aba da extensão já existe, só a seleciona; senão cria a sessão e a entrega à aba. */
    private fun createPopup(ext: WebExtension): GeckoResult<GeckoSession>? = try {
        popupRequestedAt[ext.id] = System.currentTimeMillis()
        val host = tabHost
        if (host == null) {
            Log.w(TAG, "createPopup: tabHost nulo (MainActivity não registrada) ext=${ext.id}")
            null
        } else if (host.focusExtensionTab(ext.id)) {
            Log.i(TAG, "createPopup: aba da extensão já existe, só selecionada ext=${ext.id}")
            null
        } else {
            val s = GeckoSession()
            s.open(runtime)
            host.openExtensionSession(ext.id, s)
            Log.i(TAG, "createPopup: sessão entregue ao Gecko ext=${ext.id}")
            GeckoResult.fromValue(s)
        }
    } catch (t: Throwable) {
        Log.e(TAG, "Erro ao abrir popup de ${ext.id}", t)
        null
    }

    // ---------- consulta ----------

    /** Lista as extensões instaladas (sem as embutidas do ETERNAL) e registra os delegates em cada uma. */
    fun listInstalledExtensions(callback: (List<WebExtension>) -> Unit) {
        try {
            controller.list().accept(
                { list ->
                    val exts = (list ?: emptyList()).filter { !it.isBuiltIn }
                    val ids = exts.map { it.id }.toSet()
                    actions.keys.retainAll(ids)
                    actionKeys.keys.retainAll(ids)
                    exts.forEach { attach(it) }
                    main.post { callback(exts) }
                },
                { e ->
                    Log.e(TAG, "Erro ao listar extensões", e)
                    main.post { callback(emptyList()) }
                }
            )
        } catch (t: Throwable) {
            Log.e(TAG, "Erro ao listar extensões", t)
            callback(emptyList())
        }
    }

    /** O Gecko já entregou um botão de ação (browser_action/action) para esta extensão? */
    fun hasAction(ext: WebExtension): Boolean = actions[ext.id]?.let { it.enabled != false } ?: false

    fun isEnabled(ext: WebExtension): Boolean = try { ext.metaData?.enabled != false } catch (_: Throwable) { true }

    /** O Gecko normalmente já traz isto de options_ui.page/options_page; se vier vazio, usa o que foi lido na importação. */
    fun optionsUrl(ext: WebExtension): String? = try {
        ext.metaData?.optionsPageUrl?.takeIf { it.isNotBlank() } ?: optionsUrlFallback(ext)
    } catch (_: Throwable) { optionsUrlFallback(ext) }

    private fun optionsUrlFallback(ext: WebExtension): String? = try {
        val path = app.getSharedPreferences(OPTIONS_PREFS, Context.MODE_PRIVATE).getString(ext.id, null)
        val base = ext.metaData?.baseUrl
        if (path.isNullOrBlank() || base.isNullOrBlank()) null
        else base.trimEnd('/') + "/" + path.trimStart('/')
    } catch (_: Throwable) { null }

    /**
     * EXPERIMENTAL: o GeckoView não desenha painel lateral nativo (nem sidebar_action do Firefox, nem
     * side_panel do Manifest V3/Chrome). Para extensões importadas por este app, o manifest é lido na
     * importação (ExtensionManager) e a página do painel é guardada aqui; abrir o painel vira abrir essa
     * página em nova aba, como o popup.
     */
    fun sidebarUrl(ext: WebExtension): String? = try {
        val path = app.getSharedPreferences(SIDEBAR_PREFS, Context.MODE_PRIVATE).getString(ext.id, null)
        val base = ext.metaData?.baseUrl
        if (path.isNullOrBlank() || base.isNullOrBlank()) null
        else base.trimEnd('/') + "/" + path.trimStart('/')
    } catch (_: Throwable) { null }

    /** popup.html declarado no manifest (só conhecido para extensões importadas por este app). */
    fun popupUrl(ext: WebExtension): String? = try {
        val path = app.getSharedPreferences(POPUP_PREFS, Context.MODE_PRIVATE).getString(ext.id, null)
        val base = ext.metaData?.baseUrl
        if (path.isNullOrBlank() || base.isNullOrBlank()) null
        else base.trimEnd('/') + "/" + path.trimStart('/')
    } catch (_: Throwable) { null }

    fun rememberPopup(extensionId: String, popupPath: String?) {
        try {
            val e = app.getSharedPreferences(POPUP_PREFS, Context.MODE_PRIVATE).edit()
            if (popupPath.isNullOrBlank()) e.remove(extensionId) else e.putString(extensionId, popupPath)
            e.apply()
        } catch (t: Throwable) { Log.w(TAG, "popup não salvo", t) }
    }

    fun rememberOptions(extensionId: String, optionsPath: String?) {
        try {
            val e = app.getSharedPreferences(OPTIONS_PREFS, Context.MODE_PRIVATE).edit()
            if (optionsPath.isNullOrBlank()) e.remove(extensionId) else e.putString(extensionId, optionsPath)
            e.apply()
        } catch (t: Throwable) { Log.w(TAG, "página de opções não salva", t) }
    }

    fun rememberSidebar(extensionId: String, panelPath: String?) {
        try {
            val e = app.getSharedPreferences(SIDEBAR_PREFS, Context.MODE_PRIVATE).edit()
            if (panelPath.isNullOrBlank()) e.remove(extensionId) else e.putString(extensionId, panelPath)
            e.apply()
        } catch (t: Throwable) { Log.w(TAG, "sidebar não salva", t) }
    }

    /** Ícone da barra (ação) ou, se não houver, o ícone da extensão. */
    fun loadIcon(ext: WebExtension, sizePx: Int, callback: (Bitmap?) -> Unit) {
        try {
            val image = actions[ext.id]?.icon ?: ext.metaData?.icon
            if (image == null) { callback(null); return }
            image.getBitmap(sizePx).accept(
                { bmp -> main.post { callback(bmp) } },
                { main.post { callback(null) } }
            )
        } catch (t: Throwable) {
            callback(null)
        }
    }

    // ---------- ações ----------

    /**
     * Clica no botão da extensão e só avisa sucesso quando algo realmente abriu: o Gecko pediu o popup
     * (onOpenPopup/onTogglePopup criou a aba), ou, se o Gecko nunca pede (ação sem default_popup no
     * manifest — comum em extensões que só reagem a onClicked, como as que usam o side panel do Chrome),
     * abre o popup.html conhecido do manifest como alternativa. Sem nenhum dos dois, devolve false de
     * verdade: antes isto devolvia true só porque click() não deu erro, mesmo sem nada ter aberto, e quem
     * chamava (a tela de Extensões) fechava achando que tinha funcionado.
     */
    fun openPopup(ext: WebExtension, done: (Boolean) -> Unit) {
        lastFailure = null
        val a = actions[ext.id]
        val fallback = popupUrl(ext)
        if (a == null || a.enabled == false) {
            lastFailure = if (a == null) "o Gecko não entregou o botão desta extensão" else "o botão da extensão está desativado"
            Log.w(TAG, "openPopup: sem ação utilizável ext=${ext.id} action=${a != null} enabled=${a?.enabled}")
            done(if (fallback != null) { Log.i(TAG, "openPopup: abrindo $fallback direto"); openUrl(fallback) } else false)
            return
        }
        val t0 = System.currentTimeMillis()
        try {
            Log.i(TAG, "openPopup: click() ext=${ext.id}")
            a.click()
        } catch (t: Throwable) {
            lastFailure = "erro ao clicar: ${t.javaClass.simpleName}: ${t.message}"
            Log.e(TAG, "Erro ao clicar na ação de ${ext.id}", t)
            done(false)
            return
        }
        awaitPopupOutcome(ext, t0, fallback, 0, done)
    }

    private fun awaitPopupOutcome(ext: WebExtension, t0: Long, fallback: String?, attempt: Int, done: (Boolean) -> Unit) {
        if ((popupRequestedAt[ext.id] ?: 0L) >= t0) { done(true); return }
        if (attempt * POPUP_POLL_MS >= POPUP_FALLBACK_MS) {
            if (fallback != null) {
                Log.w(TAG, "Gecko não pediu o popup de ${ext.id}; fallback $fallback")
                done(openUrl(fallback))
            } else {
                lastFailure = "a extensão não pediu popup depois do clique (ação sem default_popup no manifest)"
                Log.w(TAG, "openPopup: ${ext.id} não pediu popup e não há fallback conhecido")
                done(false)
            }
            return
        }
        main.postDelayed({ awaitPopupOutcome(ext, t0, fallback, attempt + 1, done) }, POPUP_POLL_MS)
    }

    /** Página de opções em nova aba. */
    fun openOptions(ext: WebExtension): Boolean {
        val url = optionsUrl(ext) ?: return false
        return openUrl(url)
    }

    /** Painel lateral (experimental) em nova aba. */
    fun openSidebar(ext: WebExtension): Boolean {
        val url = sidebarUrl(ext) ?: return false
        return openUrl(url)
    }

    /**
     * Ponto único para "abrir a extensão": tenta na ordem popup → opções → painel lateral, e só avança
     * para a próxima quando a anterior realmente não abriu nada (ver [openPopup]). Cobre mais extensões
     * que os cartões fixos da tela de Extensões, porque não depende de saber de antemão qual interface a
     * extensão tem. Chama [done] com false só se nenhuma existir; aí [lastFailure] explica o motivo.
     */
    fun openAnyUi(ext: WebExtension, done: (Boolean) -> Unit) {
        openPopup(ext) { popupOk ->
            if (popupOk) { done(true); return@openPopup }
            val popupFailure = lastFailure
            if (openOptions(ext)) { lastFailure = null; done(true); return@openPopup }
            if (openSidebar(ext)) { lastFailure = null; done(true); return@openPopup }
            lastFailure = popupFailure ?: "sem popup, opções ou painel lateral conhecidos"
            done(false)
        }
    }

    fun openAddons(): Boolean = openUrl("about:addons")

    /** Abre [url] em nova aba. Sem MainActivity viva, pede a ela por Intent (open_url_new_tab). */
    private fun openUrl(url: String): Boolean = try {
        val host = tabHost
        if (host != null) {
            main.post { runCatching { host.openUrl(url) }.onFailure { Log.e(TAG, "Erro ao abrir aba", it) } }
        } else {
            app.startActivity(
                Intent(app, com.eternal.browser.MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra(EXTRA_OPEN_URL_NEW_TAB, url)
            )
        }
        true
    } catch (t: Throwable) {
        Log.e(TAG, "Erro ao abrir $url em nova aba", t)
        false
    }

    fun setEnabled(ext: WebExtension, enabled: Boolean, done: (Boolean) -> Unit) {
        try {
            val r = if (enabled) controller.enable(ext, WebExtensionController.EnableSource.USER)
            else controller.disable(ext, WebExtensionController.EnableSource.USER)
            r.accept(
                { main.post { notifyChanged(); done(true) } },
                { e -> Log.e(TAG, "Erro ao alternar extensão", e); main.post { done(false) } }
            )
        } catch (t: Throwable) {
            Log.e(TAG, "Erro ao alternar extensão", t)
            done(false)
        }
    }

    fun uninstall(ext: WebExtension, done: (Boolean) -> Unit) {
        try {
            controller.uninstall(ext).accept(
                {
                    rememberSidebar(ext.id, null)
                    rememberPopup(ext.id, null)
                    rememberOptions(ext.id, null)
                    main.post { notifyChanged(); done(true) }
                },
                { e -> Log.e(TAG, "Erro ao desinstalar", e); main.post { done(false) } }
            )
        } catch (t: Throwable) {
            Log.e(TAG, "Erro ao desinstalar", t)
            done(false)
        }
    }
}
