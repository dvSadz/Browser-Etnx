package com.eternal.browser.features.settings.sections

import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.PrefsKeys
import com.eternal.browser.core.storage.Prefs
object PrivacySection {
    fun build(prefs: Prefs) = SettingSection("PRIVACIDADE", listOf(
        SettingItem.Toggle(PrefsKeys.GPC, "Sinal Global Privacy Control", "Solicita aos sites que respeitem sua privacidade", false, restart = true),
        SettingItem.Toggle(PrefsKeys.SAFE_MODE, "Modo seguro", "Desativa o processo de extensões após reiniciar", false, restart = true),
        SettingItem.Info("Proteção contra rastreamento", "A proteção nativa do GeckoView permanece ativa no nível estrito; controles avançados por categoria ainda não são expostos."),
    ))
}
