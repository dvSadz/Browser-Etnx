package com.eternal.browser.features.settings

import com.eternal.browser.features.settings.sections.AboutSection
import com.eternal.browser.features.settings.sections.AccessibilitySection
import com.eternal.browser.features.settings.sections.AdvancedSection
import com.eternal.browser.features.settings.sections.AppearanceSection
import com.eternal.browser.features.settings.sections.BrowsingSection
import com.eternal.browser.features.settings.sections.DeveloperSection
import com.eternal.browser.features.settings.sections.DownloadsSection
import com.eternal.browser.features.settings.sections.ExtensionsSection
import com.eternal.browser.features.settings.sections.LanguageRegionSection
import com.eternal.browser.features.settings.sections.NotificationsSection
import com.eternal.browser.features.settings.sections.PrivacySection
import com.eternal.browser.features.settings.sections.SearchSection
import com.eternal.browser.features.settings.sections.SearchWallpaperSection
import com.eternal.browser.features.settings.sections.SyncBackupSection
import com.eternal.browser.features.settings.sections.TabsSection

import com.eternal.browser.core.storage.Prefs
/** Modelo das linhas suportadas pela tela de Configurações. */
sealed class SettingItem(val title: String, val subtitle: String?) {
    /** Liga/desliga. [restart] indica que o GeckoRuntime precisa ser recriado. */
    class Toggle(
        val key: String, title: String, subtitle: String?,
        val default: Boolean, val restart: Boolean = false,
    ) : SettingItem(title, subtitle)

    /** Valor enumerado. O par guarda o valor persistido e o rótulo apresentado. */
    class Choice(
        val key: String, title: String, subtitle: String?,
        val options: List<Pair<String, String>>, val default: String, val restart: Boolean = false,
    ) : SettingItem(title, subtitle)

    /** Controle numérico inteiro, por exemplo brilho/contraste em porcentagem. */
    class Range(
        val key: String, title: String, subtitle: String?,
        val min: Int, val max: Int, val default: Int, val unit: String = "",
    ) : SettingItem(title, subtitle)

    /** Campo de texto editado em diálogo. */
    class TextInput(
        val key: String, title: String, subtitle: String?,
        val hint: String, val default: String,
    ) : SettingItem(title, subtitle)

    /** Ação executada pela SettingsActivity. */
    class Action(val id: String, title: String, subtitle: String?) : SettingItem(title, subtitle)

    /** Informação de suporte/limitação; não se apresenta como uma configuração ativa. */
    class Info(title: String, subtitle: String) : SettingItem(title, subtitle)
}

class SettingSection(val title: String, val items: List<SettingItem>)

/** Registro central; UI, busca, exportação/importação e reset usam a mesma lista. */
object SettingsRegistry {
    fun sections(prefs: Prefs): List<SettingSection> = listOf(
        AppearanceSection.build(prefs),
        SearchWallpaperSection.build(prefs),
        SearchSection.build(prefs),
        PrivacySection.build(prefs),
        BrowsingSection.build(prefs),
        TabsSection.build(prefs),
        ExtensionsSection.build(prefs),
        DownloadsSection.build(prefs),
        AccessibilitySection.build(prefs),
        LanguageRegionSection.build(prefs),
        DeveloperSection.build(prefs),
        SyncBackupSection.build(prefs),
        NotificationsSection.build(prefs),
        AdvancedSection.build(prefs),
        AboutSection.build(prefs),
    )

    /** Itens que possuem valor persistido e podem ser exportados, importados ou redefinidos. */
    fun stored(prefs: Prefs): List<SettingItem> = sections(prefs).flatMap { it.items }.filter {
        it is SettingItem.Toggle || it is SettingItem.Choice || it is SettingItem.Range || it is SettingItem.TextInput
    }

    fun keyOf(item: SettingItem): String? = when (item) {
        is SettingItem.Toggle -> item.key
        is SettingItem.Choice -> item.key
        is SettingItem.Range -> item.key
        is SettingItem.TextInput -> item.key
        is SettingItem.Action, is SettingItem.Info -> null
    }
}
