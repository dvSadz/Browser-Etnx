package com.eternal.browser.core.storage

/** Chaves estáveis do arquivo de preferências existente ("eternal"). */
object PrefsKeys {
    const val BAR_BOTTOM = "bar_bottom"
    const val NIGHT_MODE = "night_mode"
    const val NIGHT_BRIGHTNESS = "night_brightness"
    const val NIGHT_CONTRAST = "night_contrast"
    const val SEARCH_ENGINE = "search_engine"
    const val CUSTOM_SEARCH_URL = "custom_search_url"
    const val SAVED_TABS = "saved_tabs"
    const val SAVED_SELECTED = "saved_selected"
    const val NAV_BREADCRUMB = "nav_breadcrumb"
    const val LAST_EXIT_REPORTED = "last_exit_reported"
    const val SAFE_MODE = "safe_mode"
    const val START_PENDING = "start_pending"
    const val SAFE_MODE_RESET = "safe_mode_reset"
    const val DEV_ACCEPTED = "dev_accepted"
    const val REMOTE_DEBUG = "remote_debug"
    const val RESTORE_TABS = "restore_tabs"
    const val DOWNLOAD_NOTIFICATIONS = "download_notifications"
    const val GPC = "gpc"
    const val JS_ENABLED = "js_enabled"
    const val WEB_FONTS = "web_fonts"
    const val DOUBLE_TAP_ZOOM = "double_tap_zoom"
    const val FORCE_ZOOM = "force_zoom"
    const val INPUT_AUTOZOOM = "input_autozoom"
    const val FONT_SCALE = "font_scale"
    const val LOCALE = "locale"
    const val ABOUT_CONFIG = "about_config"
    const val CONSOLE_OUTPUT = "console_output"

    // Wallpaper nas páginas de resultados de busca
    const val SEARCH_WALLPAPER_ENABLED = "search_wallpaper_enabled"
    const val SEARCH_WALLPAPER_URI = "search_wallpaper_uri"
    const val SEARCH_WALLPAPER_DIM = "search_wallpaper_dim"
}
