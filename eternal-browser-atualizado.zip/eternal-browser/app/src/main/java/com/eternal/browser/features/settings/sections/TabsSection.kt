package com.eternal.browser.features.settings.sections

import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.PrefsKeys
import com.eternal.browser.core.storage.Prefs
object TabsSection {
    fun build(prefs: Prefs) = SettingSection("ABAS", listOf(
        SettingItem.Toggle(PrefsKeys.RESTORE_TABS, "Restaurar abas ao abrir", "Restaura as abas da última sessão", true),
        SettingItem.Info("Gerenciador de abas", "Abas privadas não são restauradas. O seletor de abas fica na barra inferior."),
    ))
}
