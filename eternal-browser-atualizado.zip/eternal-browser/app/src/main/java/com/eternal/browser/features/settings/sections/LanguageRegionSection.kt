package com.eternal.browser.features.settings.sections

import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.PrefsKeys
import com.eternal.browser.core.storage.Prefs
object LanguageRegionSection {
    fun build(prefs: Prefs) = SettingSection("IDIOMA E REGIÃO", listOf(
        SettingItem.Choice(PrefsKeys.LOCALE, "Idioma preferido dos sites", "Enviado aos sites no cabeçalho Accept-Language",
            listOf("" to "Padrão do sistema", "pt-BR" to "Português (Brasil)", "en-US" to "English", "es" to "Español"), "", restart = true),
    ))
}
