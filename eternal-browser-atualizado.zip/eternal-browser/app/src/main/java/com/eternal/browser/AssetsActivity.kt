package com.eternal.browser

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.URLUtil

/** Lista imagens, CSS, JS, fontes, mídia e links da página e baixa os selecionados em Download/eternal_assets/<site>/<tipo>/. */
class AssetsActivity : ToolActivity() {
    private var url = ""
    private var found: HtmlScan.Found? = null
    private var kind = "all"
    private val selected = LinkedHashSet<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        url = intent.getStringExtra("url") ?: ""
        setTitleText("Extrair assets")
        setStatus(url)
        setAction1("Marcar tudo") { markAll() }
        setPrimary("Baixar selecionados") { download() }
        for ((label, k) in listOf("Todos" to "all", "Imagens" to "img", "CSS" to "css", "JS" to "js", "Fontes" to "font", "Vídeos" to "media", "Links" to "link")) {
            addChip(label) { kind = k; render() }
        }
        onRowCheck = { row, checked -> (row.tag as? String)?.let { if (checked) selected.add(it) else selected.remove(it) } }
        showMessage("Analisando a página…")
        io.execute {
            try {
                val page = Net.text(Net.get(url, 5_000_000))
                found = HtmlScan.scan(page, url)
                ui { render() }
            } catch (t: Throwable) {
                ui { showMessage("Erro ao carregar: ${t.message}") }
            }
        }
    }

    private fun items(): List<Pair<String, String>> {
        val f = found ?: return emptyList()
        fun tag(list: List<String>, k: String) = list.map { it to k }
        return when (kind) {
            "img" -> tag(f.images, "imagens")
            "css" -> tag(f.css, "css")
            "js" -> tag(f.js, "js")
            "font" -> tag(f.fonts, "fontes")
            "media" -> tag(f.media, "videos")
            "link" -> tag(f.links, "links")
            else -> tag(f.images, "imagens") + tag(f.css, "css") + tag(f.js, "js") + tag(f.fonts, "fontes") + tag(f.media, "videos") + tag(f.links, "links")
        }
    }

    private fun render() {
        val f = found ?: return
        setStatus("Encontrados: ${f.images.size} imagens, ${f.css.size} CSS, ${f.js.size} JS, ${f.fonts.size} fontes, ${f.media.size} vídeos, ${f.links.size} links")
        showRows(
            items().map { (u, k) -> ToolRow(UrlUtils.display(u).ifBlank { u }, k, checkable = true, checked = u in selected, tag = u) },
            "Nada encontrado nesta categoria."
        )
    }

    private fun markAll() {
        val list = items().map { it.first }
        if (list.all { it in selected }) selected.removeAll(list.toSet()) else selected.addAll(list)
        render()
    }

    private fun download() {
        if (selected.isEmpty()) { toast("Marque ao menos um item"); return }
        val kinds = items().toMap()
        val allKinds = HashMap<String, String>()
        found?.let { f ->
            f.images.forEach { allKinds[it] = "imagens" }; f.css.forEach { allKinds[it] = "css" }; f.js.forEach { allKinds[it] = "js" }
            f.fonts.forEach { allKinds[it] = "fontes" }; f.media.forEach { allKinds[it] = "videos" }; f.links.forEach { allKinds[it] = "links" }
        }
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val host = hostOf(url)
        var ok = 0
        for (u in selected) {
            try {
                val k = kinds[u] ?: allKinds[u] ?: "outros"
                val name = URLUtil.guessFileName(u, null, null)
                val req = DownloadManager.Request(Uri.parse(u))
                    .setTitle(name)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "eternal_assets/$host/$k/$name")
                dm.enqueue(req); ok++
            } catch (t: Throwable) { /* um item ruim não cancela os demais */ }
        }
        toast("$ok download(s) iniciados em Download/eternal_assets/$host/")
    }
}
