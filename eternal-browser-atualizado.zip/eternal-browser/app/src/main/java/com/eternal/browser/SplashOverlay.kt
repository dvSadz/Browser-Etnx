package com.eternal.browser

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import java.util.Calendar

/**
 * Abertura animada: E pequeno com halo pulsante, nome, saudação, barra fina de loading e status. Cobre a tela até a primeira página carregar (mínimo ~1,7 s, máximo 7 s).
 */
class SplashOverlay private constructor(private val view: View) {

    companion object {
        private const val MIN_SHOW_MS = 1700L
        private const val MAX_SHOW_MS = 7000L

        fun show(activity: Activity): SplashOverlay {
            val v = LayoutInflater.from(activity).inflate(R.layout.view_splash, null)
            activity.addContentView(
                v,
                ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
            )
            return SplashOverlay(v).also { it.start() }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val startedAt = SystemClock.uptimeMillis()
    private var dismissed = false
    private var pageReady = false
    private var pulse: ObjectAnimator? = null
    private var statusIndex = 0

    private val status: TextView = view.findViewById(R.id.splashStatus)

    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            h < 5 -> "Boa madrugada"
            h < 12 -> "Bom dia"
            h < 18 -> "Boa tarde"
            else -> "Boa noite"
        }
    }

    private fun start() {
        val density = view.resources.displayMetrics.density
        val glow: View = view.findViewById(R.id.splashGlow)
        val icon: View = view.findViewById(R.id.splashIconCard)
        val title: View = view.findViewById(R.id.splashTitle)
        val subtitle: TextView = view.findViewById(R.id.splashSubtitle)
        val bar: View = view.findViewById(R.id.splashBar)

        subtitle.text = greeting()

        // estado inicial
        glow.alpha = 0f; glow.scaleX = 0.6f; glow.scaleY = 0.6f
        icon.alpha = 0f; icon.scaleX = 0.55f; icon.scaleY = 0.55f
        val risers = listOf(title, subtitle, bar, status)
        risers.forEach { it.alpha = 0f; it.translationY = 14f * density }

        // entradas em sequência
        glow.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(900)
            .setInterpolator(DecelerateInterpolator()).start()
        icon.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).setStartDelay(100)
            .setInterpolator(OvershootInterpolator(1.4f)).start()
        val delays = longArrayOf(450, 600, 750, 850)
        risers.forEachIndexed { i, t ->
            t.animate().alpha(1f).translationY(0f).setDuration(450).setStartDelay(delays[i])
                .setInterpolator(DecelerateInterpolator()).start()
        }

        // brilho pulsando enquanto carrega
        pulse = ObjectAnimator.ofPropertyValuesHolder(
            glow,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.12f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.12f),
        ).apply {
            duration = 1400
            startDelay = 1000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }

        handler.postDelayed(statusTick, 1700)
        handler.postDelayed({ hide() }, MAX_SHOW_MS) // segurança: nunca prende o usuário na abertura
    }

    private val statusTick = object : Runnable {
        override fun run() {
            if (dismissed) return
            val texts = arrayOf(
                view.context.getString(R.string.splash_status_1),
                view.context.getString(R.string.splash_status_2),
                view.context.getString(R.string.splash_status_3),
            )
            statusIndex = (statusIndex + 1) % texts.size
            status.animate().alpha(0f).setDuration(150).withEndAction {
                if (dismissed) return@withEndAction
                status.text = texts[statusIndex]
                status.animate().alpha(1f).setDuration(150).start()
            }.start()
            handler.postDelayed(this, 1100)
        }
    }

    /** Chamado quando a primeira página terminou de carregar. */
    fun onPageReady() {
        if (pageReady || dismissed) return
        pageReady = true
        val wait = (MIN_SHOW_MS - (SystemClock.uptimeMillis() - startedAt)).coerceAtLeast(0L)
        handler.postDelayed({ hide() }, wait + 120) // 120 ms para a página inicial pintar por baixo
    }

    private fun hide() {
        if (dismissed) return
        dismissed = true
        handler.removeCallbacksAndMessages(null)
        pulse?.cancel()
        status.animate().cancel()
        status.alpha = 1f
        status.text = view.context.getString(R.string.splash_ready)
        view.animate().alpha(0f).scaleX(1.06f).scaleY(1.06f).setDuration(380).setStartDelay(150)
            .withEndAction { (view.parent as? ViewGroup)?.removeView(view) }
            .start()
    }

    /** Ao destruir a Activity: para tudo e solta a view. */
    fun cancel() {
        dismissed = true
        handler.removeCallbacksAndMessages(null)
        pulse?.cancel()
        view.animate().cancel()
        (view.parent as? ViewGroup)?.removeView(view)
    }
}
