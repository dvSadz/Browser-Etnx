package com.eternal.browser.features.settings.sections

import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.PrefsKeys
import com.eternal.browser.core.storage.Prefs
object DownloadsSection {
    fun build(prefs: Prefs) = SettingSection("DOWNLOADS", listOf(
        SettingItem.Toggle(PrefsKeys.DOWNLOAD_NOTIFICATIONS, "Notificar ao concluir", "Controla a notificação do gerenciador de downloads do Android", true),
        SettingItem.Action("open_downloads", "Abrir downloads", "Exibe a lista gerenciada pelo Android"),
    ))
}
