package com.eternal.browser.extensions

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Window
import android.view.WindowManager
import com.eternal.browser.R

/** Mini popup de loading no centro da tela (sem bloquear o botão voltar por mais de alguns instantes). */
class LoadingPopup(private val activity: Activity) {
    private var dialog: Dialog? = null

    fun show() {
        if (dialog?.isShowing == true || activity.isFinishing || activity.isDestroyed) return
        val d = Dialog(activity)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.setContentView(LayoutInflater.from(activity).inflate(R.layout.dialog_loading, null))
        d.setCancelable(false)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
            setDimAmount(0.55f)
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        }
        d.show()
        dialog = d
    }

    fun dismiss() {
        runCatching { dialog?.dismiss() }
        dialog = null
    }
}
