package com.eternal.browser.features.settings.sections

import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.Prefs
object ExtensionsSection {
    fun build(prefs: Prefs) = SettingSection("EXTENSÕES", listOf(
        SettingItem.Info("Gerenciamento de extensões", "Use o menu principal → Extensões para listar, ativar ou remover extensões."),
        SettingItem.Action("extension_help", "Ajuda para instalar extensões", "Importe um arquivo .zip ou informe uma URL (extensões Manifest V3)"),
    ))
}
