package com.eternal.browser.features.settings.sections

import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.PrefsKeys
import com.eternal.browser.core.storage.Prefs
object SearchSection {
    fun build(prefs: Prefs) = SettingSection("PESQUISA", listOf(
        SettingItem.Choice(PrefsKeys.SEARCH_ENGINE, "Mecanismo de busca", "Usado ao digitar termos na barra", prefs.searchEngines.keys.map { it to it }, "Google"),
        SettingItem.TextInput(PrefsKeys.CUSTOM_SEARCH_URL, "URL de busca personalizada", "Selecione Custom para usar este endereço", "Ex.: https://exemplo.com/?q={query}", prefs.searchEngines.getValue("Custom")),
    ))
}
