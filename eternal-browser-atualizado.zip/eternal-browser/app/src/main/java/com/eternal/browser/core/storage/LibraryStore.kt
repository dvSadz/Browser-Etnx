package com.eternal.browser.core.storage

import android.content.Context
import com.eternal.browser.core.storage.PrefsManager
import org.json.JSONArray
import org.json.JSONObject

data class Entry(val title: String, val url: String, val time: Long)

/** Lista persistente (mais recente primeiro) de favoritos ou histórico, guardada como JSON. */
class LibraryStore(context: Context, private val key: String, private val max: Int) {
    private val storage = PrefsManager(context, "eternal_library")

    fun all(): List<Entry> = try {
        val a = JSONArray(storage.getString(key, "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Entry(o.optString("t"), o.getString("u"), o.optLong("d"))
        }
    } catch (_: Throwable) { emptyList() }

    private fun save(list: List<Entry>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("t", it.title).put("u", it.url).put("d", it.time)) }
        storage.setString(key, a.toString(), commit = false)
    }

    fun contains(url: String) = all().any { it.url == url }

    fun add(title: String, url: String) {
        val rest = all().filter { it.url != url }
        save((listOf(Entry(title, url, System.currentTimeMillis())) + rest).take(max))
    }

    fun remove(url: String) = save(all().filter { it.url != url })

    fun clear() = storage.removeKeys(listOf(key))
}
