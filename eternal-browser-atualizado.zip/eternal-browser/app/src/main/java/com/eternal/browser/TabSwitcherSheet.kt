package com.eternal.browser

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog

import com.eternal.browser.core.engine.TabManager
import com.eternal.browser.core.engine.Tab
/** Seletor de abas em bottom sheet, com animação de entrada dos itens. */
class TabSwitcherSheet(
    private val activity: AppCompatActivity,
    private val tabManager: TabManager,
) {
    fun show() {
        val dialog = BottomSheetDialog(activity)
        val view = LayoutInflater.from(activity).inflate(R.layout.sheet_tabs, null)
        val list = view.findViewById<RecyclerView>(R.id.tabList)
        val adapter = TabAdapter(
            onSelect = { tabManager.select(it); dialog.dismiss() },
            onClose = { tab, pos ->
                val before = tabManager.tabs.size
                tabManager.close(tab)
                if (tabManager.tabs.size < before) (list.adapter as TabAdapter).notifyItemRemoved(pos)
                else list.adapter?.notifyDataSetChanged()
                view.findViewById<TextView>(R.id.tabsTitle).text =
                    activity.getString(R.string.tabs_title, tabManager.tabs.size)
            },
        )
        list.layoutManager = LinearLayoutManager(activity)
        list.adapter = adapter
        view.findViewById<TextView>(R.id.tabsTitle).text =
            activity.getString(R.string.tabs_title, tabManager.tabs.size)
        view.findViewById<View>(R.id.newTabButton).setOnClickListener {
            tabManager.openTab(); dialog.dismiss()
        }
        dialog.setContentView(view)
        dialog.show()
    }

    private inner class TabAdapter(
        val onSelect: (Tab) -> Unit,
        val onClose: (Tab, Int) -> Unit,
    ) : RecyclerView.Adapter<TabAdapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val title: TextView = v.findViewById(R.id.itemTitle)
            val url: TextView = v.findViewById(R.id.itemUrl)
            val close: ImageButton = v.findViewById(R.id.itemClose)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_tab, parent, false))

        override fun getItemCount() = tabManager.tabs.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val tab = tabManager.tabs[position]
            h.title.text = tab.title.ifBlank { activity.getString(R.string.new_tab) }
            h.url.text = (if (tab.isPrivate) activity.getString(R.string.private_label) + " · " else "") +
                UrlUtils.display(tab.url).ifBlank { "ETERNAL" }
            h.itemView.isActivated = tab === tabManager.current
            h.itemView.alpha = 0f
            h.itemView.translationY = 40f
            h.itemView.animate().alpha(1f).translationY(0f).setDuration(220)
                .setStartDelay((position * 30L).coerceAtMost(240)).start()
            h.itemView.setOnClickListener { onSelect(tab) }
            h.close.setOnClickListener { onClose(tab, h.bindingAdapterPosition) }
        }
    }
}
