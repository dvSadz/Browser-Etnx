package com.eternal.browser.features.settings.sections

import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.PrefsKeys
import com.eternal.browser.core.storage.Prefs
object BrowsingSection {
    fun build(prefs: Prefs) = SettingSection("NAVEGAÇÃO", listOf(
        SettingItem.Toggle(PrefsKeys.JS_ENABLED, "JavaScript", "Desativar pode impedir páginas de funcionar", true, restart = true),
        SettingItem.Toggle(PrefsKeys.WEB_FONTS, "Fontes da web", "Permite fontes fornecidas pelos sites", true, restart = true),
        SettingItem.Toggle(PrefsKeys.DOUBLE_TAP_ZOOM, "Zoom com toque duplo", null, true, restart = true),
        SettingItem.Toggle(PrefsKeys.INPUT_AUTOZOOM, "Ampliar campos de formulário", null, true, restart = true),
    ))
}
