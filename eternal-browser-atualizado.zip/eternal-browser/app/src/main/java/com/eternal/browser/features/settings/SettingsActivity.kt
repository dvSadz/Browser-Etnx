package com.eternal.browser.features.settings

import android.animation.LayoutTransition
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import com.eternal.browser.SearchWallpaperManager
import com.eternal.browser.features.settings.sections.SearchWallpaperSection
import java.util.concurrent.Executors
import android.app.DownloadManager
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.slider.Slider
import com.google.android.material.snackbar.Snackbar
import org.json.JSONObject

import com.eternal.browser.BuildConfig
import com.eternal.browser.R
import com.eternal.browser.core.storage.PrefsKeys
import com.eternal.browser.core.storage.Prefs
/** Configurações do ETERNAL: 14 categorias, filtro em tempo real, persistência e backup JSON. */
class SettingsActivity : AppCompatActivity() {
    private lateinit var prefs: Prefs
    private lateinit var content: LinearLayout
    private lateinit var root: LinearLayout
    private var query = ""
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    /** Seletor de imagem do wallpaper (ACTION_OPEN_DOCUMENT permite guardar a permissão de leitura). */
    private val wallpaperPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onWallpaperPicked(uri)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.eternal_background))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(16), dp(8))
        }
        top.addView(TextView(this).apply {
            text = "←"
            setTextColor(getColor(R.color.eternal_text))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(4), dp(12), dp(4))
            contentDescription = "Voltar"
            setOnClickListener { finish() }
        })
        top.addView(TextView(this).apply {
            text = "Configurações"
            setTextColor(getColor(R.color.eternal_text))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        root.addView(top)

        val search = EditText(this).apply {
            hint = "Buscar configurações"
            setHintTextColor(getColor(R.color.eternal_text_tertiary))
            setTextColor(getColor(R.color.eternal_text))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setSingleLine(true)
            setBackgroundResource(R.drawable.bg_settings_card)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            contentDescription = "Buscar configurações"
            doAfterTextChanged { query = it?.toString().orEmpty().trim(); render() }
        }
        root.addView(search, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
        ).apply { setMargins(dp(16), dp(4), dp(16), dp(8)) })

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(32))
            layoutTransition = LayoutTransition().apply { setDuration(220) }
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            addView(content)
        }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        render()
    }

    private fun matches(section: SettingSection, item: SettingItem): Boolean {
        if (query.isEmpty()) return true
        val q = query.lowercase()
        if (section.title.lowercase().contains(q) || item.title.lowercase().contains(q) ||
            item.subtitle?.lowercase()?.contains(q) == true
        ) return true
        return when (item) {
            is SettingItem.Choice -> item.options.any { it.second.lowercase().contains(q) || it.first.lowercase().contains(q) }
            is SettingItem.TextInput -> prefs.getStr(item.key, item.default).lowercase().contains(q)
            else -> false
        }
    }

    private fun render() {
        content.removeAllViews()
        var shown = 0
        for (section in SettingsRegistry.sections(prefs)) {
            val items = section.items.filter { matches(section, it) }
            if (items.isEmpty()) continue
            shown += items.size
            content.addView(TextView(this).apply {
                text = section.title
                setTextColor(getColor(R.color.eternal_text_tertiary))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                letterSpacing = 0.15f
                setPadding(dp(4), dp(16), dp(4), dp(8))
            })
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundResource(R.drawable.bg_settings_card)
                clipToOutline = true
            }
            items.forEachIndexed { i, item ->
                if (i > 0) card.addView(View(this).apply {
                    setBackgroundColor(getColor(R.color.eternal_stroke))
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply {
                    marginStart = dp(16)
                })
                card.addView(buildRow(item))
            }
            content.addView(card, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            ))
        }
        if (shown == 0) content.addView(TextView(this).apply {
            text = "Nada encontrado"
            setTextColor(getColor(R.color.eternal_text_secondary))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
            setPadding(0, dp(48), 0, 0)
        })
    }

    private fun buildRow(item: SettingItem): View {
        if (item is SettingItem.Range) return buildRangeRow(item)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(56)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            val tv = TypedValue()
            if (theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) setBackgroundResource(tv.resourceId)
        }
        val texts = makeTextBlock(item)
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        when (item) {
            is SettingItem.Toggle -> {
                val sw = SwitchCompat(this).apply { isChecked = prefs.getBool(item.key, item.default) }
                sw.setOnCheckedChangeListener { _, checked -> onToggle(item, checked) }
                row.addView(sw)
                row.setOnClickListener { sw.toggle() }
            }
            is SettingItem.Choice -> {
                val value = TextView(this).apply {
                    text = labelOf(item)
                    setTextColor(getColor(R.color.eternal_text_secondary))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    gravity = Gravity.END or Gravity.CENTER_VERTICAL
                    maxWidth = dp(150)
                    setPadding(dp(12), 0, 0, 0)
                }
                row.addView(value)
                row.setOnClickListener { pickChoice(item, value) }
            }
            is SettingItem.TextInput -> {
                val value = TextView(this).apply {
                    text = prefs.getStr(item.key, item.default).take(22)
                    setTextColor(getColor(R.color.eternal_text_secondary))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    maxWidth = dp(140)
                    setPadding(dp(12), 0, 0, 0)
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                row.addView(value)
                row.setOnClickListener { editTextValue(item) }
            }
            is SettingItem.Action -> {
                if (item.id == SearchWallpaperSection.ACTION_IMPORT) row.addView(wallpaperThumb())
                row.setOnClickListener { onAction(item) }
            }
            is SettingItem.Info -> Unit
            is SettingItem.Range -> Unit
        }
        return row
    }

    private fun makeTextBlock(item: SettingItem): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(TextView(this@SettingsActivity).apply {
            text = item.title
            setTextColor(getColor(R.color.eternal_text))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        })
        item.subtitle?.let { sub -> addView(TextView(this@SettingsActivity).apply {
            text = sub
            setTextColor(getColor(R.color.eternal_text_secondary))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        }) }
    }

    private fun buildRangeRow(item: SettingItem.Range): View {
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(8))
            minimumHeight = dp(84)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(makeTextBlock(item), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val valueText = TextView(this).apply {
            setTextColor(getColor(R.color.eternal_text_secondary))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.END
        }
        fun label(v: Int) = "$v${item.unit}"
        valueText.text = label(prefs.getInt(item.key, item.default).coerceIn(item.min, item.max))
        header.addView(valueText)
        column.addView(header)
        val slider = Slider(this).apply {
            valueFrom = item.min.toFloat()
            valueTo = item.max.toFloat()
            stepSize = 1f
            value = prefs.getInt(item.key, item.default).coerceIn(item.min, item.max).toFloat()
            contentDescription = item.title
        }
        slider.addOnChangeListener { _, v, fromUser ->
            if (fromUser) {
                val intValue = v.toInt().coerceIn(item.min, item.max)
                prefs.setInt(item.key, intValue)
                valueText.text = label(intValue)
            }
        }
        column.addView(slider)
        return column
    }

    private fun labelOf(item: SettingItem.Choice): String {
        val current = prefs.getStr(item.key, item.default)
        return item.options.firstOrNull { it.first == current }?.second ?: item.options.firstOrNull()?.second.orEmpty()
    }

    private fun onToggle(item: SettingItem.Toggle, checked: Boolean) {
        prefs.setBool(item.key, checked)
        if (item.restart) askRestart() else toastSaved()
    }

    private fun pickChoice(item: SettingItem.Choice, valueView: TextView) {
        val current = prefs.getStr(item.key, item.default)
        val checked = item.options.indexOfFirst { it.first == current }.coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle(item.title)
            .setSingleChoiceItems(item.options.map { it.second }.toTypedArray(), checked) { dialog, which ->
                prefs.setStr(item.key, item.options[which].first)
                valueView.text = item.options[which].second
                dialog.dismiss()
                if (item.restart) askRestart() else toastSaved()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun editTextValue(item: SettingItem.TextInput) {
        val input = EditText(this).apply {
            hint = item.hint
            setText(prefs.getStr(item.key, item.default))
            setSelection(text?.length ?: 0)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(item.title)
            .setView(input)
            .setPositiveButton("Salvar") { _, _ ->
                val value = input.text?.toString()?.trim().orEmpty()
                if (item.key == PrefsKeys.CUSTOM_SEARCH_URL && !isHttpUrl(value)) {
                    Snackbar.make(root, "Informe uma URL http:// ou https:// válida", Snackbar.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                prefs.setStr(item.key, value)
                render()
                toastSaved()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun isHttpUrl(value: String): Boolean = try {
        val uri = Uri.parse(value)
        value.length <= 2048 && uri.scheme in setOf("http", "https") && !uri.host.isNullOrBlank()
    } catch (_: Throwable) { false }

    private fun onAction(item: SettingItem.Action) {
        when (item.id) {
            SearchWallpaperSection.ACTION_IMPORT -> launchWallpaperPicker()
            SearchWallpaperSection.ACTION_RESTORE -> restoreDefaultWallpaper()
            "export" -> exportSettings()
            "import" -> importSettings()
            "reset" -> confirmReset()
            "restart" -> restartApp()
            "open_downloads" -> runCatching { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
                .onFailure { showInfo("Downloads", "Abra o aplicativo Arquivos para consultar os downloads.") }
            "notification_settings" -> runCatching {
                startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            }.onFailure { showInfo("Notificações", "Altere as notificações do ETERNAL nas configurações do Android.") }
            "extension_help" -> showInfo("Extensões", "Abra o menu principal do ETERNAL e escolha Extensões para gerenciar itens instalados. Para instalar, use Importar extensão para escolher um arquivo .zip, ou Instalar → Por URL. As extensões devem ser Manifest V3 (o padrão atual) e estar nesses dois formatos.")
            "licenses" -> showInfo("Sobre o ETERNAL", getString(R.string.about_text))
            "version" -> showInfo("ETERNAL ${BuildConfig.VERSION_NAME}", "Versão instalada do navegador.")
            else -> showInfo(item.title, item.subtitle.orEmpty())
        }
    }

    // ---------- wallpaper da pesquisa ----------

    /** Miniatura 120x68dp com borda de 1dp (#2A2A2A) do wallpaper atual; vazia se não há wallpaper. */
    private fun wallpaperThumb(): View {
        val w = dp(120)
        val h = dp(68)
        val thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                setColor(getColor(R.color.eternal_surface))
                setStroke(dp(1), getColor(R.color.eternal_stroke))
                cornerRadius = dp(8).toFloat()
            }
            contentDescription = "Wallpaper da pesquisa"
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(8).toFloat())
                }
            }
        }
        val uri = prefs.searchWallpaperUri
        if (uri.isNotBlank()) {
            val appContext = applicationContext
            io.execute {
                val bmp = SearchWallpaperManager.loadThumbnail(appContext, uri, w * 2, h * 2)
                ui.post { if (!isFinishing && !isDestroyed && bmp != null) thumb.setImageBitmap(bmp) }
            }
        }
        thumb.layoutParams = LinearLayout.LayoutParams(w, h).apply { marginStart = dp(12) }
        return thumb
    }

    private fun launchWallpaperPicker() {
        runCatching { wallpaperPicker.launch(arrayOf("image/*")) }
            .onFailure { Snackbar.make(root, "Não foi possível abrir o seletor de imagens", Snackbar.LENGTH_LONG).show() }
    }

    private fun onWallpaperPicked(uri: Uri) {
        // Mantém o acesso ao arquivo depois de reiniciar o app.
        val persisted = runCatching {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }.isSuccess
        val appContext = applicationContext
        io.execute {
            // Valida que é mesmo uma imagem legível antes de salvar.
            val ok = SearchWallpaperManager.loadThumbnail(appContext, uri.toString(), 64, 64) != null
            ui.post {
                if (isFinishing || isDestroyed) return@post
                if (!ok) {
                    runCatching { contentResolver.releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    Snackbar.make(root, "Não foi possível ler essa imagem", Snackbar.LENGTH_LONG).show()
                    return@post
                }
                releaseCurrentWallpaperPermission(except = uri.toString())
                prefs.searchWallpaperUri = uri.toString()
                render()
                Snackbar.make(
                    root,
                    if (persisted) "Wallpaper atualizado" else "Wallpaper atualizado (pode precisar ser escolhido de novo após reiniciar)",
                    Snackbar.LENGTH_SHORT,
                ).show()
            }
        }
    }

    private fun restoreDefaultWallpaper() {
        releaseCurrentWallpaperPermission(except = null)
        prefs.searchWallpaperUri = ""
        render()
        toastSaved()
    }

    private fun releaseCurrentWallpaperPermission(except: String?) {
        val old = prefs.searchWallpaperUri
        if (old.isBlank() || old == except) return
        runCatching { contentResolver.releasePersistableUriPermission(Uri.parse(old), Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        io.shutdown()
        super.onDestroy()
    }

    private fun showInfo(title: String, message: String) {
        MaterialAlertDialogBuilder(this).setTitle(title).setMessage(message)
            .setPositiveButton(android.R.string.ok, null).show()
    }

    private fun toastSaved() { Snackbar.make(root, "Salvo", Snackbar.LENGTH_SHORT).show() }

    private fun askRestart() {
        Snackbar.make(root, "Salvo. Reinicie para aplicar.", Snackbar.LENGTH_LONG)
            .setAction("Reiniciar") { restartApp() }
            .show()
    }

    private fun restartApp() {
        val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
        Runtime.getRuntime().exit(0)
    }

    private fun exportSettings() {
        val json = JSONObject()
        for (item in SettingsRegistry.stored(prefs)) {
            when (item) {
                is SettingItem.Toggle -> json.put(item.key, prefs.getBool(item.key, item.default))
                is SettingItem.Choice -> json.put(item.key, prefs.getStr(item.key, item.default))
                is SettingItem.Range -> json.put(item.key, prefs.getInt(item.key, item.default))
                is SettingItem.TextInput -> json.put(item.key, prefs.getStr(item.key, item.default))
                is SettingItem.Action, is SettingItem.Info -> Unit
            }
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_SUBJECT, "Configurações do ETERNAL")
            putExtra(Intent.EXTRA_TEXT, json.toString(2))
        }
        startActivity(Intent.createChooser(send, "Exportar configurações"))
    }

    private fun importSettings() {
        val input = EditText(this).apply {
            hint = "Cole aqui o JSON exportado"
            minLines = 5
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Importar configurações")
            .setView(input)
            .setPositiveButton("Importar") { _, _ -> applyImport(input.text?.toString().orEmpty()) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun applyImport(text: String) {
        try {
            val json = JSONObject(text)
            var count = 0
            for (item in SettingsRegistry.stored(prefs)) {
                if (!json.has(item.key())) continue
                when (item) {
                    is SettingItem.Toggle -> { prefs.setBool(item.key, json.getBoolean(item.key)); count++ }
                    is SettingItem.Choice -> {
                        val value = json.getString(item.key)
                        if (item.options.any { it.first == value }) { prefs.setStr(item.key, value); count++ }
                    }
                    is SettingItem.Range -> {
                        val value = json.getInt(item.key).coerceIn(item.min, item.max)
                        prefs.setInt(item.key, value); count++
                    }
                    is SettingItem.TextInput -> {
                        val value = json.getString(item.key).take(2048)
                        if (item.key != PrefsKeys.CUSTOM_SEARCH_URL || isHttpUrl(value)) { prefs.setStr(item.key, value); count++ }
                    }
                    is SettingItem.Action, is SettingItem.Info -> Unit
                }
            }
            render()
            Snackbar.make(root, "$count configurações importadas. Reinicie para aplicar as opções do motor.", Snackbar.LENGTH_LONG)
                .setAction("Reiniciar") { restartApp() }
                .show()
        } catch (_: Throwable) {
            Snackbar.make(root, "JSON inválido ou incompatível", Snackbar.LENGTH_LONG).show()
        }
    }

    private fun SettingItem.key(): String = when (this) {
        is SettingItem.Toggle -> key
        is SettingItem.Choice -> key
        is SettingItem.Range -> key
        is SettingItem.TextInput -> key
        is SettingItem.Action, is SettingItem.Info -> ""
    }

    private fun confirmReset() {
        val check = CheckBox(this).apply {
            text = "Tenho certeza"
            setTextColor(getColor(R.color.eternal_text))
            setPadding(dp(24), dp(8), dp(24), dp(8))
        }
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Redefinir configurações")
            .setMessage("As opções registradas nesta tela voltarão ao padrão. Favoritos, histórico e abas salvas não serão apagados.")
            .setView(check)
            .setPositiveButton("Redefinir", null)
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        dialog.setOnShowListener {
            val positive = dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)
            positive.isEnabled = false
            check.setOnCheckedChangeListener { _, checked -> positive.isEnabled = checked }
            positive.setOnClickListener {
                releaseCurrentWallpaperPermission(except = null)
                prefs.removeKeys(SettingsRegistry.stored(prefs).mapNotNull(SettingsRegistry::keyOf) + PrefsKeys.SEARCH_WALLPAPER_URI)
                dialog.dismiss()
                render()
                askRestart()
            }
        }
        dialog.show()
    }
}
