package com.eternal.browser

import android.net.Uri
import android.util.Log
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONArray
import org.json.JSONObject
import com.eternal.browser.extensions.ExtensionActionManager
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController

/** Instala, lista, ativa/desativa e remove WebExtensions (mesmo sistema do Firefox). */
class ExtensionManager(
    private val activity: AppCompatActivity,
    private val runtime: GeckoRuntime,
    private val night: NightModeController,
    private val searchWallpaper: SearchWallpaperManager,
) {
    private val controller: WebExtensionController get() = runtime.webExtensionController

    /** Chamado quando uma extensão termina de instalar (a UI registra os delegates de popup/opções nela). */
    var onInstalled: ((WebExtension) -> Unit)? = null

    /** Painel (sidebar_action.default_panel ou side_panel.default_path) do manifest da última importação. */
    @Volatile private var pendingSidebar: String? = null

    /** default_popup da ação do manifest da última importação (fallback caso o Gecko não abra o popup). */
    @Volatile private var pendingPopup: String? = null

    /** Página de opções do manifest (fallback para quando metaData.optionsPageUrl do Gecko vem vazio). */
    @Volatile private var pendingOptions: String? = null

    /** Abre o seletor de arquivos .zip (quem possui o ActivityResult é a MainActivity). */
    var onPickZip: (() -> Unit)? = null

    fun init(withBuiltIn: Boolean = true) {
        // Sem este delegate o Gecko não instala nada: ele pergunta ao app antes de cada instalação.
        controller.setPromptDelegate(object : WebExtensionController.PromptDelegate {
            override fun onInstallPromptRequest(
                extension: WebExtension,
                permissions: Array<String>,
                origins: Array<String>,
                dataCollectionPermissions: Array<String>,
            ): GeckoResult<WebExtension.PermissionPromptResponse>? {
                val result = GeckoResult<WebExtension.PermissionPromptResponse>()
                val name = extension.metaData.name ?: extension.id
                val all = permissions.toList() + origins.toList() + dataCollectionPermissions.toList()
                val msg = if (all.isEmpty()) activity.getString(R.string.ext_no_permissions)
                else activity.getString(R.string.ext_permissions_intro) + "\n\n• " + all.joinToString("\n• ")
                MaterialAlertDialogBuilder(activity)
                    .setTitle(activity.getString(R.string.ext_add_title, name))
                    .setMessage(msg)
                    // (permissões, modo privado, dados técnicos e de interação)
                    .setPositiveButton(R.string.ext_add) { _, _ ->
                        result.complete(WebExtension.PermissionPromptResponse(true, false, false))
                    }
                    .setNegativeButton(android.R.string.cancel) { _, _ ->
                        result.complete(WebExtension.PermissionPromptResponse(false, false, false))
                    }
                    .setOnCancelListener { result.complete(WebExtension.PermissionPromptResponse(false, false, false)) }
                    .show()
                return result
            }
        })

        // Extensão embutida do modo noturno (fora do modo seguro).
        if (!withBuiltIn) return
        controller.ensureBuiltIn(NightModeController.EXTENSION_URI, NightModeController.EXTENSION_ID)
            .accept(
                { ext -> if (ext != null) { night.bind(ext); night.apply() } },
                { e -> Log.e("Eternal", "Falha ao carregar extensão do modo noturno", e) }
            )

        // Extensão embutida do wallpaper nas páginas de busca.
        controller.ensureBuiltIn(SearchWallpaperManager.EXTENSION_URI, SearchWallpaperManager.EXTENSION_ID)
            .accept(
                { ext -> if (ext != null) { searchWallpaper.bind(ext); searchWallpaper.apply() } },
                { e -> Log.e("Eternal", "Falha ao carregar extensão do wallpaper de pesquisa", e) }
            )

        // Extensão embutida das ferramentas de desenvolvedor (rede e cookies).
        controller.ensureBuiltIn(DevToolsHub.EXTENSION_URI, DevToolsHub.EXTENSION_ID)
            .accept(
                { ext -> if (ext != null) DevToolsHub.bind(ext) },
                { e -> Log.e("Eternal", "Falha ao carregar extensão de DevTools", e) }
            )
    }

    /** Instala a partir de um file:// já preparado (.xpi gerado no cache). Não é exposto: a entrada pública é ZIP ou URL. */
    private fun install(url: String) {
        controller.install(url).accept(
            { ext ->
                if (ext != null) {
                    pendingSidebar?.let { ExtensionActionManager.get(activity)?.rememberSidebar(ext.id, it) }
                    pendingPopup?.let { ExtensionActionManager.get(activity)?.rememberPopup(ext.id, it) }
                    pendingOptions?.let { ExtensionActionManager.get(activity)?.rememberOptions(ext.id, it) }
                    runCatching { onInstalled?.invoke(ext) }
                }
                pendingSidebar = null
                pendingPopup = null
                pendingOptions = null
                toast(activity.getString(R.string.ext_installed, ext?.metaData?.name ?: ""))
            },
            { e -> pendingSidebar = null; showFailure(e) }
        )
    }

    private fun errorCode(e: Throwable?): Int? {
        if (e == null) return null
        return runCatching { e.javaClass.getField("code").getInt(e) }.getOrNull()
            ?: runCatching { e.javaClass.getMethod("getCode").invoke(e) as? Int }.getOrNull()
    }

    /** Diálogo (não some sozinho) com o motivo, o detalhe técnico para copiar e, se for falta de assinatura, o atalho para assinar. */
    private fun showFailure(e: Throwable?) {
        Log.e("Eternal", "instalação de extensão falhou", e)
        val code = errorCode(e)
        val detail = buildString {
            append(e?.javaClass?.simpleName ?: "erro")
            if (code != null) append(" (código ").append(code).append(")")
            val m = e?.message
            if (!m.isNullOrBlank()) append(": ").append(m)
        }
        activity.runOnUiThread {
            if (activity.isFinishing || activity.isDestroyed) return@runOnUiThread
            val b = MaterialAlertDialogBuilder(activity)
                .setTitle(R.string.ext_fail_title)
                .setMessage(explain(e) + "\n\n" + detail)
                .setPositiveButton(android.R.string.ok, null)
                .setNeutralButton(android.R.string.copy) { _, _ ->
                    val cm = activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("eternal-extensao", detail))
                }
            if (code == -5) {
                b.setNegativeButton(R.string.ext_sign_amo) { _, _ ->
                    runCatching {
                        activity.startActivity(
                            android.content.Intent(
                                android.content.Intent.ACTION_VIEW,
                                Uri.parse("https://addons.mozilla.org/developers/addon/submit/distribution"),
                            )
                        )
                    }
                }
            }
            b.show()
        }
    }

    /** Traduz o erro do Gecko (código de instalação) em algo que o usuário entenda. */
    private fun explain(e: Throwable?): String {
        if (e == null) return ""
        return when (errorCode(e)) {
            -5 -> activity.getString(R.string.ext_err_unsigned)
            -3 -> activity.getString(R.string.ext_err_corrupt)
            -10 -> activity.getString(R.string.ext_err_incompatible)
            else -> e.message ?: e.javaClass.simpleName
        }
    }

    // ---------- importação (arquivo .zip ou URL; Manifest V3) ----------

    private val maxImport = 100L * 1024 * 1024

    /** Importa um ARQUIVO .zip do armazenamento: converte para .xpi se preciso e instala por file://. */
    fun installFromUri(uri: Uri) {
        toast(activity.getString(R.string.ext_installing))
        Thread {
            try {
                val name = displayName(uri)
                if (name != null && !name.endsWith(".zip", ignoreCase = true)) {
                    throw java.io.IOException(activity.getString(R.string.ext_err_not_zip))
                }
                val raw = readLimited(uri)
                if (!isZip(raw)) throw java.io.IOException(activity.getString(R.string.ext_err_not_zip))
                val file = prepare(raw)
                activity.runOnUiThread { install(Uri.fromFile(file).toString()) }
            } catch (t: Throwable) {
                showFailure(t)
            }
        }.start()
    }

    private fun isZip(raw: ByteArray): Boolean =
        raw.size > 4 && raw[0] == 'P'.code.toByte() && raw[1] == 'K'.code.toByte()

    private fun displayName(uri: Uri): String? = try {
        activity.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Throwable) { null }

    /** Baixa de um endereço http(s) (o arquivo é um .zip de extensão; .xpi/.crx também funcionam), converte se preciso e instala. */
    fun installFromUrl(url: String) {
        val clean = url.trim().substringBefore('#')
        if (!clean.startsWith("https://", true) && !clean.startsWith("http://", true)) {
            showFailure(java.io.IOException(activity.getString(R.string.ext_err_url)))
            return
        }
        toast(activity.getString(R.string.ext_installing))
        Thread {
            try {
                val r = Net.get(clean, 80_000_000)
                val file = prepare(r.bytes)
                activity.runOnUiThread { install(Uri.fromFile(file).toString()) }
            } catch (t: Throwable) {
                showFailure(t)
            }
        }.start()
    }

    private fun readLimited(uri: Uri): ByteArray {
        val input = activity.contentResolver.openInputStream(uri)
            ?: throw java.io.IOException("não foi possível abrir o arquivo")
        input.use { i ->
            val out = java.io.ByteArrayOutputStream()
            val buf = ByteArray(64 * 1024)
            var total = 0L
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                total += n
                if (total > maxImport) throw java.io.IOException("arquivo grande demais (máx. 100 MB)")
                out.write(buf, 0, n)
            }
            return out.toByteArray()
        }
    }

    /** Remove o cabeçalho do .crx (Chrome) e devolve o zip; aceita zip/xpi/jar como estão. */
    private fun unwrap(raw: ByteArray): ByteArray {
        if (raw.size > 16 && String(raw, 0, 4, Charsets.ISO_8859_1) == "Cr24") {
            fun le(o: Int): Int = (raw[o].toInt() and 255) or ((raw[o + 1].toInt() and 255) shl 8) or
                ((raw[o + 2].toInt() and 255) shl 16) or ((raw[o + 3].toInt() and 255) shl 24)
            val version = le(4)
            val start = if (version >= 3) 12L + le(8) else 16L + le(8) + le(12)
            if (start <= 0 || start >= raw.size) throw java.io.IOException("arquivo .crx inválido")
            return raw.copyOfRange(start.toInt(), raw.size)
        }
        if (raw.size > 4 && raw[0] == 'P'.code.toByte() && raw[1] == 'K'.code.toByte()) return raw
        throw java.io.IOException(activity.getString(R.string.ext_err_format))
    }

    /**
     * Gera um .xpi instalável no cache. Extensões já assinadas (arquivo .rsa em META-INF) na raiz do zip são
     * entregues byte a byte, para não quebrar a assinatura. Nos outros casos: acha o manifest.json
     * (mesmo dentro de uma pasta), usa a pasta dele como raiz e ajusta o manifest para o Gecko
     * (id da extensão e background.scripts no lugar de service_worker).
     */
    private fun prepare(raw: ByteArray): java.io.File {
        val zipBytes = unwrap(raw)
        val entries = LinkedHashMap<String, ByteArray>()
        var total = 0L
        java.util.zip.ZipInputStream(zipBytes.inputStream()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val name = e.name.replace('\\', '/').trimStart('/')
                if (!e.isDirectory && name.isNotEmpty() && !name.contains("../") && !name.startsWith("__MACOSX/")) {
                    val data = zin.readBytes()
                    total += data.size
                    if (total > 300L * 1024 * 1024) throw java.io.IOException("extensão grande demais depois de descompactar")
                    entries[name] = data
                }
                e = zin.nextEntry
            }
        }
        val manifestPath = entries.keys
            .filter { it == "manifest.json" || it.endsWith("/manifest.json") }
            .minByOrNull { p -> p.count { it == '/' } }
        if (manifestPath == null) {
            throw java.io.IOException(
                if (entries.containsKey("install.rdf")) activity.getString(R.string.ext_err_legacy)
                else activity.getString(R.string.ext_err_no_manifest)
            )
        }
        val prefix = manifestPath.removeSuffix("manifest.json")
        val signed = prefix.isEmpty() && entries.keys.any { it.startsWith("META-INF/") && it.endsWith(".rsa", ignoreCase = true) }

        val original = entries.getValue(manifestPath)
        requireManifestVersion(original)
        // sidebar_action (Manifest V2/Firefox) ou side_panel (Manifest V3/Chrome): ambos viram a
        // mesma "aba de painel" aberta em nova aba, já que o GeckoView não desenha painel lateral nativo.
        pendingSidebar = runCatching {
            val m = JSONObject(String(original, Charsets.UTF_8).removePrefix("\uFEFF"))
            m.optJSONObject("sidebar_action")?.optString("default_panel")?.takeIf { it.isNotBlank() }
                ?: m.optJSONObject("side_panel")?.optString("default_path")?.takeIf { it.isNotBlank() }
        }.getOrNull()
        pendingPopup = runCatching {
            val m = JSONObject(String(original, Charsets.UTF_8).removePrefix("\uFEFF"))
            listOf("action", "browser_action", "page_action")
                .mapNotNull { m.optJSONObject(it)?.optString("default_popup")?.takeIf { p -> p.isNotBlank() } }
                .firstOrNull()
        }.getOrNull()
        // Reforço: o Gecko normalmente já relata isto em metaData.optionsPageUrl; isto só entra se vier vazio.
        pendingOptions = runCatching {
            val m = JSONObject(String(original, Charsets.UTF_8).removePrefix("\uFEFF"))
            m.optJSONObject("options_ui")?.optString("page")?.takeIf { it.isNotBlank() }
                ?: m.optString("options_page").takeIf { it.isNotBlank() }
        }.getOrNull()
        val fixed = if (signed) null else fixManifest(original)

        cleanOldImports()
        val out = java.io.File(activity.cacheDir, "import-${System.currentTimeMillis()}.xpi")
        if (prefix.isEmpty() && fixed == null) {
            out.writeBytes(zipBytes)
            return out
        }
        java.util.zip.ZipOutputStream(out.outputStream().buffered()).use { z ->
            for ((name, data) in entries) {
                if (!name.startsWith(prefix)) continue
                val rel = name.removePrefix(prefix)
                z.putNextEntry(java.util.zip.ZipEntry(rel))
                z.write(if (name == manifestPath && fixed != null) fixed else data)
                z.closeEntry()
            }
        }
        return out
    }

    /**
     * Extensões normalmente são Manifest V3: exige manifest_version 3 (ou 2, ainda aceito pelo motor).
     * Sem o campo, o Gecko recusa com um erro técnico difícil de entender; aqui o motivo vem claro.
     */
    private fun requireManifestVersion(bytes: ByteArray) {
        val version = try {
            JSONObject(String(bytes, Charsets.UTF_8).removePrefix("\uFEFF")).optInt("manifest_version", 0)
        } catch (t: Throwable) {
            throw java.io.IOException(activity.getString(R.string.ext_err_manifest_json))
        }
        if (version != 3 && version != 2) throw java.io.IOException(activity.getString(R.string.ext_err_manifest_version))
    }

    /** Devolve o manifest ajustado, ou null se nada precisava mudar (ou se não for JSON simples). */
    private fun fixManifest(bytes: ByteArray): ByteArray? {
        return try {
            val json = JSONObject(String(bytes, Charsets.UTF_8).removePrefix("\uFEFF"))
            var changed = false

            // O Gecko exige um id para instalar uma extensão de forma permanente.
            val bss = json.optJSONObject("browser_specific_settings")
            val apps = json.optJSONObject("applications")
            val hasId = bss?.optJSONObject("gecko")?.has("id") == true || apps?.optJSONObject("gecko")?.has("id") == true
            if (!hasId) {
                val gecko = (bss?.optJSONObject("gecko")) ?: JSONObject()
                gecko.put("id", "imp-" + Integer.toHexString(bytes.contentHashCode()) + "@eternal.local")
                val holder = bss ?: JSONObject()
                holder.put("gecko", gecko)
                json.put("browser_specific_settings", holder)
                changed = true
            }

            // Manifest V3 do Chrome usa service_worker; o Firefox usa background.scripts.
            val bg = json.optJSONObject("background")
            if (bg != null && bg.has("service_worker") && !bg.has("scripts")) {
                bg.put("scripts", JSONArray().put(bg.getString("service_worker")))
                changed = true
            }
            if (changed) json.toString(2).toByteArray(Charsets.UTF_8) else null
        } catch (t: Throwable) {
            Log.w("Eternal", "manifest não ajustado", t)
            null
        }
    }

    private fun cleanOldImports() {
        val limit = System.currentTimeMillis() - 60 * 60 * 1000
        activity.cacheDir.listFiles { f -> f.name.startsWith("import-") && f.lastModified() < limit }?.forEach { it.delete() }
    }

    // ---------- UI ----------

    fun showManager() {
        controller.list().accept(
            { list ->
                val exts = (list ?: emptyList()).filter { !it.isBuiltIn }
                val labels = exts.map {
                    val enabled = it.metaData.enabled
                    (it.metaData.name ?: it.id) + if (enabled) "" else "  (desativada)"
                }.toTypedArray()
                val b = MaterialAlertDialogBuilder(activity)
                    .setTitle(R.string.menu_extensions)
                    .setNeutralButton(R.string.ext_install_new) { _, _ -> showInstallChooser() }
                    .setPositiveButton(android.R.string.ok, null)
                if (exts.isEmpty()) b.setMessage(R.string.ext_none) else b.setItems(labels) { _, i -> showActions(exts[i]) }
                b.show()
            },
            { e -> toast(e?.message ?: "erro") }
        )
    }

    private fun showActions(ext: WebExtension) {
        val enabled = ext.metaData.enabled
        val items = arrayOf(
            activity.getString(if (enabled) R.string.ext_disable else R.string.ext_enable),
            activity.getString(R.string.ext_remove),
        )
        MaterialAlertDialogBuilder(activity)
            .setTitle(ext.metaData.name ?: ext.id)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> (if (enabled) controller.disable(ext, WebExtensionController.EnableSource.USER)
                    else controller.enable(ext, WebExtensionController.EnableSource.USER))
                        .accept({ }, { e -> toast(e?.message ?: "erro") })
                    1 -> controller.uninstall(ext)
                        .accept({ toast(activity.getString(R.string.ext_removed)) }, { e -> toast(e?.message ?: "erro") })
                }
            }.show()
    }

    /** Só duas formas de instalar: importar um arquivo .zip ou informar uma URL. */
    fun showInstallChooser() {
        val names = arrayOf(activity.getString(R.string.ext_import_zip), activity.getString(R.string.ext_from_url))
        MaterialAlertDialogBuilder(activity)
            .setTitle(R.string.ext_install_new)
            .setItems(names) { _, i -> if (i == 0) onPickZip?.invoke() else askUrl() }
            .show()
    }

    private fun askUrl() {
        val input = EditText(activity).apply { hint = "https://…/extensao.zip"; setSingleLine() }
        MaterialAlertDialogBuilder(activity)
            .setTitle(R.string.ext_from_url)
            .setView(input)
            .setPositiveButton(R.string.ext_add) { _, _ ->
                val u = input.text.toString().trim()
                if (u.isNotEmpty()) installFromUrl(u)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun toast(msg: String) = activity.runOnUiThread { Toast.makeText(activity, msg, Toast.LENGTH_LONG).show() }
}
