package com.eternal.browser.core.storage

import android.content.Context
import androidx.core.content.edit

/** Acesso centralizado e síncrono ao arquivo de preferências do ETERNAL. */
class PrefsManager(context: Context, fileName: String = "eternal") {
    private val preferences = context.applicationContext
        .getSharedPreferences(fileName, Context.MODE_PRIVATE)

    fun getBoolean(key: String, default: Boolean): Boolean = preferences.getBoolean(key, default)
    fun setBoolean(key: String, value: Boolean) = preferences.edit(commit = true) { putBoolean(key, value) }

    fun getString(key: String, default: String): String = preferences.getString(key, default) ?: default
    fun setString(key: String, value: String, commit: Boolean = true) =
        preferences.edit(commit = commit) { putString(key, value) }

    fun getInt(key: String, default: Int): Int = preferences.getInt(key, default)
    fun setInt(key: String, value: Int) = preferences.edit(commit = true) { putInt(key, value) }

    fun getLong(key: String, default: Long): Long = preferences.getLong(key, default)
    fun setLong(key: String, value: Long) = preferences.edit(commit = true) { putLong(key, value) }

    fun removeKeys(keys: Collection<String>) = preferences.edit(commit = true) {
        keys.forEach(::remove)
    }
}
