package com.eternal.browser

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class ToolRow(
    val title: String, val sub: String, val right: String = "",
    val checkable: Boolean = false, var checked: Boolean = false, val tag: Any? = null,
)

/** Base das telas de ferramentas (fonte, rede, cookies, assets): barra, chips, lista/código e botão primário. */
abstract class ToolActivity : AppCompatActivity() {

    protected val io: ExecutorService = Executors.newSingleThreadExecutor()
    protected var animateRows = false
    protected var onRowClick: (ToolRow) -> Unit = {}
    protected var onRowCheck: (ToolRow, Boolean) -> Unit = { _, _ -> }
    protected val rows = mutableListOf<ToolRow>()

    private lateinit var listView: RecyclerView
    private lateinit var codeScroll: View
    private lateinit var codeText: TextView
    private lateinit var emptyText: TextView
    private lateinit var statusText: TextView
    private lateinit var chips: LinearLayout
    private lateinit var primary: TextView
    private lateinit var action1: TextView
    private lateinit var action2: TextView

    private val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
            object : RecyclerView.ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_tool, parent, false)) {}

        override fun getItemCount() = rows.size

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
            val r = rows.getOrNull(position) ?: return
            val v = h.itemView
            v.findViewById<TextView>(R.id.itemTitle).text = r.title
            v.findViewById<TextView>(R.id.itemSub).text = r.sub
            v.findViewById<TextView>(R.id.itemRight).apply {
                text = r.right
                visibility = if (r.right.isBlank()) View.GONE else View.VISIBLE
            }
            val cb = v.findViewById<CheckBox>(R.id.itemCheck)
            cb.setOnCheckedChangeListener(null)
            cb.visibility = if (r.checkable) View.VISIBLE else View.GONE
            cb.isChecked = r.checked
            cb.setOnCheckedChangeListener { _, c -> r.checked = c; onRowCheck(r, c) }
            v.setOnClickListener { if (r.checkable) cb.toggle() else onRowClick(r) }
            if (animateRows && position < 12) {
                v.alpha = 0f
                v.animate().alpha(1f).setStartDelay(position * 30L).setDuration(200).start()
            } else v.alpha = 1f
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tool)
        listView = findViewById(R.id.toolList)
        codeScroll = findViewById(R.id.toolCodeScroll)
        codeText = findViewById(R.id.toolCode)
        emptyText = findViewById(R.id.toolEmpty)
        statusText = findViewById(R.id.toolStatus)
        chips = findViewById(R.id.toolChips)
        primary = findViewById(R.id.toolPrimary)
        action1 = findViewById(R.id.toolAction1)
        action2 = findViewById(R.id.toolAction2)
        listView.layoutManager = LinearLayoutManager(this)
        listView.adapter = adapter
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        // Entrada: desliza da direita (280 ms) via animação padrão da janela não é garantida; fade simples no conteúdo.
        findViewById<View>(R.id.toolList).alpha = 0f
        findViewById<View>(R.id.toolList).animate().alpha(1f).setDuration(280).start()
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    protected fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    protected fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    protected fun ui(block: () -> Unit) = runOnUiThread { if (!isFinishing && !isDestroyed) block() }

    protected fun setTitleText(t: String) { findViewById<TextView>(R.id.toolTitle).text = t }

    protected fun setStatus(t: String) { statusText.text = t }

    protected fun setAction1(label: String, onClick: () -> Unit) {
        action1.text = label; action1.visibility = View.VISIBLE; action1.setOnClickListener { onClick() }
    }

    protected fun setAction2(label: String, onClick: () -> Unit) {
        action2.text = label; action2.visibility = View.VISIBLE; action2.setOnClickListener { onClick() }
    }

    protected fun setPrimary(label: String, onClick: () -> Unit) {
        primary.text = label; primary.visibility = View.VISIBLE; primary.setOnClickListener { onClick() }
    }

    protected fun addChip(label: String, onClick: () -> Unit): TextView {
        val c = TextView(this).apply {
            text = label
            textSize = 13f
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setTextColor(ContextCompat.getColorStateList(this@ToolActivity, R.color.chip_text))
            background = ContextCompat.getDrawable(this@ToolActivity, R.drawable.bg_chip)
            isClickable = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { marginEnd = dp(8) }
            setOnClickListener { selectChip(this); onClick() }
        }
        chips.addView(c)
        if (chips.childCount == 1) c.isSelected = true
        return c
    }

    private fun selectChip(sel: View) {
        for (i in 0 until chips.childCount) chips.getChildAt(i).isSelected = chips.getChildAt(i) === sel
    }

    protected fun showCode(text: String) {
        listView.visibility = View.GONE; emptyText.visibility = View.GONE
        codeScroll.visibility = View.VISIBLE
        codeText.text = text
        codeScroll.alpha = 0f; codeScroll.animate().alpha(1f).setDuration(250).start()
    }

    protected fun showRows(list: List<ToolRow>, emptyMessage: String) {
        rows.clear(); rows.addAll(list)
        adapter.notifyDataSetChanged()
        codeScroll.visibility = View.GONE
        listView.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        emptyText.text = emptyMessage
        emptyText.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    protected fun showMessage(msg: String) {
        rows.clear(); adapter.notifyDataSetChanged()
        listView.visibility = View.GONE; codeScroll.visibility = View.GONE
        emptyText.text = msg; emptyText.visibility = View.VISIBLE
    }

    protected fun copyToClipboard(label: String, text: String) {
        // O Binder limita ~1 MB por transação: copia no máximo 500 mil caracteres.
        val t = if (text.length > 500_000) text.take(500_000) else text
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, t))
        toast(if (t.length < text.length) "Copiado (primeiros 500 mil caracteres)" else "Copiado")
    }

    protected fun hostOf(url: String): String = try { java.net.URL(url).host } catch (_: Throwable) { "site" }
}
