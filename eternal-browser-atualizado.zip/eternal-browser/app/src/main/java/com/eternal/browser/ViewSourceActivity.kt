package com.eternal.browser

import android.os.Bundle

/** Código-fonte da página (HTML) e dos recursos (CSS, JS, imagens). Baixa de novo a URL, então não inclui o que depende de login/cookies. */
class ViewSourceActivity : ToolActivity() {
    private var url = ""
    private var html: String? = null
    private var shown = ""
    private var ext = "html"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        url = intent.getStringExtra("url") ?: ""
        setTitleText("Código-fonte")
        setStatus(url)
        setAction1("Copiar") { if (shown.isNotEmpty()) copyToClipboard("codigo-fonte", shown) }
        setAction2("Salvar") { save() }
        addChip("HTML") { load("html") }
        addChip("CSS") { load("css") }
        addChip("JS") { load("js") }
        addChip("Imagens") { load("img") }
        addChip("Tudo") { load("all") }
        load("html")
    }

    private fun load(mode: String) {
        showMessage("Carregando…")
        io.execute {
            try {
                val page = html ?: Net.text(Net.get(url, 5_000_000)).also { html = it }
                val text = when (mode) {
                    "html" -> { ext = "html"; page.replace("><", ">\n<") }
                    "css" -> { ext = "css"; bundle(page, "css") }
                    "js" -> { ext = "js"; bundle(page, "js") }
                    "img" -> { ext = "txt"; HtmlScan.scan(page, url).images.joinToString("\n").ifBlank { "Nenhuma imagem encontrada." } }
                    else -> { ext = "txt"; HtmlScan.scan(page, url).all.joinToString("\n").ifBlank { "Nenhum recurso encontrado." } }
                }
                shown = text
                val display = if (text.length > 400_000) text.take(400_000) + "\n\n… (truncado: use Salvar para o arquivo completo)" else text
                ui { showCode(display) }
            } catch (t: Throwable) {
                ui { showMessage("Erro ao carregar: ${t.message}") }
            }
        }
    }

    /** CSS/JS: trechos inline + até 15 arquivos externos baixados, separados por comentário com a URL. */
    private fun bundle(page: String, kind: String): String {
        val sb = StringBuilder()
        val inline = if (kind == "css") Regex("<style[^>]*>([\\s\\S]*?)</style>", RegexOption.IGNORE_CASE)
        else Regex("<script(?![^>]*\\bsrc\\b)[^>]*>([\\s\\S]*?)</script>", RegexOption.IGNORE_CASE)
        inline.findAll(page).forEachIndexed { i, m ->
            if (m.groupValues[1].isNotBlank()) sb.append("/* inline #${i + 1} */\n").append(m.groupValues[1].trim()).append("\n\n")
        }
        val found = HtmlScan.scan(page, url)
        for (u in (if (kind == "css") found.css else found.js).take(15)) {
            sb.append("/* ").append(u).append(" */\n")
            try { sb.append(Net.text(Net.get(u, 3_000_000))) } catch (t: Throwable) { sb.append("/* erro: ${t.message} */") }
            sb.append("\n\n")
        }
        return sb.toString().ifBlank { "Nada encontrado." }
    }

    private fun save() {
        if (shown.isEmpty()) return
        io.execute {
            val where = Downloads.saveText(this, "eternal_sites/fonte", "${hostOf(url)}.$ext", shown)
            ui { toast(if (where != null) "Salvo em $where" else "Não foi possível salvar") }
        }
    }
}
