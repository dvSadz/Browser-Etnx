package com.eternal.browser

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import org.mozilla.geckoview.WebExtension

/** Recebe da extensão embutida "devtools" o registro de requisições e as respostas de cookies. Sempre na main thread. */
object DevToolsHub {
    const val EXTENSION_URI = "resource://android/assets/devtools/"
    const val EXTENSION_ID = "devtools@eternal.browser"
    private const val NATIVE_APP = "eternaldev"
    private const val MAX = 500

    class Req(
        val method: String, val url: String, val status: Int, val type: String,
        val ms: Long, val size: Long, val headers: List<Pair<String, String>>, val error: String,
    )

    private val requests = ArrayList<Req>()
    private var port: WebExtension.Port? = null

    var listener: (() -> Unit)? = null
    var cookiesCallback: ((JSONArray, String) -> Unit)? = null

    val connected: Boolean get() = port != null

    fun snapshot(): List<Req> = ArrayList(requests)
    fun clear() { requests.clear(); listener?.invoke() }

    fun send(msg: JSONObject): Boolean = try {
        val p = port
        if (p == null) false else { p.postMessage(msg); true }
    } catch (t: Throwable) { Log.e("DevToolsHub", "send", t); false }

    fun bind(extension: WebExtension) {
        extension.setMessageDelegate(object : WebExtension.MessageDelegate {
            override fun onConnect(port: WebExtension.Port) {
                this@DevToolsHub.port = port
                port.setDelegate(object : WebExtension.PortDelegate {
                    override fun onPortMessage(message: Any, port: WebExtension.Port) {
                        try { if (message is JSONObject) handle(message) } catch (t: Throwable) { Log.e("DevToolsHub", "msg", t) }
                    }

                    override fun onDisconnect(port: WebExtension.Port) {
                        if (this@DevToolsHub.port === port) this@DevToolsHub.port = null
                    }
                })
            }
        }, NATIVE_APP)
    }

    private fun handle(m: JSONObject) {
        when (m.optString("k")) {
            "req" -> {
                val hs = ArrayList<Pair<String, String>>()
                val arr = m.optJSONArray("h")
                if (arr != null) for (i in 0 until arr.length()) {
                    val pair = arr.optJSONArray(i) ?: continue
                    hs.add(pair.optString(0) to pair.optString(1))
                }
                requests.add(
                    Req(m.optString("m"), m.optString("u"), m.optInt("s"), m.optString("ty"),
                        m.optLong("ms"), m.optLong("sz"), hs, m.optString("err"))
                )
                while (requests.size > MAX) requests.removeAt(0)
                listener?.invoke()
            }
            "nav" -> { requests.clear(); listener?.invoke() }
            "cookies" -> cookiesCallback?.invoke(m.optJSONArray("list") ?: JSONArray(), m.optString("err"))
        }
    }
}
