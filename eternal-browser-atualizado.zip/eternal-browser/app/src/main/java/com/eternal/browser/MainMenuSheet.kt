package com.eternal.browser

import android.transition.AutoTransition
import android.transition.TransitionManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.NestedScrollView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.materialswitch.MaterialSwitch

enum class MenuAction {
    SEARCH, NEW_TAB, PRIVATE_TAB, TABS, BOOKMARKS, HISTORY, EXTENSIONS,
    BOOKMARK_TOGGLE, NIGHT, NIGHT_ADJUST, BAR_POSITION, SEARCH_ENGINE,
    IMPORT_EXT, DEV, SAFE_MODE, SETTINGS, ABOUT,
    EXT_MANAGE, EXT_POPUP, EXT_OPTIONS, EXT_SIDEBAR, EXT_ADDONS,
}

/**
 * Menu principal em bottom sheet animado.
 * Tela inicial enxuta (pesquisar + 6 atalhos); o resto fica em "Mais opções", que expande com animação.
 */
class MainMenuSheet(
    private val activity: AppCompatActivity,
    private val nightOn: Boolean,
    private val bookmarked: Boolean,
    private val barAtBottom: Boolean,
    private val safeMode: Boolean,
    private val onAction: (MenuAction, Boolean) -> Unit,
) {
    private val density = activity.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()
    private fun color(res: Int) = ContextCompat.getColor(activity, res)

    private fun icon(res: Int, size: Int): ImageView = ImageView(activity).apply {
        setImageResource(res)
        setColorFilter(color(R.color.eternal_text))
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    }

    private fun label(text: String, sizeSp: Float, secondary: Boolean = false): TextView = TextView(activity).apply {
        this.text = text
        setTextColor(color(if (secondary) R.color.eternal_text_secondary else R.color.eternal_text))
        textSize = sizeSp
    }

    @Suppress("ClickableViewAccessibility")
    private fun pressable(v: View, pressedScale: Float = 0.95f) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(pressedScale).scaleY(pressedScale).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    fun show() {
        val dialog = BottomSheetDialog(activity)
        val col = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(20))
        }
        val animated = mutableListOf<View>()

        fun pick(action: MenuAction) {
            dialog.dismiss()
            onAction(action, false)
        }

        // --- Pesquisar ---
        val pill = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(16), 0)
            setBackgroundResource(R.drawable.bg_search_pill)
            isClickable = true
            isFocusable = true
            addView(icon(R.drawable.ic_search, 20))
            addView(label(activity.getString(R.string.menu_search_hint), 15f, secondary = true).apply {
                setPadding(dp(12), 0, 0, 0)
            })
            setOnClickListener { pick(MenuAction.SEARCH) }
        }
        pressable(pill, 0.97f)
        col.addView(pill, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        animated += pill

        // --- Atalhos (grade 3x2) ---
        fun tile(iconRes: Int, text: String, action: MenuAction): View = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_tile)
            isClickable = true
            isFocusable = true
            contentDescription = text
            addView(icon(iconRes, 24))
            addView(label(text, 12f).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(0, dp(6), 0, 0)
            })
            setOnClickListener { pick(action) }
        }.also { pressable(it) }

        fun tileRow(vararg tiles: View): LinearLayout = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            tiles.forEachIndexed { i, t ->
                addView(t, LinearLayout.LayoutParams(0, dp(80), 1f).apply { if (i > 0) marginStart = dp(8) })
            }
        }

        val row1 = tileRow(
            tile(R.drawable.ic_add, activity.getString(R.string.menu_new_tab), MenuAction.NEW_TAB),
            tile(R.drawable.ic_incognito, activity.getString(R.string.menu_private_tab), MenuAction.PRIVATE_TAB),
            tile(R.drawable.ic_tabs, activity.getString(R.string.menu_tabs), MenuAction.TABS),
        )
        val row2 = tileRow(
            tile(R.drawable.ic_star, activity.getString(R.string.menu_bookmarks), MenuAction.BOOKMARKS),
            tile(R.drawable.ic_history, activity.getString(R.string.menu_history), MenuAction.HISTORY),
            tile(R.drawable.ic_ext, activity.getString(R.string.menu_extensions), MenuAction.EXTENSIONS),
        )
        col.addView(row1, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })
        col.addView(row2, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        animated += row1
        animated += row2

        // --- Linhas (texto, com ou sem interruptor) ---
        fun row(text: String, action: MenuAction, switchState: Boolean? = null): View = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(8), 0)
            setBackgroundResource(R.drawable.bg_menu_row)
            isClickable = true
            isFocusable = true
            addView(label(text, 15f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (switchState == null) {
                setOnClickListener { pick(action) }
            } else {
                val sw = MaterialSwitch(activity).apply {
                    isChecked = switchState
                    setOnCheckedChangeListener { _, checked -> onAction(action, checked) }
                }
                addView(sw)
                setOnClickListener { sw.toggle() }
            }
        }

        fun rowParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))

        // --- Seção expansível ---
        val more = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        more.addView(
            row(
                activity.getString(if (bookmarked) R.string.menu_bookmark_remove else R.string.menu_bookmark_add),
                MenuAction.BOOKMARK_TOGGLE,
            ), rowParams()
        )
        more.addView(row(activity.getString(R.string.menu_night), MenuAction.NIGHT, nightOn), rowParams())
        more.addView(row(activity.getString(R.string.menu_night_adjust), MenuAction.NIGHT_ADJUST), rowParams())
        more.addView(row(activity.getString(R.string.menu_bar_position), MenuAction.BAR_POSITION, barAtBottom), rowParams())
        more.addView(row(activity.getString(R.string.menu_search_engine), MenuAction.SEARCH_ENGINE), rowParams())
        more.addView(
            label(activity.getString(R.string.menu_ext_section), 11f, secondary = true).apply {
                setPadding(dp(12), dp(12), 0, dp(4))
                letterSpacing = 0.08f
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        more.addView(row(activity.getString(R.string.menu_ext_manage), MenuAction.EXT_MANAGE), rowParams())
        more.addView(row(activity.getString(R.string.menu_ext_popup), MenuAction.EXT_POPUP), rowParams())
        more.addView(row(activity.getString(R.string.menu_ext_options), MenuAction.EXT_OPTIONS), rowParams())
        more.addView(row(activity.getString(R.string.menu_ext_sidebar), MenuAction.EXT_SIDEBAR), rowParams())
        more.addView(row(activity.getString(R.string.menu_ext_addons), MenuAction.EXT_ADDONS), rowParams())
        more.addView(row(activity.getString(R.string.menu_import_ext), MenuAction.IMPORT_EXT), rowParams())
        more.addView(row(activity.getString(R.string.menu_dev), MenuAction.DEV), rowParams())
        more.addView(row(activity.getString(R.string.menu_safe_mode), MenuAction.SAFE_MODE, safeMode), rowParams())
        more.addView(row(activity.getString(R.string.menu_about), MenuAction.ABOUT), rowParams())

        val moreLabel = label(activity.getString(R.string.menu_more), 15f)
        val chevron = icon(R.drawable.ic_chevron_down, 20)
        val moreToggle = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundResource(R.drawable.bg_menu_row)
            isClickable = true
            isFocusable = true
            addView(moreLabel, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(chevron)
            setOnClickListener {
                val expanding = more.visibility != View.VISIBLE
                TransitionManager.beginDelayedTransition(col, AutoTransition().apply { duration = 240 })
                more.visibility = if (expanding) View.VISIBLE else View.GONE
                chevron.animate().rotation(if (expanding) 180f else 0f).setDuration(240).start()
                moreLabel.text = activity.getString(if (expanding) R.string.menu_less else R.string.menu_more)
            }
        }
        col.addView(moreToggle, rowParams().apply { topMargin = dp(8) })
        col.addView(more, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        animated += moreToggle

        val settings = row(activity.getString(R.string.menu_settings), MenuAction.SETTINGS)
        col.addView(settings, rowParams())
        animated += settings

        // Estado inicial da animação de entrada (antes de aparecer, para não piscar).
        animated.forEach {
            it.alpha = 0f
            it.translationY = dp(28).toFloat()
            it.scaleX = 0.92f
            it.scaleY = 0.92f
        }

        val scroll = NestedScrollView(activity).apply { addView(col) }
        dialog.setContentView(scroll)
        dialog.setOnShowListener {
            dialog.behavior.skipCollapsed = true
            dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
            animated.forEachIndexed { i, v ->
                v.animate()
                    .alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                    .setStartDelay(50L + i * 50L)
                    .setDuration(340)
                    .setInterpolator(OvershootInterpolator(1.0f))
                    .start()
            }
        }
        dialog.show()
    }
}
