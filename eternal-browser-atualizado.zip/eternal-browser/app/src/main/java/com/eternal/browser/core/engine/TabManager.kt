package com.eternal.browser.core.engine

import android.os.Handler
import android.util.Log
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.WebResponse

import com.eternal.browser.core.storage.LibraryStore
import com.eternal.browser.PromptHandler
import com.eternal.browser.UrlUtils
class Tab(val id: Int, val session: GeckoSession, val isPrivate: Boolean = false) {
    var title: String = ""
    var url: String = ""
    var progress: Int = 0
    var loading: Boolean = false
    var secure: Boolean = false
    var canGoBack: Boolean = false
    var canGoForward: Boolean = false
    /** Sessão fechada para liberar memória; é reaberta (com a mesma URL) ao selecionar a aba. */
    var discarded: Boolean = false
    var lastUsed: Long = System.currentTimeMillis()
    /** Id da extensão dona desta aba quando ela é o popup da extensão (aba normal, mas não é salva ao fechar o app). */
    var extensionId: String? = null
}

/** Cada aba é uma GeckoSession. A aba atual é a única ativa (as outras ficam suspensas). */
class TabManager(
    private val activity: AppCompatActivity,
    private val runtime: GeckoRuntime,
    private val listener: Listener,
    private val history: LibraryStore,
) {
    interface Listener {
        fun onTabUpdated(tab: Tab)
        fun onTabSelected(tab: Tab)
        fun onTabListChanged()
        fun onFullScreen(fullScreen: Boolean)
        fun onDownload(response: WebResponse)
        fun onPopupBlocked()
        /** Comando vindo da página inicial (links eternal://…). */
        fun onAppCommand(command: String)
    }

    val tabs = mutableListOf<Tab>()
    var current: Tab? = null
        private set

    private companion object { const val TAG = "EternalTabs" }

    private var nextId = 1
    private val main = Handler(Looper.getMainLooper())
    private val promptHandler = PromptHandler(activity) { listener.onPopupBlocked() }

    private fun newSessionSettings(incognito: Boolean = false) = GeckoSessionSettings.Builder()
        .usePrivateMode(incognito)
        .useTrackingProtection(true)
        .suspendMediaWhenInactive(true)
        .build()

    fun openTab(url: String = UrlUtils.START_PAGE, select: Boolean = true, incognito: Boolean = false): Tab {
        val session = GeckoSession(newSessionSettings(incognito))
        val tab = register(session, incognito)
        try {
            session.open(runtime)
            session.loadUri(url)
        } catch (t: Throwable) {
            Log.e(TAG, "openTab falhou para $url", t)
        }
        listener.onTabListChanged()
        if (select) select(tab)
        return tab
    }

    /**
     * Adota uma sessão criada pelo app para o Gecko (popup de extensão) como uma aba normal.
     * A sessão já foi aberta por quem a criou; o Gecko carrega a página do popup nela.
     */
    fun adoptSession(session: GeckoSession, extensionId: String?): Tab {
        val tab = register(session, false)
        tab.extensionId = extensionId
        listener.onTabListChanged()
        selectWhenOpen(tab, 0)
        return tab
    }

    /**
     * Carrega [uri] na aba atual. Único caminho de navegação digitada: sempre na main thread,
     * reabre a sessão se ela estiver fechada e nunca propaga exceção. Retorna false se falhou.
     */
    fun load(uri: String): Boolean {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post { load(uri) }; return true
        }
        val tab = current ?: return openTab(uri).session.isOpen
        return try {
            if (!tab.session.isOpen) tab.session.open(runtime)
            tab.session.loadUri(uri)
            true
        } catch (t: Throwable) {
            Log.e(TAG, "loadUri falhou para $uri", t)
            false
        }
    }

    /** Processo de conteúdo morreu (onCrash/onKill): reabre a sessão e recarrega a página. */
    private fun recover(tab: Tab) {
        main.post {
            if (!tabs.contains(tab)) return@post
            try {
                val url = tab.url.ifBlank { UrlUtils.START_PAGE }
                tab.loading = false
                tab.session.close()
                tab.session.open(runtime)
                if (tab === current) { tab.session.setActive(true); listener.onTabSelected(tab) }
                tab.session.loadUri(url)
            } catch (t: Throwable) {
                Log.e(TAG, "recover falhou", t)
            }
        }
    }

    fun select(tab: Tab) {
        if (current === tab) { listener.onTabSelected(tab); return }
        current?.session?.setActive(false)
        current = tab
        tab.lastUsed = System.currentTimeMillis()
        ensureLive(tab)
        tab.session.setActive(true)
        listener.onTabSelected(tab)
        discardExcess()
    }

    // ---------- memória ----------

    /** No máximo isto de abas em segundo plano mantém a página carregada; as mais antigas são descartadas. */
    private val maxLiveBackground = 3

    /** Reabre uma aba descartada (ou com a sessão fechada) na URL em que estava. */
    private fun ensureLive(tab: Tab) {
        if (!tab.discarded && tab.session.isOpen) return
        try {
            if (!tab.session.isOpen) tab.session.open(runtime)
            tab.session.loadUri(tab.url.ifBlank { UrlUtils.START_PAGE })
            tab.discarded = false
        } catch (t: Throwable) {
            Log.e(TAG, "reabrir aba descartada falhou", t)
        }
    }

    /** Fecha a sessão de uma aba em segundo plano (guarda a URL). Abas anônimas ficam, para não perder o estado. */
    private fun discard(tab: Tab) {
        if (tab === current || tab.isPrivate || tab.discarded || !tab.session.isOpen) return
        try {
            tab.session.close()
            tab.discarded = true
            tab.loading = false
        } catch (t: Throwable) {
            Log.e(TAG, "descartar aba falhou", t)
        }
    }

    private fun discardExcess() {
        tabs.filter { it !== current && !it.isPrivate && !it.discarded && it.session.isOpen }
            .sortedByDescending { it.lastUsed }
            .drop(maxLiveBackground)
            .forEach { discard(it) }
    }

    /** Pouca memória no aparelho: descarta todas as abas em segundo plano (a atual não é tocada). */
    fun discardBackground() {
        if (Looper.myLooper() != Looper.getMainLooper()) { main.post { discardBackground() }; return }
        tabs.toList().forEach { discard(it) }
        listener.onTabListChanged()
    }

    fun close(tab: Tab) {
        val idx = tabs.indexOf(tab)
        if (idx < 0) return
        val wasCurrent = current === tab
        tabs.remove(tab)
        try { tab.session.close() } catch (t: Throwable) { Log.e(TAG, "close falhou", t) }
        listener.onTabListChanged()
        if (wasCurrent) {
            current = null
            val next = tabs.getOrNull(minOf(idx, tabs.size - 1))
            if (next != null) select(next) else openTab()
        }
    }

    // ---------- delegates ----------

    private fun register(session: GeckoSession, incognito: Boolean = false): Tab {
        val tab = Tab(nextId++, session, incognito)
        tabs.add(tab)

        session.promptDelegate = promptHandler

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(s: GeckoSession, url: String) {
                tab.loading = true; tab.progress = 0; tab.url = url
                listener.onTabUpdated(tab)
            }

            override fun onPageStop(s: GeckoSession, success: Boolean) {
                tab.loading = false; tab.progress = 100
                if (success && !tab.isPrivate && tab.url.startsWith("http")) {
                    try { history.add(tab.title.ifBlank { tab.url }, tab.url) } catch (t: Throwable) { Log.e(TAG, "histórico", t) }
                }
                listener.onTabUpdated(tab)
            }

            override fun onProgressChange(s: GeckoSession, progress: Int) {
                tab.progress = progress
                listener.onTabUpdated(tab)
            }

            override fun onSecurityChange(s: GeckoSession, securityInfo: GeckoSession.ProgressDelegate.SecurityInformation) {
                tab.secure = securityInfo.isSecure
                listener.onTabUpdated(tab)
            }
        }

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                s: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean,
            ) {
                tab.url = url ?: ""
                listener.onTabUpdated(tab)
            }

            override fun onCanGoBack(s: GeckoSession, canGoBack: Boolean) {
                tab.canGoBack = canGoBack; listener.onTabUpdated(tab)
            }

            override fun onCanGoForward(s: GeckoSession, canGoForward: Boolean) {
                tab.canGoForward = canGoForward; listener.onTabUpdated(tab)
            }

            // target="_blank" e window.open() iniciados pelo usuário chegam aqui;
            // pop-ups sem gesto passam pelo PromptHandler.onPopupPrompt e são negados.
            override fun onNewSession(s: GeckoSession, uri: String): GeckoResult<GeckoSession>? = try {
                val child = GeckoSession(newSessionSettings(tab.isPrivate))
                val childTab = register(child, tab.isPrivate)
                listener.onTabListChanged()
                selectWhenOpen(childTab, 0)
                GeckoResult.fromValue(child) // o Gecko abre a sessão devolvida
            } catch (t: Throwable) {
                Log.e(TAG, "onNewSession falhou", t); null
            }

            // Links eternal://… da página inicial viram comandos do app; nenhuma outra página pode usá-los.
            override fun onLoadRequest(
                s: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest,
            ): GeckoResult<AllowOrDeny>? {
                if (request.uri.startsWith("eternal://")) {
                    if (UrlUtils.isStartPage(tab.url)) {
                        val cmd = request.uri.removePrefix("eternal://").trimEnd('/')
                        main.post { try { listener.onAppCommand(cmd) } catch (t: Throwable) { Log.e(TAG, "cmd", t) } }
                    }
                    return GeckoResult.fromValue(AllowOrDeny.DENY)
                }
                return null // comportamento padrão
            }
        }

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(s: GeckoSession, title: String?) {
                tab.title = title ?: ""
                listener.onTabUpdated(tab)
            }

            override fun onCloseRequest(s: GeckoSession) = close(tab)

            override fun onCrash(s: GeckoSession) { Log.e(TAG, "Processo de conteúdo caiu: ${tab.url}"); recover(tab) }

            override fun onKill(s: GeckoSession) { Log.w(TAG, "Processo de conteúdo encerrado pelo sistema"); recover(tab) }

            override fun onFullScreen(s: GeckoSession, fullScreen: Boolean) = listener.onFullScreen(fullScreen)

            override fun onExternalResponse(s: GeckoSession, response: WebResponse) = listener.onDownload(response)
        }
        return tab
    }

    private fun selectWhenOpen(tab: Tab, attempt: Int) {
        main.postDelayed({
            when {
                !tabs.contains(tab) -> Unit
                tab.session.isOpen -> select(tab)
                attempt < 20 -> selectWhenOpen(tab, attempt + 1)
            }
        }, 50)
    }
}
