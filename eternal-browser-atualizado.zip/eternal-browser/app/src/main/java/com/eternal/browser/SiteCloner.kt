package com.eternal.browser

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Clona páginas (HTML + recursos) para uma pasta temporária, reescreve os links para caminhos locais
 * e entrega tudo em um .zip em Download/eternal_sites/. Rodar fora da main thread; cancelável.
 *
 * Rápido: as páginas de cada nível do rastreio e todos os arquivos (imagens, CSS, JS, fontes) são
 * baixados em paralelo, e o zip usa compressão veloz.
 */
class SiteCloner(private val ctx: Context) {

    data class Options(
        val maxDepth: Int = 2, val maxPages: Int = 50, val external: Boolean = true,
        val images: Boolean = true, val css: Boolean = true, val js: Boolean = true,
        val fonts: Boolean = false, val video: Boolean = false,
    )

    data class Progress(val pages: Int, val maxPages: Int, val current: String, val bytes: Long)
    data class Result(val pages: Int, val bytes: Long, val savedAs: String?, val cancelled: Boolean)

    private class Page(val base: String, val rel: String)
    private class CssFile(val rel: String, val base: String)

    @Volatile private var cancelled = false
    fun cancel() { cancelled = true }

    private val maxTotal = 300L * 1024 * 1024
    private val pageThreads = 6
    private val resourceThreads = 16
    private val nestedThreads = 8
    private val pageExt = setOf("html", "htm", "php", "asp", "aspx", "jsp", "shtml")
    private val fontExt = setOf("woff", "woff2", "ttf", "otf", "eot")
    private val imgExt = setOf("png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "avif")
    private val cssUrlRe = Regex("url\\(\\s*(['\"]?)([^'\")]+)\\1\\s*\\)")

    fun run(startUrlRaw: String, o: Options, onProgress: (Progress) -> Unit): Result {
        val startUrl = startUrlRaw.substringBefore('#')
        val stampMs = System.currentTimeMillis()
        val root = File(ctx.cacheDir, "clone-$stampMs")
        val zip = File(ctx.cacheDir, "clone-$stampMs.zip")
        val pagePool = Executors.newFixedThreadPool(pageThreads)
        val resPool = Executors.newFixedThreadPool(resourceThreads)
        val nestedPool = Executors.newFixedThreadPool(nestedThreads)
        try {
            root.mkdirs()
            val startHost = URL(startUrl).host
            val saved = ConcurrentHashMap<String, String>()
            val claimed: MutableSet<String> = ConcurrentHashMap.newKeySet<String>()
            val seen: MutableSet<String> = ConcurrentHashMap.newKeySet<String>()
            val finals: MutableSet<String> = ConcurrentHashMap.newKeySet<String>()
            val pages: MutableList<Page> = Collections.synchronizedList(ArrayList<Page>())
            val cssFiles: MutableList<CssFile> = Collections.synchronizedList(ArrayList<CssFile>())
            val bytes = AtomicLong(0)
            val reserved = AtomicInteger(0)

            var level: List<String> = listOf(startUrl)
            var depth = 0
            while (level.isNotEmpty() && !cancelled && reserved.get() < o.maxPages && bytes.get() < maxTotal) {
                val next: MutableList<String> = Collections.synchronizedList(ArrayList<String>())
                val jobs = ArrayList<Future<*>>()
                val currentDepth = depth
                for (url in level) {
                    if (!seen.add(url)) continue
                    jobs.add(pagePool.submit(Runnable {
                        crawlPage(
                            url, currentDepth, o, root, startHost, saved, claimed, finals, pages, cssFiles,
                            bytes, reserved, next, resPool, nestedPool, onProgress,
                        )
                    }))
                }
                for (j in jobs) { try { j.get() } catch (_: Throwable) { } }
                level = next.distinct().filter { it !in seen }
                depth++
            }

            if (cancelled) return Result(pages.size, bytes.get(), null, true)

            // Reescreve os links só depois que tudo foi baixado: assim nenhum arquivo fica sem destino.
            for (c in cssFiles.toList()) rewriteCss(root, c, saved)
            for (p in pages.toList()) rewritePage(root, p, saved)

            zip.parentFile?.mkdirs()
            ZipOutputStream(FileOutputStream(zip).buffered(64 * 1024)).use { z ->
                z.setLevel(Deflater.BEST_SPEED)
                root.walkTopDown().filter { it.isFile }.forEach { f ->
                    z.putNextEntry(ZipEntry(f.relativeTo(root).path.replace('\\', '/')))
                    f.inputStream().use { it.copyTo(z) }
                    z.closeEntry()
                }
            }
            val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
            val savedAs = Downloads.saveFile(ctx, "eternal_sites", "$startHost-$stamp.zip", "application/zip", zip)
            return Result(pages.size, bytes.get(), savedAs, false)
        } finally {
            pagePool.shutdownNow()
            resPool.shutdownNow()
            nestedPool.shutdownNow()
            root.deleteRecursively()
            zip.delete()
        }
    }

    // ---------- uma página ----------

    private fun crawlPage(
        url: String, depth: Int, o: Options, root: File, startHost: String,
        saved: ConcurrentHashMap<String, String>, claimed: MutableSet<String>, finals: MutableSet<String>,
        pages: MutableList<Page>, cssFiles: MutableList<CssFile>,
        bytes: AtomicLong, reserved: AtomicInteger, next: MutableList<String>,
        resPool: ExecutorService, nestedPool: ExecutorService, onProgress: (Progress) -> Unit,
    ) {
        if (cancelled || bytes.get() >= maxTotal) return
        if (reserved.incrementAndGet() > o.maxPages) { reserved.decrementAndGet(); return }
        val resp = try { Net.get(url) } catch (_: Throwable) { reserved.decrementAndGet(); return }
        if (resp.type.isNotBlank() && !resp.type.contains("html", true)) { reserved.decrementAndGet(); return }
        val base = resp.finalUrl
        if (!finals.add(base)) { reserved.decrementAndGet(); return }

        val html = Net.text(resp)
        val rel = localRel(base, true)
        write(root, rel, resp.bytes)
        bytes.addAndGet(resp.bytes.size.toLong())
        saved[url] = rel
        saved[base] = rel
        pages.add(Page(base, rel))
        onProgress(Progress(pages.size, o.maxPages, url, bytes.get()))

        val found = HtmlScan.scan(html, base)
        val wanted = ArrayList<String>()
        if (o.images) wanted += found.images
        if (o.css) wanted += found.css
        if (o.js) wanted += found.js
        if (o.fonts) wanted += found.fonts
        if (o.video) wanted += found.media

        val downloads = ArrayList<Future<*>>()
        for (ref in wanted.distinct()) {
            if (cancelled) break
            if (!o.external && hostOf(ref) != startHost) continue
            if (!claimed.add(ref)) continue
            downloads.add(resPool.submit(Runnable {
                if (!cancelled && bytes.get() < maxTotal) grab(ref, root, saved, claimed, cssFiles, o, startHost, bytes, nestedPool)
            }))
        }
        for (d in downloads) { try { d.get() } catch (_: Throwable) { } }

        if (depth < o.maxDepth) {
            found.links.filter { hostOf(it) == startHost && looksLikePage(it) }.forEach { next.add(it) }
        }
    }

    // ---------- recursos ----------

    private fun grab(
        ref: String, root: File, saved: ConcurrentHashMap<String, String>, claimed: MutableSet<String>,
        cssFiles: MutableList<CssFile>, o: Options, startHost: String, bytes: AtomicLong, nestedPool: ExecutorService,
    ) {
        val r = try { Net.get(ref, 25_000_000) } catch (_: Throwable) { return }
        val rel = localRel(ref, false)
        write(root, rel, r.bytes)
        saved[ref] = rel
        bytes.addAndGet(r.bytes.size.toLong())

        if (rel.endsWith(".css") || r.type.contains("css", true)) {
            cssFiles.add(CssFile(rel, r.finalUrl))
            // Imagens e fontes citadas dentro do CSS: baixadas em paralelo, links reescritos no final.
            val css = String(r.bytes, Charsets.UTF_8)
            val nested = ArrayList<Future<*>>()
            for (m in cssUrlRe.findAll(css)) {
                val target = HtmlScan.resolve(r.finalUrl, m.groupValues[2]) ?: continue
                if (!cssTargetWanted(target, o, startHost)) continue
                if (!claimed.add(target)) continue
                nested.add(nestedPool.submit(Runnable {
                    if (!cancelled) downloadPlain(target, root, saved, bytes)
                }))
            }
            for (n in nested) { try { n.get() } catch (_: Throwable) { } }
        }
    }

    private fun cssTargetWanted(target: String, o: Options, startHost: String): Boolean {
        val ext = target.substringBefore('?').substringAfterLast('.', "").lowercase()
        val ok = (ext in fontExt && o.fonts) || (ext in imgExt && o.images)
        return ok && (o.external || hostOf(target) == startHost)
    }

    private fun downloadPlain(target: String, root: File, saved: ConcurrentHashMap<String, String>, bytes: AtomicLong) {
        val r = try { Net.get(target, 25_000_000) } catch (_: Throwable) { return }
        val rel = localRel(target, false)
        write(root, rel, r.bytes)
        saved[target] = rel
        bytes.addAndGet(r.bytes.size.toLong())
    }

    private fun rewriteCss(root: File, c: CssFile, saved: Map<String, String>) {
        val f = File(root, c.rel)
        if (!f.exists()) return
        val css = String(f.readBytes(), Charsets.UTF_8)
        val out = cssUrlRe.replace(css) { m ->
            val target = HtmlScan.resolve(c.base, m.groupValues[2])
            val local = target?.let { saved[it] }
            if (local != null) "url(" + relPath(c.rel, local) + ")" else m.value
        }
        f.writeBytes(out.toByteArray(Charsets.UTF_8))
    }

    private fun rewritePage(root: File, p: Page, saved: Map<String, String>) {
        val f = File(root, p.rel)
        if (!f.exists()) return
        val bytes = f.readBytes()
        val text = String(bytes, Charsets.UTF_8)
        val tagRe = Regex("<(img|link|script|a|video|audio|source)\\b[^>]*>", RegexOption.IGNORE_CASE)
        val attrRe = Regex("\\b(src|href)\\s*=\\s*([\"'])([^\"']*)\\2", RegexOption.IGNORE_CASE)
        val out = tagRe.replace(text) { tm ->
            attrRe.replace(tm.value) { am ->
                val target = HtmlScan.resolve(p.base, am.groupValues[3])
                val local = target?.let { saved[it] }
                if (local != null) "${am.groupValues[1]}=${am.groupValues[2]}${relPath(p.rel, local)}${am.groupValues[2]}" else am.value
            }
        }
        f.writeBytes(out.toByteArray(Charsets.UTF_8))
    }

    // ---------- caminhos ----------

    private fun write(root: File, rel: String, data: ByteArray) {
        val f = File(root, rel)
        f.parentFile?.mkdirs()
        f.writeBytes(data)
    }

    private fun hostOf(url: String): String = try { URL(url).host } catch (_: Throwable) { "" }

    private fun looksLikePage(url: String): Boolean {
        val last = try { URL(url).path.substringAfterLast('/') } catch (_: Throwable) { return false }
        if (!last.contains('.')) return true
        return last.substringAfterLast('.').lowercase() in pageExt
    }

    private fun localRel(url: String, isPage: Boolean): String {
        val u = URL(url)
        var p = u.path
        if (p.isEmpty() || p.endsWith("/")) p += "index.html"
        else if (isPage && p.substringAfterLast('/').substringAfterLast('.', "").lowercase() !in setOf("html", "htm")) p += ".html"
        val q = u.query
        if (q != null) {
            val h = Integer.toHexString(q.hashCode())
            val dot = p.lastIndexOf('.')
            p = if (dot > p.lastIndexOf('/')) p.substring(0, dot) + "_q" + h + p.substring(dot) else p + "_q" + h
        }
        return (u.host + p).replace(Regex("[^A-Za-z0-9._/\\-]"), "_")
    }

    /** Caminho relativo de [from] (arquivo) até [to] (arquivo), ambos relativos à raiz. */
    private fun relPath(from: String, to: String): String {
        val f = from.split('/').dropLast(1)
        val t = to.split('/')
        var i = 0
        while (i < f.size && i < t.size - 1 && f[i] == t[i]) i++
        return "../".repeat(f.size - i) + t.drop(i).joinToString("/")
    }
}
