package com.eternal.browser

import android.app.Application
import android.os.Build
import android.util.Log
import java.io.File
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings

import com.eternal.browser.core.storage.PrefsKeys
import com.eternal.browser.core.storage.Prefs
class EternalApplication : Application() {
    companion object {
        private const val TAG = "EternalApp"

        lateinit var runtime: GeckoRuntime
            private set
        @Volatile
        var initializationFailure: Throwable? = null
            private set

        /** false se GeckoRuntime.create falhou: a Activity mostra aviso em vez de crashar. */
        fun isReady(): Boolean = ::runtime.isInitialized

        /**
         * Application.onCreate roda em TODO processo do app, inclusive nos processos filhos do Gecko
         * (:tab, :gpu, :socket, :extensions...). Só o processo principal pode criar o GeckoRuntime.
         */
        fun isMainProcess(app: Application): Boolean {
            val name = if (Build.VERSION.SDK_INT >= 28) {
                Application.getProcessName()
            } else {
                try { File("/proc/self/cmdline").readText().trim('\u0000', ' ') } catch (_: Throwable) { null }
            }
            return name == null || name == app.packageName
        }
    }

    /**
     * O GeckoRuntimeSettings.Builder não tem método para prefs; o caminho suportado é o arquivo de
     * configuração YAML (seção "prefs"), que o GeckoView lê quando apontado por configFilePath(),
     * inclusive em build release. No canal Nightly isso desliga a exigência de assinatura das extensões.
     * Devolve o caminho do arquivo, ou null se não deu para gravar.
     */
    private fun writeGeckoConfig(): String? = try {
        val f = File(filesDir, "geckoview-config.yaml")
        f.writeText(
            "prefs:\n" +
                "  xpinstall.signatures.required: false\n" +
                "  extensions.langpacks.signatures.required: false\n"
        )
        f.absolutePath
    } catch (t: Throwable) {
        Log.e(TAG, "não foi possível gravar a config do GeckoView", t)
        null
    }

    /**
     * Configurações da tela de Configurações que são do motor e só valem na criação do runtime.
     * Cada uma é aplicada isoladamente: se alguma falhar, é ignorada e o motor sobe do mesmo jeito.
     */
    private fun applyUserSettings(b: GeckoRuntimeSettings.Builder, p: Prefs) {
        fun safe(block: () -> Unit) {
            try { block() } catch (t: Throwable) { Log.w(TAG, "configuração ignorada", t) }
        }
        safe { b.javaScriptEnabled(p.getBool(PrefsKeys.JS_ENABLED, true)) }
        safe { b.webFontsEnabled(p.getBool(PrefsKeys.WEB_FONTS, true)) }
        safe { b.doubleTapZoomingEnabled(p.getBool(PrefsKeys.DOUBLE_TAP_ZOOM, true)) }
        safe { b.forceUserScalableEnabled(p.getBool(PrefsKeys.FORCE_ZOOM, false)) }
        safe { b.inputAutoZoomEnabled(p.getBool(PrefsKeys.INPUT_AUTOZOOM, true)) }
        safe { b.globalPrivacyControlEnabled(p.getBool(PrefsKeys.GPC, false)) }
        safe { b.aboutConfigEnabled(BuildConfig.DEBUG || p.getBool(PrefsKeys.ABOUT_CONFIG, false)) }
        safe { b.consoleOutput(BuildConfig.DEBUG || p.getBool(PrefsKeys.CONSOLE_OUTPUT, false)) }
        safe {
            val f = p.getStr(PrefsKeys.FONT_SCALE, "1.0").toFloatOrNull() ?: 1f
            if (f != 1f) b.fontSizeFactor(f)
        }
        safe {
            val l = p.getStr(PrefsKeys.LOCALE, "")
            if (l.isNotBlank()) b.locales(arrayOf(l))
        }
    }

    override fun onCreate() {
        super.onCreate()
        // Mais conexões reaproveitáveis por host: a clonagem baixa muitos arquivos em paralelo.
        System.setProperty("http.maxConnections", "32")
        // Processos filhos do Gecko não podem criar outro GeckoRuntime nem mexer no estado de inicialização:
        // antes, cada processo filho criava um runtime próprio e ligava o "modo seguro" sozinho.
        if (!isMainProcess(this)) return
        CrashReporter.install(this)
        if (isReady()) return
        val prefs = Prefs(this)
        // Modo seguro é SOMENTE manual (menu). Versões anteriores o ligavam sozinho e salvavam o valor:
        // uma única vez, desliga o que ficou gravado por aquela lógica automática.
        if (!prefs.safeModeReset) { prefs.safeMode = false; prefs.safeModeReset = true }
        prefs.startPending = true
        try {
            // Bloqueio de anúncios/rastreadores nativo do Gecko (Enhanced Tracking Protection).
            // Para bloqueio mais agressivo, instale o uBlock Origin pelo menu Extensões.
            val contentBlocking = ContentBlocking.Settings.Builder()
                .antiTracking(
                    ContentBlocking.AntiTracking.AD or
                        ContentBlocking.AntiTracking.ANALYTIC or
                        ContentBlocking.AntiTracking.SOCIAL or
                        ContentBlocking.AntiTracking.CRYPTOMINING or
                        ContentBlocking.AntiTracking.FINGERPRINTING or
                        ContentBlocking.AntiTracking.CONTENT or
                        ContentBlocking.AntiTracking.STP
                )
                .enhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.STRICT)
                .cookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS)
                .safeBrowsing(ContentBlocking.SafeBrowsing.DEFAULT)
                .build()

            val builder = GeckoRuntimeSettings.Builder()
                .contentBlocking(contentBlocking)
                .javaScriptEnabled(true)
                .extensionsProcessEnabled(!prefs.safeMode)
                .extensionsWebAPIEnabled(true)
                // about:config e depuração remota SÓ em debug (no release seriam brechas de segurança).
                .aboutConfigEnabled(BuildConfig.DEBUG)
                .remoteDebuggingEnabled(BuildConfig.DEBUG || prefs.remoteDebug)
                .consoleOutput(BuildConfig.DEBUG)
                .debugLogging(BuildConfig.DEBUG)
                .preferredColorScheme(
                    if (prefs.nightMode) GeckoRuntimeSettings.COLOR_SCHEME_DARK
                    else GeckoRuntimeSettings.COLOR_SCHEME_SYSTEM
                )
            applyUserSettings(builder, prefs)
            writeGeckoConfig()?.let { builder.configFilePath(it) }
            val settings = builder.build()

            runtime = GeckoRuntime.create(this, settings)
            Log.i(TAG, "GeckoRuntime OK")
        } catch (t: Throwable) {
            initializationFailure = t
            Log.e(TAG, "Falha ao criar GeckoRuntime", t)
        }
    }
}
