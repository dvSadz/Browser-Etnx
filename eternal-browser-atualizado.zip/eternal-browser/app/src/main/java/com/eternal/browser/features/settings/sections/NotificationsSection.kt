package com.eternal.browser.features.settings.sections

import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.Prefs
object NotificationsSection {
    fun build(prefs: Prefs) = SettingSection("NOTIFICAÇÕES", listOf(
        SettingItem.Action("notification_settings", "Configurações de notificação do Android", "Abre os controles de notificação do ETERNAL no sistema"),
        SettingItem.Info("Downloads", "A notificação de conclusão de download também pode ser ligada ou desligada na seção Downloads."),
    ))
}
