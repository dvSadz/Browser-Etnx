package com.eternal.browser

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.Charset

/** Download simples (HttpURLConnection) usado por código-fonte, clonagem e extração. Sempre chamar fora da main thread. */
object Net {
    const val UA = "Mozilla/5.0 (Linux; Android 14; Mobile) ETERNAL/1.0"

    class Resp(val bytes: ByteArray, val type: String, val charset: String, val finalUrl: String)

    fun get(url: String, maxBytes: Int = 20_000_000): Resp = try {
        fetch(url, maxBytes)
    } catch (e: IOException) {
        // Android bloqueia http:// sem criptografia para este código: tenta a versão https.
        if (url.startsWith("http://") && (e.message ?: "").contains("leartext", true)) fetch("https://" + url.removePrefix("http://"), maxBytes)
        else throw e
    }

    private fun fetch(start: String, maxBytes: Int): Resp {
        var cur = start
        repeat(6) {
            if (!(cur.startsWith("http://") || cur.startsWith("https://"))) throw IOException("endereço não suportado")
            val c = URL(cur).openConnection() as HttpURLConnection
            try {
                c.instanceFollowRedirects = false
                c.connectTimeout = 10_000
                c.readTimeout = 15_000
                c.setRequestProperty("User-Agent", UA)
                c.setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9,en;q=0.8")
                val code = c.responseCode
                if (code in intArrayOf(301, 302, 303, 307, 308)) {
                    val loc = c.getHeaderField("Location") ?: throw IOException("redirecionamento inválido")
                    cur = URL(URL(cur), loc).toString()
                    return@repeat
                }
                if (code >= 400) throw IOException("HTTP $code")
                val type = c.contentType ?: ""
                val cs = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(type)?.groupValues?.get(1) ?: "UTF-8"
                val out = ByteArrayOutputStream()
                c.inputStream.use { input ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        if (out.size() > maxBytes) break
                    }
                }
                return Resp(out.toByteArray(), type, cs, cur)
            } finally {
                c.disconnect()
            }
        }
        throw IOException("redirecionamentos demais")
    }

    fun text(r: Resp): String = try {
        String(r.bytes, Charset.forName(r.charset))
    } catch (_: Throwable) {
        String(r.bytes, Charsets.UTF_8)
    }
}
