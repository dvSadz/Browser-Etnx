package com.eternal.browser

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.app.Application
import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
import java.util.Date

import com.eternal.browser.core.storage.Prefs
/**
 * Registra o stack trace de qualquer exceção Java não tratada em arquivo e mostra no próximo
 * start do app (assim dá para diagnosticar o crash sem adb). Crashes nativos do Gecko não passam
 * por aqui: para eles existe o "rastro de navegação" (Prefs.navBreadcrumb), que diz qual
 * endereço estava carregando quando o processo morreu.
 */
object CrashReporter {
    private const val FILE = "last_crash.txt"

    fun install(app: Application) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                File(app.filesDir, FILE).writeText(
                    "${Date()}\nthread=${thread.name}\n${Log.getStackTraceString(error)}"
                )
            } catch (_: Throwable) { /* nunca falhar dentro do handler */ }
            previous?.uncaughtException(thread, error)
        }
    }

    /** Lê e apaga o relatório do crash anterior (null = não houve). */
    fun consume(context: Context): String? = try {
        val f = File(context.filesDir, FILE)
        if (f.exists()) f.readText().also { f.delete() } else null
    } catch (_: Throwable) { null }

    /**
     * Motivo registrado pelo Android para a morte do processo anterior (API 30+): CRASH_NATIVE = queda
     * dentro do Gecko (libxul), CRASH = exceção Java, LOW_MEMORY, ANR etc. Só devolve saídas anormais novas.
     */
    fun exitInfo(context: Context, prefs: Prefs): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val last = am.getHistoricalProcessExitReasons(context.packageName, 0, 5)
                .firstOrNull { it.processName == context.packageName } ?: return null
            val abnormal = last.reason in setOf(
                ApplicationExitInfo.REASON_CRASH, ApplicationExitInfo.REASON_CRASH_NATIVE,
                ApplicationExitInfo.REASON_ANR, ApplicationExitInfo.REASON_LOW_MEMORY,
                ApplicationExitInfo.REASON_SIGNALED, ApplicationExitInfo.REASON_INITIALIZATION_FAILURE,
                ApplicationExitInfo.REASON_DEPENDENCY_DIED, ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE,
            )
            if (!abnormal || last.timestamp <= prefs.lastExitReported) return null
            prefs.lastExitReported = last.timestamp
            val name = when (last.reason) {
                ApplicationExitInfo.REASON_CRASH -> "CRASH (exceção Java)"
                ApplicationExitInfo.REASON_CRASH_NATIVE -> "CRASH_NATIVE (queda nativa, provavelmente no Gecko)"
                ApplicationExitInfo.REASON_ANR -> "ANR (app travado)"
                ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW_MEMORY (sem memória)"
                ApplicationExitInfo.REASON_SIGNALED -> "SIGNALED (morto por sinal)"
                else -> "reason=${last.reason}"
            }
            "${Date(last.timestamp)}\n$name\nstatus=${last.status} rss=${last.rss / 1024}MB\n${last.description ?: ""}"
        } catch (t: Throwable) { null }
    }

    /** Últimas linhas relevantes do logcat do próprio app (um app lê só os logs do seu próprio uid). */
    fun recentLog(): String? = try {
        val p = Runtime.getRuntime().exec(arrayOf("logcat", "-d", "-t", "600"))
        val re = Regex("gecko|eternal|androidruntime|fatal|libc|crash|signal|exception|\\sE\\s", RegexOption.IGNORE_CASE)
        val lines = p.inputStream.bufferedReader().readLines().filter { re.containsMatchIn(it) }
        lines.takeLast(40).joinToString("\n") { it.take(220) }.ifBlank { null }
    } catch (t: Throwable) { null }
}
