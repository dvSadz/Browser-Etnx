package com.eternal.browser.extensions

import android.app.Activity
import com.eternal.browser.R

/** Transições (200–300 ms) das telas de extensão. */
object ExtensionTransitions {
    @Suppress("DEPRECATION")
    fun slideIn(a: Activity) = a.overridePendingTransition(R.anim.ext_slide_in_right, R.anim.ext_hold)

    @Suppress("DEPRECATION")
    fun slideOut(a: Activity) = a.overridePendingTransition(R.anim.ext_hold, R.anim.ext_slide_out_right)

    @Suppress("DEPRECATION")
    fun none(a: Activity) = a.overridePendingTransition(0, 0)
}
