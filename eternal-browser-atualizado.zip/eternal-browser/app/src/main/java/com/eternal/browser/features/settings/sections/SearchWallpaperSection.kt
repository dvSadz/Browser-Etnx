package com.eternal.browser.features.settings.sections

import com.eternal.browser.core.storage.Prefs
import com.eternal.browser.core.storage.PrefsKeys
import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

/** Wallpaper de fundo nas páginas de resultados de busca (Google, Bing, DuckDuckGo…). */
object SearchWallpaperSection {
    const val ACTION_IMPORT = "search_wallpaper_import"
    const val ACTION_RESTORE = "search_wallpaper_restore"

    @Suppress("UNUSED_PARAMETER")
    fun build(prefs: Prefs) = SettingSection("WALLPAPER DA PESQUISA", listOf(
        SettingItem.Toggle(PrefsKeys.SEARCH_WALLPAPER_ENABLED, "Ativar wallpaper na página de pesquisa",
            "Troca o fundo dos resultados de busca pelo wallpaper escolhido", true),
        SettingItem.Action(ACTION_IMPORT, "Importar wallpaper", "Escolha uma imagem da galeria ou dos arquivos"),
        SettingItem.Action(ACTION_RESTORE, "Restaurar padrão", "Remove o wallpaper e volta ao fundo normal"),
        SettingItem.Range(PrefsKeys.SEARCH_WALLPAPER_DIM, "Escurecer wallpaper",
            "Melhora a leitura dos resultados", 0, 80, 40, "%"),
    ))
}
