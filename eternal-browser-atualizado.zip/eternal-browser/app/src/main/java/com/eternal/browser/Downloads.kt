package com.eternal.browser

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import java.io.File
import java.io.OutputStream

/** Salva arquivos em Download/<subdir>/. No Android 10+ usa MediaStore (sem permissão); antes, grava direto. */
object Downloads {
    fun save(ctx: Context, subdir: String, name: String, mime: String, write: (OutputStream) -> Unit): String? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$subdir")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return null
                (ctx.contentResolver.openOutputStream(uri) ?: return null).use(write)
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), subdir)
                dir.mkdirs()
                File(dir, name).outputStream().use(write)
            }
            "Download/$subdir/$name"
        } catch (t: Throwable) {
            Log.e("EternalDownloads", "falha ao salvar $name", t)
            null
        }
    }

    fun saveFile(ctx: Context, subdir: String, name: String, mime: String, file: File): String? =
        save(ctx, subdir, name, mime) { out -> file.inputStream().use { it.copyTo(out) } }

    fun saveText(ctx: Context, subdir: String, name: String, text: String): String? =
        save(ctx, subdir, name, "text/plain") { it.write(text.toByteArray(Charsets.UTF_8)) }
}
