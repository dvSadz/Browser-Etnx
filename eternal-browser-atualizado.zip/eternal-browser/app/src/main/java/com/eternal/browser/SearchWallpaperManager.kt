package com.eternal.browser

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import com.eternal.browser.core.storage.Prefs
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import org.json.JSONObject
import org.mozilla.geckoview.WebExtension

/**
 * Wallpaper no fundo das páginas de resultados de busca.
 *
 * O GeckoView não tem evaluateJS; a injeção é feita por uma extensão embutida (assets/searchwallpaper), no mesmo
 * esquema do modo noturno: o app manda { enabled, dim, dataUrl } pela porta nativa "eternal" e o content script
 * aplica um override GENÉRICO de fundo (sem cores nem classes de nenhum site) nas páginas de busca.
 *
 * `content://` não funciona em CSS de página web, então a imagem é lida do URI, reduzida, convertida para data URL
 * (base64) e guardada em cache na memória; o SharedPreferences guarda só o URI. Tudo fora da UI thread.
 */
class SearchWallpaperManager(
    private val context: Context,
    private val prefs: Prefs,
) {
    companion object {
        const val EXTENSION_URI = "resource://android/assets/searchwallpaper/"
        const val EXTENSION_ID = "searchwallpaper@eternal.browser"
        const val NATIVE_APP = "eternal"

        private const val TAG = "SearchWallpaper"
        private const val MAX_EDGE = 1920 // maior lado do wallpaper enviado às páginas
        private const val JPEG_QUALITY = 85

        private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "eternal-search-wallpaper").apply { isDaemon = true } }

        /** Miniatura para a tela de Configurações. Nunca lança; null se o URI está vazio, sem permissão ou não é imagem. */
        fun loadThumbnail(context: Context, uriString: String, reqW: Int, reqH: Int): Bitmap? =
            if (uriString.isBlank()) null else decode(context, Uri.parse(uriString), reqW, reqH)

        private fun decode(context: Context, uri: Uri, reqW: Int, reqH: Int): Bitmap? = try {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                null
            } else {
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= reqW && bounds.outHeight / (sample * 2) >= reqH) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (bmp == null) null else rotate(bmp, exifDegrees(context, uri))
            }
        } catch (t: Throwable) { // SecurityException (permissão perdida), arquivo apagado, OutOfMemoryError…
            Log.w(TAG, "imagem indisponível: $uri", t)
            null
        }

        /** Fotos de câmera trazem a orientação no EXIF. */
        private fun exifDegrees(context: Context, uri: Uri): Float = try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                when (ExifInterface(input).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (_: Throwable) { 0f }

        private fun rotate(bmp: Bitmap, degrees: Float): Bitmap {
            if (degrees == 0f) return bmp
            return try {
                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(degrees) }, true)
            } catch (_: Throwable) { bmp }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var port: WebExtension.Port? = null

    /** Cache do data URL (o base64 não vai para o SharedPreferences: é grande). */
    @Volatile private var cachedUri: String? = null
    @Volatile private var cachedDataUrl: String? = null

    /** Última configuração enviada à extensão, para não reenviar centenas de KB sem necessidade. */
    private var lastSent: String? = null

    /** Chamado quando a extensão embutida foi carregada. */
    fun bind(extension: WebExtension) {
        extension.setMessageDelegate(object : WebExtension.MessageDelegate {
            override fun onConnect(port: WebExtension.Port) {
                this@SearchWallpaperManager.port = port
                lastSent = null
                port.setDelegate(object : WebExtension.PortDelegate {
                    override fun onDisconnect(port: WebExtension.Port) {
                        if (this@SearchWallpaperManager.port === port) this@SearchWallpaperManager.port = null
                    }
                })
                apply()
            }
        }, NATIVE_APP)
    }

    /** Lê as preferências e envia à extensão (se mudou). Seguro para chamar a qualquer momento. */
    fun apply() {
        val enabled = prefs.searchWallpaperEnabled
        val uri = prefs.searchWallpaperUri
        val dim = prefs.searchWallpaperDim
        io.execute {
            try {
                val dataUrl = if (enabled && uri.isNotBlank()) dataUrlFor(uri) else null
                val payload = JSONObject()
                    .put("enabled", dataUrl != null)
                    .put("dim", dim)
                    .put("dataUrl", dataUrl ?: "")
                val signature = "${dataUrl != null}|$dim|$uri"
                main.post {
                    try {
                        if (signature == lastSent) return@post
                        val p = port ?: return@post
                        p.postMessage(payload)
                        lastSent = signature
                    } catch (t: Throwable) { Log.e(TAG, "falha ao enviar à extensão", t) }
                }
            } catch (t: Throwable) {
                Log.e(TAG, "falha ao preparar o wallpaper", t)
            }
        }
    }

    private fun dataUrlFor(uriString: String): String? {
        if (uriString == cachedUri) cachedDataUrl?.let { return it }
        val uri = Uri.parse(uriString)
        var bmp = decode(context, uri, MAX_EDGE, MAX_EDGE) ?: return null
        val longest = maxOf(bmp.width, bmp.height)
        if (longest > MAX_EDGE) {
            val k = MAX_EDGE.toFloat() / longest
            bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true)
        }
        // PNG só se a imagem tem transparência; do contrário JPEG (muito menor para a página carregar).
        val png = bmp.hasAlpha()
        val out = ByteArrayOutputStream()
        if (png) bmp.compress(Bitmap.CompressFormat.PNG, 100, out) else bmp.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        val data = (if (png) "data:image/png;base64," else "data:image/jpeg;base64,") +
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        cachedUri = uriString
        cachedDataUrl = data
        return data
    }
}
