package com.eternal.browser.features.settings.sections

import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.Prefs
object SyncBackupSection {
    fun build(prefs: Prefs) = SettingSection("SINCRONIZAÇÃO E BACKUP", listOf(
        SettingItem.Action("export", "Exportar configurações", "Compartilha um JSON com as opções desta tela"),
        SettingItem.Action("import", "Importar configurações", "Cole um JSON exportado anteriormente"),
        SettingItem.Info("Sincronização de conta", "Sincronização com conta e backup integral do perfil ainda não estão disponíveis. A exportação inclui somente as configurações registradas."),
    ))
}
