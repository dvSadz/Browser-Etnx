package com.eternal.browser.features.settings.sections

import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.PrefsKeys
import com.eternal.browser.core.storage.Prefs
object AccessibilitySection {
    fun build(prefs: Prefs) = SettingSection("ACESSIBILIDADE", listOf(
        SettingItem.Toggle(PrefsKeys.FORCE_ZOOM, "Forçar zoom", "Permite ampliar páginas que tentam bloquear o zoom", false, restart = true),
        SettingItem.Choice(PrefsKeys.FONT_SCALE, "Tamanho do texto das páginas", null,
            listOf("0.8" to "80%", "1.0" to "100%", "1.2" to "120%", "1.5" to "150%", "2.0" to "200%"), "1.0", restart = true),
    ))
}
