package com.eternal.browser

import java.net.URL

/** Extrai URLs de recursos de um HTML (regex simples: suficiente para ver fonte, extrair e clonar). */
object HtmlScan {
    class Found(
        val images: List<String>, val css: List<String>, val js: List<String>,
        val fonts: List<String>, val media: List<String>, val links: List<String>,
    ) {
        val all: List<String> get() = (images + css + js + fonts + media + links).distinct()
    }

    private val tagRe = Regex("<(img|link|script|a|video|audio|source)\\b[^>]*>", RegexOption.IGNORE_CASE)

    fun attr(tag: String, name: String): String? =
        Regex("\\b$name\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')", RegexOption.IGNORE_CASE).find(tag)
            ?.let { it.groupValues[1].ifEmpty { it.groupValues[2] } }

    /** Resolve [ref] contra [base]; devolve null para âncoras, data:, javascript:, mailto: etc. */
    fun resolve(base: String, ref: String): String? {
        val r = ref.trim()
        if (r.isEmpty() || r.startsWith("#") || r.startsWith("data:") || r.startsWith("javascript:") ||
            r.startsWith("mailto:") || r.startsWith("tel:") || r.startsWith("blob:")
        ) return null
        return try {
            val u = URL(URL(base), r).toString().substringBefore('#')
            if (u.startsWith("http://") || u.startsWith("https://")) u else null
        } catch (_: Throwable) { null }
    }

    fun scan(html: String, base: String): Found {
        val images = LinkedHashSet<String>(); val css = LinkedHashSet<String>(); val js = LinkedHashSet<String>()
        val fonts = LinkedHashSet<String>(); val media = LinkedHashSet<String>(); val links = LinkedHashSet<String>()
        for (m in tagRe.findAll(html)) {
            val tag = m.value
            when (m.groupValues[1].lowercase()) {
                "img" -> attr(tag, "src")?.let { resolve(base, it) }?.let { images.add(it) }
                "script" -> attr(tag, "src")?.let { resolve(base, it) }?.let { js.add(it) }
                "a" -> attr(tag, "href")?.let { resolve(base, it) }?.let { links.add(it) }
                "video", "audio", "source" -> attr(tag, "src")?.let { resolve(base, it) }?.let { media.add(it) }
                "link" -> {
                    val rel = (attr(tag, "rel") ?: "").lowercase()
                    val href = attr(tag, "href")?.let { resolve(base, it) } ?: continue
                    val asType = (attr(tag, "as") ?: "").lowercase()
                    when {
                        rel.contains("stylesheet") -> css.add(href)
                        rel.contains("icon") -> images.add(href)
                        asType == "font" -> fonts.add(href)
                        rel.contains("preload") && asType == "image" -> images.add(href)
                    }
                }
            }
        }
        return Found(images.toList(), css.toList(), js.toList(), fonts.toList(), media.toList(), links.toList())
    }
}
