package com.eternal.browser.features.settings.sections

import com.eternal.browser.BuildConfig
import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.Prefs
object AboutSection {
    fun build(prefs: Prefs) = SettingSection("SOBRE", listOf(
        SettingItem.Action("version", "Versão", BuildConfig.VERSION_NAME),
        SettingItem.Action("licenses", "Sobre e licenças", "Informações sobre o GeckoView e o projeto"),
    ))
}
