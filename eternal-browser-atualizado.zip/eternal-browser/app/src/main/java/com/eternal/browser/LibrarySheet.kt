package com.eternal.browser

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog

import com.eternal.browser.core.storage.LibraryStore
import com.eternal.browser.core.storage.Entry
/** Favoritos e histórico em um bottom sheet com duas abas. */
class LibrarySheet(
    private val activity: AppCompatActivity,
    private val bookmarks: LibraryStore,
    private val history: LibraryStore,
    private val onOpen: (String) -> Unit,
) {
    private var showBookmarks = true
    private var items: List<Entry> = emptyList()

    fun show(startOnBookmarks: Boolean) {
        showBookmarks = startOnBookmarks
        val dialog = BottomSheetDialog(activity)
        val view = LayoutInflater.from(activity).inflate(R.layout.sheet_library, null)
        val tabBm = view.findViewById<TextView>(R.id.libTabBookmarks)
        val tabHist = view.findViewById<TextView>(R.id.libTabHistory)
        val clear = view.findViewById<TextView>(R.id.libClear)
        val empty = view.findViewById<TextView>(R.id.libEmpty)
        val list = view.findViewById<RecyclerView>(R.id.libList)

        val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
                object : RecyclerView.ViewHolder(
                    LayoutInflater.from(parent.context).inflate(R.layout.item_library, parent, false)
                ) {}

            override fun getItemCount() = items.size

            override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
                val e = items.getOrNull(position) ?: return
                h.itemView.findViewById<TextView>(R.id.itemTitle).text = e.title.ifBlank { e.url }
                h.itemView.findViewById<TextView>(R.id.itemUrl).text = UrlUtils.display(e.url)
                h.itemView.setOnClickListener { onOpen(e.url); dialog.dismiss() }
                h.itemView.findViewById<ImageButton>(R.id.itemClose).setOnClickListener {
                    (if (showBookmarks) bookmarks else history).remove(e.url)
                    refresh(tabBm, tabHist, clear, empty, list)
                }
            }
        }
        list.layoutManager = LinearLayoutManager(activity)
        list.adapter = adapter

        tabBm.setOnClickListener { showBookmarks = true; refresh(tabBm, tabHist, clear, empty, list) }
        tabHist.setOnClickListener { showBookmarks = false; refresh(tabBm, tabHist, clear, empty, list) }
        clear.setOnClickListener { history.clear(); refresh(tabBm, tabHist, clear, empty, list) }

        refresh(tabBm, tabHist, clear, empty, list)
        dialog.setContentView(view)
        dialog.show()
    }

    private fun refresh(tabBm: TextView, tabHist: TextView, clear: TextView, empty: TextView, list: RecyclerView) {
        items = (if (showBookmarks) bookmarks else history).all()
        list.adapter?.notifyDataSetChanged()
        tabBm.alpha = if (showBookmarks) 1f else 0.45f
        tabHist.alpha = if (showBookmarks) 0.45f else 1f
        empty.setText(if (showBookmarks) R.string.bookmarks_empty else R.string.history_empty)
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        clear.visibility = if (!showBookmarks && items.isNotEmpty()) View.VISIBLE else View.GONE
    }
}
