package com.eternal.browser.extensions

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.eternal.browser.R
import com.google.android.material.materialswitch.MaterialSwitch
import org.mozilla.geckoview.WebExtension

class ExtensionsAdapter(
    private val actions: ExtensionActionManager,
    private val onPlay: (WebExtension) -> Unit,
    private val onOpenOptions: (WebExtension) -> Unit,
    private val onOpenSidebar: (WebExtension) -> Unit,
    private val onToggle: (WebExtension, Boolean) -> Unit,
    private val onRemove: (WebExtension) -> Unit,
) : RecyclerView.Adapter<ExtensionsAdapter.VH>() {

    private val items = mutableListOf<WebExtension>()
    private var animatedUpTo = -1

    fun submitList(list: List<WebExtension>) {
        items.clear()
        items.addAll(list)
        animatedUpTo = -1
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.extIcon)
        val name: TextView = v.findViewById(R.id.extName)
        val version: TextView = v.findViewById(R.id.extVersion)
        val sw: MaterialSwitch = v.findViewById(R.id.extSwitch)
        val btnPlay: View = v.findViewById(R.id.btnPlay)
        val btnOptions: View = v.findViewById(R.id.btnOptions)
        val btnSidebar: View = v.findViewById(R.id.btnSidebar)
        val btnRemove: View = v.findViewById(R.id.btnRemove)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_extension, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val ext = items[position]
        val meta = try { ext.metaData } catch (_: Throwable) { null }
        h.name.text = meta?.name ?: ext.id
        h.version.text = "v${meta?.version ?: "?"}"

        h.icon.setImageResource(R.drawable.ic_ext)
        actions.loadIcon(ext, 96) { bmp ->
            if (bmp != null && h.bindingAdapterPosition == position) h.icon.setImageBitmap(bmp)
        }

        val enabled = actions.isEnabled(ext)
        h.sw.setOnCheckedChangeListener(null)
        h.sw.isChecked = enabled
        h.sw.setOnCheckedChangeListener { _, on -> onToggle(ext, on) }

        // Botões sem função para esta extensão ficam apagados; o sidebar só aparece quando há painel conhecido.
        fun state(v: View, available: Boolean) {
            v.isEnabled = available && enabled
            v.alpha = if (available && enabled) 1f else 0.3f
        }
        // Play abre a interface que a extensão tiver (popup, opções ou painel), então só depende de estar ativa.
        state(h.btnPlay, true)
        state(h.btnOptions, actions.optionsUrl(ext) != null)
        val hasSidebar = actions.sidebarUrl(ext) != null
        h.btnSidebar.visibility = if (hasSidebar) View.VISIBLE else View.GONE
        state(h.btnSidebar, hasSidebar)

        h.btnPlay.setOnClickListener { if (it.isEnabled) onPlay(ext) }
        h.btnOptions.setOnClickListener { if (it.isEnabled) onOpenOptions(ext) }
        h.btnSidebar.setOnClickListener { if (it.isEnabled) onOpenSidebar(ext) }
        h.btnRemove.setOnClickListener { onRemove(ext) }

        // Entrada em cascata: 30 ms por item, só na primeira exibição de cada posição.
        if (position > animatedUpTo) {
            animatedUpTo = position
            h.itemView.alpha = 0f
            h.itemView.translationY = 24f
            h.itemView.animate().alpha(1f).translationY(0f)
                .setStartDelay(position * 30L).setDuration(250).start()
        } else {
            h.itemView.alpha = 1f
            h.itemView.translationY = 0f
        }
    }

    override fun onViewRecycled(h: VH) {
        h.itemView.animate().cancel()
        super.onViewRecycled(h)
    }

    override fun getItemCount() = items.size
}
