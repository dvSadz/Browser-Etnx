package com.eternal.browser.core.storage

import android.content.Context

/** Fachada de domínio para as preferências do navegador; a persistência fica em [PrefsManager]. */
class Prefs(context: Context) {
    private val storage = PrefsManager(context)

    /** true = barra de endereço embaixo (padrão); false = em cima. */
    var barAtBottom: Boolean
        get() = getBool(PrefsKeys.BAR_BOTTOM, true)
        set(v) = setBool(PrefsKeys.BAR_BOTTOM, v)

    var nightMode: Boolean
        get() = getBool(PrefsKeys.NIGHT_MODE, false)
        set(v) = setBool(PrefsKeys.NIGHT_MODE, v)

    /** 50..150 (%) */
    var nightBrightness: Int
        get() = getInt(PrefsKeys.NIGHT_BRIGHTNESS, 95)
        set(v) = setInt(PrefsKeys.NIGHT_BRIGHTNESS, v)

    /** 50..150 (%) */
    var nightContrast: Int
        get() = getInt(PrefsKeys.NIGHT_CONTRAST, 105)
        set(v) = setInt(PrefsKeys.NIGHT_CONTRAST, v)

    val searchEngines: Map<String, String> = linkedMapOf(
        "Google" to "https://www.google.com/search?q=",
        "DuckDuckGo" to "https://duckduckgo.com/?q=",
        "Bing" to "https://www.bing.com/search?q=",
        "Brave" to "https://search.brave.com/search?q=",
        "Ecosia" to "https://www.ecosia.org/search?q=",
        "Startpage" to "https://www.startpage.com/do/search?q=",
        "Qwant" to "https://www.qwant.com/?q=",
        "Custom" to "https://www.google.com/search?q={query}",
    )

    var searchEngine: String
        get() = getStr(PrefsKeys.SEARCH_ENGINE, "Google")
        set(v) = setStr(PrefsKeys.SEARCH_ENGINE, v)

    val searchUrl: String
        get() = if (searchEngine == "Custom") {
            getStr(PrefsKeys.CUSTOM_SEARCH_URL, searchEngines.getValue("Custom"))
        } else {
            searchEngines[searchEngine] ?: searchEngines.getValue("Google")
        }

    /** URL customizada aceita {query} (ou %s); sem marcador, o termo é acrescentado ao final. */
    var customSearchUrl: String
        get() = getStr(PrefsKeys.CUSTOM_SEARCH_URL, searchEngines.getValue("Custom"))
        set(v) = setStr(PrefsKeys.CUSTOM_SEARCH_URL, v)

    var savedTabs: List<String>
        get() = getStr(PrefsKeys.SAVED_TABS, "").split('\n').filter { it.isNotBlank() }
        set(v) = setStr(PrefsKeys.SAVED_TABS, v.joinToString("\n"))

    var savedSelected: Int
        get() = getInt(PrefsKeys.SAVED_SELECTED, 0)
        set(v) = setInt(PrefsKeys.SAVED_SELECTED, v)

    /** Endereço em carregamento; commit síncrono para sobreviver a crash durante a navegação. */
    var navBreadcrumb: String
        get() = getStr(PrefsKeys.NAV_BREADCRUMB, "")
        set(v) = storage.setString(PrefsKeys.NAV_BREADCRUMB, v, commit = true)

    /** Timestamp da última saída anormal já mostrada ao usuário. */
    var lastExitReported: Long
        get() = storage.getLong(PrefsKeys.LAST_EXIT_REPORTED, 0L)
        set(v) = storage.setLong(PrefsKeys.LAST_EXIT_REPORTED, v)

    /** Modo seguro: sem processo de extensões e sem a extensão embutida do modo noturno. */
    var safeMode: Boolean
        get() = getBool(PrefsKeys.SAFE_MODE, false)
        set(v) = setBool(PrefsKeys.SAFE_MODE, v)

    var startPending: Boolean
        get() = getBool(PrefsKeys.START_PENDING, false)
        set(v) = setBool(PrefsKeys.START_PENDING, v)

    var safeModeReset: Boolean
        get() = getBool(PrefsKeys.SAFE_MODE_RESET, false)
        set(v) = setBool(PrefsKeys.SAFE_MODE_RESET, v)

    var devAccepted: Boolean
        get() = getBool(PrefsKeys.DEV_ACCEPTED, false)
        set(v) = setBool(PrefsKeys.DEV_ACCEPTED, v)

    var remoteDebug: Boolean
        get() = getBool(PrefsKeys.REMOTE_DEBUG, false)
        set(v) = setBool(PrefsKeys.REMOTE_DEBUG, v)

    // ---------- Wallpaper da pesquisa ----------

    var searchWallpaperEnabled: Boolean
        get() = getBool(PrefsKeys.SEARCH_WALLPAPER_ENABLED, true)
        set(v) = setBool(PrefsKeys.SEARCH_WALLPAPER_ENABLED, v)

    /** URI (content://) do wallpaper escolhido; vazio = sem wallpaper (fundo normal da página). */
    var searchWallpaperUri: String
        get() = getStr(PrefsKeys.SEARCH_WALLPAPER_URI, "")
        set(v) = setStr(PrefsKeys.SEARCH_WALLPAPER_URI, v)

    /** 0..80 (%) de escurecimento sobre o wallpaper. */
    var searchWallpaperDim: Int
        get() = getInt(PrefsKeys.SEARCH_WALLPAPER_DIM, 40).coerceIn(0, 80)
        set(v) = setInt(PrefsKeys.SEARCH_WALLPAPER_DIM, v)

    // Acesso genérico usado pelo registro e pela tela de Configurações.
    fun getBool(key: String, def: Boolean): Boolean = storage.getBoolean(key, def)
    fun setBool(key: String, v: Boolean) = storage.setBoolean(key, v)
    fun getStr(key: String, def: String): String = storage.getString(key, def)
    fun setStr(key: String, v: String) = storage.setString(key, v)
    fun getInt(key: String, def: Int): Int = storage.getInt(key, def)
    fun setInt(key: String, v: Int) = storage.setInt(key, v)
    fun removeKeys(keys: Collection<String>) = storage.removeKeys(keys)
}
