package com.eternal.browser

import android.Manifest
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.URLUtil
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.slider.Slider
import com.google.android.material.snackbar.Snackbar
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebResponse

import com.eternal.browser.features.settings.SettingsActivity
import com.eternal.browser.extensions.ExtensionActionManager
import com.eternal.browser.extensions.ExtensionTransitions
import com.eternal.browser.extensions.ExtensionsActivity
import org.mozilla.geckoview.WebExtension
import com.eternal.browser.core.storage.PrefsKeys
import com.eternal.browser.core.storage.Prefs
import com.eternal.browser.core.storage.LibraryStore
import com.eternal.browser.core.engine.TabManager
import com.eternal.browser.core.engine.Tab
class MainActivity : AppCompatActivity(), TabManager.Listener {

    private lateinit var prefs: Prefs
    private lateinit var root: LinearLayout
    private lateinit var geckoView: GeckoView
    private lateinit var bar: View
    private lateinit var progress: LinearProgressIndicator
    private lateinit var urlInput: EditText
    private lateinit var lockIcon: ImageView
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnReload: ImageButton
    private lateinit var tabCount: TextView

    private lateinit var tabManager: TabManager
    private lateinit var bookmarks: LibraryStore
    private lateinit var history: LibraryStore
    private lateinit var extensions: ExtensionManager
    private lateinit var night: NightModeController
    private lateinit var searchWallpaper: SearchWallpaperManager

    private var fullScreen = false
    private var splash: SplashOverlay? = null
    private var appliedBarBottom: Boolean? = null

    private var extActions: ExtensionActionManager? = null
    private val extBarRefresh = Runnable { populateExtensionsBar() }
    private val extActionsListener: () -> Unit = { bar.removeCallbacks(extBarRefresh); bar.postDelayed(extBarRefresh, 150) }

    /** Resultado da tela "Gerenciar extensões": o botão + pede o seletor de instalação (o diálogo de permissões fica aqui). */
    private val extensionsScreen = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK && r.data?.getStringExtra(ExtensionsActivity.RESULT_ACTION) == "install") {
            extensions.showInstallChooser()
        }
    }

    /** Seletor de extensão: só arquivos .zip (a validação do nome/conteúdo fica em [ExtensionManager.installFromUri]). */
    private val zipPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching { extensions.installFromUri(uri) }
            .onFailure { Log.e(TAG, "importar extensão falhou", it); toast(getString(R.string.ext_install_error, it.message ?: "")) }
    }

    private fun launchZipPicker() {
        // ZIPs chegam com vários MIME types conforme o provedor de arquivos; o filtro final é pela extensão .zip.
        runCatching { zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }
            .onFailure { Log.e(TAG, "picker", it) }
    }

    private companion object { const val TAG = "EternalMain" }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        // Sem runtime (GeckoRuntime.create falhou) não há navegador: avisa em vez de crashar.
        if (!EternalApplication.isReady()) {
            val cause = EternalApplication.initializationFailure
            val diagnostic = buildString {
                appendLine("Motor não iniciado.")
                appendLine()
                appendLine("Dispositivo: ${Build.SUPPORTED_ABIS.joinToString()}")
                appendLine("Diretório das bibliotecas: ${applicationInfo.nativeLibraryDir}")
                appendLine("APK: ${applicationInfo.sourceDir}")
                if (cause != null) {
                    appendLine("Falha: ${cause.javaClass.simpleName}: ${cause.message.orEmpty()}")
                }
            }
            Log.e(TAG, diagnostic, cause)
            MaterialAlertDialogBuilder(this)
                .setTitle("ETERNAL")
                .setMessage(diagnostic)
                .setCancelable(false)
                .setPositiveButton(android.R.string.ok) { _, _ -> finish() }
                .show()
            return
        }
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)
        root = findViewById(R.id.root)
        // Android 15+ (targetSdk 35) força edge-to-edge: reservamos o espaço das barras do sistema e do teclado.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val sys = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(sys.left, sys.top, sys.right, sys.bottom)
            // O teclado NÃO redimensiona mais o GeckoView (no vídeo do crash o app morre ao abrir o teclado,
            // com a superfície do Gecko sendo redimensionada). Só a barra sobe, por cima da página.
            if (::bar.isInitialized) {
                val lift = (ime.bottom - sys.bottom).coerceAtLeast(0)
                bar.translationY = if (prefs.barAtBottom) -lift.toFloat() else 0f
            }
            insets
        }
        geckoView = findViewById(R.id.geckoView)
        bar = findViewById(R.id.bar)
        progress = bar.findViewById(R.id.progress)
        urlInput = bar.findViewById(R.id.urlInput)
        lockIcon = bar.findViewById(R.id.lockIcon)
        btnBack = bar.findViewById(R.id.btnBack)
        btnForward = bar.findViewById(R.id.btnForward)
        btnReload = bar.findViewById(R.id.btnReload)
        tabCount = bar.findViewById(R.id.tabCount)

        val runtime = EternalApplication.runtime
        night = NightModeController(runtime, prefs)
        searchWallpaper = SearchWallpaperManager(this, prefs)
        extensions = ExtensionManager(this, runtime, night, searchWallpaper)
        extensions.onPickZip = { launchZipPicker() }
        bookmarks = LibraryStore(this, "bookmarks", 500)
        history = LibraryStore(this, "history", 300)
        tabManager = TabManager(this, runtime, this, history)

        applyBarPosition()
        setupBar()
        extensions.init(withBuiltIn = !prefs.safeMode)
        setupExtensionUi()
        restoreTabs(intent)
        intent.getStringExtra(ExtensionActionManager.EXTRA_OPEN_URL_NEW_TAB)?.takeIf { it.isNotBlank() }
            ?.let { tabManager.openTab(it) }
        reportPreviousCrash()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val tab = tabManager.current
                when {
                    fullScreen -> tabManager.current?.session?.exitFullScreen()
                    urlInput.hasFocus() -> { urlInput.clearFocus(); hideKeyboard() }
                    tab != null && tab.canGoBack -> tab.session.goBack()
                    tab != null && tabManager.tabs.size > 1 -> tabManager.close(tab)
                    else -> { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })

        // Abertura animada por cima de tudo até a primeira página carregar.
        splash = SplashOverlay.show(this)
    }

    /** O Android avisa antes de matar o processo por falta de memória: solta as abas em segundo plano. */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW && ::tabManager.isInitialized) {
            tabManager.discardBackground()
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onLowMemory() {
        super.onLowMemory()
        if (::tabManager.isInitialized) tabManager.discardBackground()
    }

    override fun onDestroy() {
        extActions?.removeListener(extActionsListener)
        if (extActions?.tabHost === extTabHost) extActions?.tabHost = null
        if (::bar.isInitialized) bar.removeCallbacks(extBarRefresh)
        splash?.cancel()
        splash = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (!::tabManager.isInitialized) return
        intent.data?.let { tabManager.openTab(it.toString()) }
        intent.getStringExtra(ExtensionActionManager.EXTRA_OPEN_URL_NEW_TAB)?.takeIf { it.isNotBlank() }
            ?.let { tabManager.openTab(it) }
    }

    /** Mostra o que causou o fechamento inesperado anterior (exceção Java, motivo registrado pelo Android, log). */
    private fun reportPreviousCrash() {
        val crumb = prefs.navBreadcrumb
        prefs.navBreadcrumb = ""
        val trace = CrashReporter.consume(this)
        Thread {
            val exit = CrashReporter.exitInfo(this, prefs)
            val log = if (trace != null || exit != null || crumb.isNotBlank()) CrashReporter.recentLog() else null
            val text = buildString {
                if (crumb.isNotBlank()) append("Carregando quando fechou:\n$crumb\n\n")
                if (exit != null) append("Motivo (Android):\n$exit\n\n")
                if (trace != null) append("Exceção Java:\n${trace.take(3000)}\n\n")
                if (log != null) append("Log recente:\n$log")
            }
            if (text.isBlank()) return@Thread
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.crash_title)
                    .setMessage(text.take(7000))
                    .setPositiveButton(android.R.string.copy) { _, _ ->
                        (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                            .setPrimaryClip(android.content.ClipData.newPlainText("eternal-crash", text))
                    }
                    .setNegativeButton(android.R.string.ok, null)
                    .show()
            }
        }.start()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    override fun onStop() {
        super.onStop()
        if (!::tabManager.isInitialized) return
        prefs.navBreadcrumb = "" // saída normal: não é crash
        prefs.startPending = false
        // Abas anônimas nunca são salvas.
        // Também não salva o popup de extensão: ele só faz sentido enquanto a extensão o mantém aberto.
        val persistent = tabManager.tabs.filter { !it.isPrivate && it.extensionId == null }
        prefs.savedTabs = persistent.map { it.url }.filter { it.isNotBlank() && !UrlUtils.isStartPage(it) }
        prefs.savedSelected = persistent.indexOf(tabManager.current).coerceAtLeast(0)
    }

    // ---------- inicialização ----------

    private fun restoreTabs(intent: Intent) {
        val saved = if (prefs.getBool(PrefsKeys.RESTORE_TABS, true)) prefs.savedTabs else emptyList()
        val fromIntent = intent.data?.toString()
        if (saved.isEmpty() && fromIntent == null) {
            tabManager.openTab(); return
        }
        saved.forEach { tabManager.openTab(it, select = false) }
        if (fromIntent != null) {
            tabManager.openTab(fromIntent)
        } else {
            tabManager.tabs.getOrNull(prefs.savedSelected.coerceIn(0, saved.size - 1))
                ?.let { tabManager.select(it) }
        }
    }

    /** Barra configurável: embaixo (padrão) ou em cima. */
    private fun applyBarPosition() {
        root.removeView(bar)
        root.addView(bar, if (prefs.barAtBottom) root.childCount else 0)
        appliedBarBottom = prefs.barAtBottom
    }

    /** Ao voltar da tela de Configurações: aplica na hora o que não precisa reiniciar. */
    override fun onResume() {
        super.onResume()
        if (!::night.isInitialized) return // início falhou antes de montar a tela
        if (appliedBarBottom != prefs.barAtBottom) applyBarPosition()
        night.apply()
        searchWallpaper.apply() // volta das Configurações: wallpaper/escurecimento podem ter mudado
        populateExtensionsBar()
    }

    private fun setupBar() {
        btnBack.setOnClickListener { tabManager.current?.session?.goBack() }
        btnForward.setOnClickListener { tabManager.current?.session?.goForward() }
        btnReload.setOnClickListener {
            val tab = tabManager.current ?: return@setOnClickListener
            if (tab.loading) tab.session.stop() else tab.session.reload()
        }
        bar.findViewById<View>(R.id.tabsButton).setOnClickListener { TabSwitcherSheet(this, tabManager).show() }
        bar.findViewById<View>(R.id.btnExtensions).setOnClickListener { openExtensionsScreen() }
        bar.findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        urlInput.setOnEditorActionListener { v, actionId, event ->
            val go = actionId == EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            if (go) navigate(v.text.toString())
            go
        }
        urlInput.setOnFocusChangeListener { _, focused ->
            val tab = tabManager.current
            if (focused) {
                urlInput.setText(if (UrlUtils.isStartPage(tab?.url)) "" else tab?.url ?: "")
                urlInput.post { urlInput.selectAll() }
            } else {
                urlInput.setText(UrlUtils.display(tab?.url))
            }
        }
    }

    /** Pesquisa/URL digitada. Nunca lança: qualquer falha vira aviso, não crash. */
    private fun navigate(input: String) {
        try {
            val uri = UrlUtils.toUri(input, prefs.searchUrl)
            prefs.navBreadcrumb = uri
            if (!tabManager.load(uri)) toast(getString(R.string.load_error))
        } catch (t: Throwable) {
            Log.e(TAG, "navigate falhou: $input", t)
            toast(getString(R.string.load_error))
        }
        // Fora do callback do teclado: tirar o foco aqui dentro dispara setText durante o IME.
        urlInput.post { urlInput.clearFocus(); hideKeyboard() }
    }

    /** Comandos dos cartões da página inicial (eternal://…). */
    override fun onAppCommand(command: String) {
        when (command) {
            "search" -> {
                urlInput.requestFocus()
                urlInput.post { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(urlInput, InputMethodManager.SHOW_IMPLICIT) }
            }
            "tabs" -> TabSwitcherSheet(this, tabManager).show()
            "newtab" -> tabManager.openTab()
            "private" -> tabManager.openTab(incognito = true)
            "dev" -> requireDevConsent { showDevSheet() }
            "bookmarks" -> LibrarySheet(this, bookmarks, history) { tabManager.load(it) }.show(true)
            "history" -> LibrarySheet(this, bookmarks, history) { tabManager.load(it) }.show(false)
            "extensions" -> openExtensionsScreen()
            "import" -> launchZipPicker()
            "downloads" -> runCatching { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                .onFailure { Log.e(TAG, "downloads", it); toast("Abra o app Arquivos para ver seus downloads") }
            "settings" -> showMenu(findViewById(R.id.btnMenu))
        }
    }

    private fun showMenu(anchor: View) {
        MainMenuSheet(
            activity = this,
            nightOn = prefs.nightMode,
            bookmarked = bookmarks.contains(tabManager.current?.url.orEmpty()),
            barAtBottom = prefs.barAtBottom,
            safeMode = prefs.safeMode,
            onAction = { action, checked -> handleMenuAction(action, checked) },
        ).show()
    }

    private fun handleMenuAction(action: MenuAction, checked: Boolean) {
        when (action) {
            MenuAction.SEARCH -> urlInput.postDelayed({ onAppCommand("search") }, 200)
            MenuAction.NEW_TAB -> tabManager.openTab()
            MenuAction.PRIVATE_TAB -> tabManager.openTab(incognito = true)
            MenuAction.TABS -> TabSwitcherSheet(this, tabManager).show()
            MenuAction.BOOKMARKS -> onAppCommand("bookmarks")
            MenuAction.HISTORY -> onAppCommand("history")
            MenuAction.EXTENSIONS, MenuAction.EXT_MANAGE -> openExtensionsScreen()
            MenuAction.EXT_POPUP -> pickExtension(ExtKind.POPUP)
            MenuAction.EXT_OPTIONS -> pickExtension(ExtKind.OPTIONS)
            MenuAction.EXT_SIDEBAR -> pickExtension(ExtKind.SIDEBAR)
            MenuAction.EXT_ADDONS -> tabManager.openTab("about:addons")
            MenuAction.BOOKMARK_TOGGLE -> toggleBookmark()
            MenuAction.NIGHT -> { prefs.nightMode = checked; night.apply() }
            MenuAction.NIGHT_ADJUST -> showNightAdjust()
            MenuAction.BAR_POSITION -> { prefs.barAtBottom = checked; applyBarPosition() }
            MenuAction.SEARCH_ENGINE -> showSearchEngines()
            MenuAction.IMPORT_EXT -> onAppCommand("import")
            MenuAction.DEV -> onAppCommand("dev")
            MenuAction.SAFE_MODE -> { prefs.safeMode = checked; toast(getString(R.string.safe_mode_restart)) }
            MenuAction.SETTINGS -> startActivity(Intent(this, SettingsActivity::class.java))
            MenuAction.ABOUT -> showAbout()
        }
    }

    // ---------- UI das extensões (popup, opções, painel lateral) ----------

    private enum class ExtKind { POPUP, OPTIONS, SIDEBAR }

    /** Abas pedidas pelas extensões (popup, opções, painel lateral, about:addons). */
    private val extTabHost = object : ExtensionActionManager.TabHost {
        override fun openUrl(url: String) { tabManager.openTab(url) }

        override fun openExtensionSession(extensionId: String, session: org.mozilla.geckoview.GeckoSession) {
            tabManager.adoptSession(session, extensionId)
        }

        override fun focusExtensionTab(extensionId: String): Boolean {
            val tab = tabManager.tabs.firstOrNull { it.extensionId == extensionId && it.session.isOpen } ?: return false
            tabManager.select(tab)
            return true
        }
    }

    private fun setupExtensionUi() {
        val am = ExtensionActionManager.get(this) ?: return
        extActions = am
        am.tabHost = extTabHost
        am.addListener(extActionsListener)
        // Extensão recém-instalada: registra os delegates para o Gecko entregar o botão dela.
        extensions.onInstalled = { ext ->
            am.attach(ext)
            populateExtensionsBar()
        }
        populateExtensionsBar()
    }

    private fun openExtensionsScreen() {
        if (!EternalApplication.isReady()) return
        extensionsScreen.launch(Intent(this, ExtensionsActivity::class.java))
        ExtensionTransitions.slideIn(this)
    }

    /** Ícones das extensões ativas que têm botão; clicar abre o popup (ou as opções, se não houver popup). */
    private fun populateExtensionsBar() {
        val am = extActions ?: return
        val scroll = bar.findViewById<View>(R.id.extensionsScroll) ?: return
        val row = bar.findViewById<LinearLayout>(R.id.extensionsBar) ?: return
        am.listInstalledExtensions { exts ->
            if (isFinishing || isDestroyed) return@listInstalledExtensions
            val visible = exts.filter { am.isEnabled(it) && am.hasAction(it) }
            row.removeAllViews()
            visible.forEachIndexed { i, ext ->
                val name = try { ext.metaData?.name } catch (_: Throwable) { null } ?: ext.id
                val icon = ImageView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dpi(28), dpi(28)).apply { marginEnd = dpi(10) }
                    setPadding(dpi(2), dpi(2), dpi(2), dpi(2))
                    contentDescription = name
                    setImageResource(R.drawable.ic_ext)
                    alpha = 0f; scaleX = 0.8f; scaleY = 0.8f
                    setOnClickListener {
                        am.openAnyUi(ext) { ok -> if (!ok) toast(getString(R.string.ext_no_popup) + (am.lastFailure?.let { "\n($it)" } ?: "")) }
                    }
                }
                am.loadIcon(ext, dpi(56)) { bmp -> if (bmp != null) icon.setImageBitmap(bmp) }
                row.addView(icon)
                icon.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(i * 40L).setDuration(200).start()
            }
            scroll.visibility = if (visible.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    /** Menu "Abrir popup / Página de opções / Painel lateral": escolhe entre as extensões que têm o recurso. */
    private fun pickExtension(kind: ExtKind) {
        val am = extActions ?: ExtensionActionManager.get(this) ?: return
        am.listInstalledExtensions { exts ->
            if (isFinishing || isDestroyed) return@listInstalledExtensions
            val candidates: List<WebExtension> = exts.filter {
                am.isEnabled(it) && when (kind) {
                    ExtKind.POPUP -> am.hasAction(it)
                    ExtKind.OPTIONS -> am.optionsUrl(it) != null
                    ExtKind.SIDEBAR -> am.sidebarUrl(it) != null
                }
            }
            if (candidates.isEmpty()) {
                toast(getString(when (kind) {
                    ExtKind.POPUP -> R.string.ext_none_with_popup
                    ExtKind.OPTIONS -> R.string.ext_none_with_options
                    ExtKind.SIDEBAR -> R.string.ext_none_with_sidebar
                }))
                return@listInstalledExtensions
            }
            fun openExt(ext: WebExtension) {
                when (kind) {
                    ExtKind.POPUP -> am.openPopup(ext) { }
                    ExtKind.OPTIONS -> am.openOptions(ext)
                    ExtKind.SIDEBAR -> am.openSidebar(ext)
                }
            }
            if (candidates.size == 1) { openExt(candidates[0]); return@listInstalledExtensions }
            val names = candidates.map { (try { it.metaData?.name } catch (_: Throwable) { null }) ?: it.id }.toTypedArray()
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.menu_extensions)
                .setItems(names) { _, i -> openExt(candidates[i]) }
                .show()
        }
    }

    // ---------- ferramentas de desenvolvedor ----------

    private fun dpi(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Aviso legal obrigatório (uma vez) antes de qualquer ferramenta de desenvolvedor. */
    private fun requireDevConsent(then: () -> Unit) {
        if (prefs.devAccepted) { then(); return }
        val box = CheckBox(this).apply { text = "Li e concordo"; setTextColor(getColor(R.color.eternal_text)) }
        val holder = FrameLayout(this).apply { setPadding(dpi(24), dpi(8), dpi(24), 0); addView(box) }
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle("Ativar modo desenvolvedor?")
            .setMessage("As ferramentas de desenvolvedor permitem inspecionar, modificar e clonar conteúdo de sites. Use apenas em sites próprios ou com permissão. Clonar conteúdo protegido por direitos autorais é ilegal.")
            .setView(holder)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton("Ativar", null)
            .create()
        dlg.setOnShowListener {
            val ok = dlg.getButton(android.content.DialogInterface.BUTTON_POSITIVE)
            ok.isEnabled = false
            box.setOnCheckedChangeListener { _, c -> ok.isEnabled = c }
            ok.setOnClickListener { prefs.devAccepted = true; dlg.dismiss(); then() }
        }
        dlg.show()
    }

    private fun devRow(dialog: BottomSheetDialog, list: LinearLayout, title: String, sub: String, enabled: Boolean, onClick: () -> Unit) {
        val r = layoutInflater.inflate(R.layout.item_tool, list, false)
        r.findViewById<TextView>(R.id.itemTitle).text = title
        r.findViewById<TextView>(R.id.itemSub).text = sub
        r.alpha = if (enabled) 1f else 0.4f
        r.setOnClickListener {
            dialog.dismiss()
            if (enabled) onClick() else toast("Abra uma página http/https primeiro")
        }
        list.addView(r)
    }

    private fun showDevSheet() {
        val url = tabManager.current?.url.orEmpty()
        val web = url.startsWith("http")
        val dialog = BottomSheetDialog(this)
        val v = layoutInflater.inflate(R.layout.sheet_dev, null)
        v.findViewById<TextView>(R.id.devTitle).text = "Desenvolvedor"
        v.findViewById<TextView>(R.id.devUrl).text = if (web) UrlUtils.display(url) else "Abra uma página (http/https) para usar as ferramentas"
        val list = v.findViewById<LinearLayout>(R.id.devList)
        fun open(cls: Class<*>) = startActivity(Intent(this, cls).putExtra("url", url))
        devRow(dialog, list, "Ver código-fonte", "HTML, CSS e JS da página", web) { open(ViewSourceActivity::class.java) }
        devRow(dialog, list, "Clonar site (HTML)", "Uma página ou o site inteiro", web) { showCloneSheet(url) }
        devRow(dialog, list, "Inspecionar requisições", "Rede: status, tipo, tempo, cabeçalhos", true) { startActivity(Intent(this, NetworkActivity::class.java)) }
        devRow(dialog, list, "Cookies", "Ver, copiar e remover", web) { open(StorageActivity::class.java) }
        devRow(dialog, list, "Extrair assets", "Imagens, CSS, JS, fontes e links", web) { open(AssetsActivity::class.java) }
        devRow(dialog, list, "DevTools remoto (USB)", if (prefs.remoteDebug) "Ligado: toque para desligar" else "Desligado: inspetor e console completos pelo Firefox do PC", true) { toggleRemoteDebug() }
        dialog.setContentView(v)
        dialog.show()
    }

    private fun toggleRemoteDebug() {
        if (prefs.remoteDebug) {
            prefs.remoteDebug = false
            runCatching { EternalApplication.runtime.settings.setRemoteDebuggingEnabled(false) }
            toast("DevTools remoto desligado")
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Ligar DevTools remoto?")
            .setMessage("Permite inspecionar abas (elementos, console, rede) pelo Firefox do computador: ligue a depuração USB, conecte o cabo e abra about:debugging no Firefox do PC. Deixe ligado só enquanto usar.")
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton("Ligar") { _, _ ->
                prefs.remoteDebug = true
                runCatching { EternalApplication.runtime.settings.setRemoteDebuggingEnabled(true) }
                toast("DevTools remoto ligado")
            }.show()
    }

    private fun showCloneSheet(url: String) {
        val dialog = BottomSheetDialog(this)
        val v = layoutInflater.inflate(R.layout.sheet_dev, null)
        v.findViewById<TextView>(R.id.devTitle).text = "Clonar site"
        v.findViewById<TextView>(R.id.devUrl).text = url
        val list = v.findViewById<LinearLayout>(R.id.devList)
        devRow(dialog, list, "Somente esta página", "Baixa o HTML e recursos desta página", true) {
            startClone(url, SiteCloner.Options(maxDepth = 0, maxPages = 1))
        }
        devRow(dialog, list, "Site inteiro (mesmo domínio)", "Rastreia e baixa até 100 páginas do domínio", true) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Clonar o site inteiro?")
                .setMessage("Isso pode baixar muitos arquivos e levar tempo. Clone apenas sites seus ou com permissão.")
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton("Clonar") { _, _ -> startClone(url, SiteCloner.Options(maxDepth = 5, maxPages = 100)) }
                .show()
        }
        devRow(dialog, list, "Personalizado", "Profundidade, limite de páginas e tipos de arquivo", true) { showCloneCustom(url) }
        dialog.setContentView(v)
        dialog.show()
    }

    private fun showCloneCustom(url: String) {
        val v = layoutInflater.inflate(R.layout.dialog_clone, null)
        MaterialAlertDialogBuilder(this)
            .setTitle("Clonagem personalizada")
            .setView(v)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Iniciar clonagem") { _, _ ->
                val pages = v.findViewById<EditText>(R.id.cloneMaxPages).text.toString().toIntOrNull()?.coerceIn(1, 1000) ?: 50
                startClone(url, SiteCloner.Options(
                    maxDepth = v.findViewById<Slider>(R.id.cloneDepth).value.toInt(),
                    maxPages = pages,
                    external = v.findViewById<MaterialSwitch>(R.id.swExternal).isChecked,
                    images = v.findViewById<MaterialSwitch>(R.id.swImages).isChecked,
                    css = v.findViewById<MaterialSwitch>(R.id.swCss).isChecked,
                    js = v.findViewById<MaterialSwitch>(R.id.swJs).isChecked,
                    fonts = v.findViewById<MaterialSwitch>(R.id.swFonts).isChecked,
                    video = v.findViewById<MaterialSwitch>(R.id.swVideo).isChecked,
                ))
            }.show()
    }

    private fun startClone(url: String, o: SiteCloner.Options) {
        val cloner = SiteCloner(this)
        val pv = layoutInflater.inflate(R.layout.dialog_progress, null)
        val tUrl = pv.findViewById<TextView>(R.id.cloneUrl)
        val bar = pv.findViewById<LinearProgressIndicator>(R.id.cloneBar)
        val tPages = pv.findViewById<TextView>(R.id.clonePages)
        val tBytes = pv.findViewById<TextView>(R.id.cloneBytes)
        tUrl.text = url
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle("Clonando site…")
            .setView(pv)
            .setCancelable(false)
            .setNegativeButton(android.R.string.cancel) { _, _ -> cloner.cancel() }
            .show()
        Thread {
            val result = try {
                cloner.run(url, o) { p ->
                    runOnUiThread {
                        tUrl.text = p.current
                        bar.setProgressCompat(((p.pages * 100) / p.maxPages.coerceAtLeast(1)).coerceIn(0, 100), true)
                        tPages.text = "${p.pages} de ${p.maxPages} páginas"
                        tBytes.text = String.format("%.1f MB baixados", p.bytes / 1048576.0)
                    }
                }
            } catch (t: Throwable) {
                Log.e(TAG, "clonagem falhou", t); null
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                dlg.dismiss()
                when {
                    result == null -> toast("Erro ao clonar o site")
                    result.cancelled -> toast("Clonagem cancelada")
                    result.savedAs == null -> toast("Clonado, mas não foi possível salvar o arquivo")
                    else -> MaterialAlertDialogBuilder(this)
                        .setTitle("Site clonado com sucesso!")
                        .setMessage(String.format("%d páginas, %.1f MB salvos em %s", result.pages, result.bytes / 1048576.0, result.savedAs))
                        .setPositiveButton("Abrir pasta") { _, _ ->
                            runCatching { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        }
                        .setNegativeButton("Fechar", null)
                        .show()
                }
            }
        }.start()
    }

    private fun toggleBookmark() {
        val tab = tabManager.current
        val url = tab?.url.orEmpty()
        if (tab == null || !url.startsWith("http")) { toast(getString(R.string.bookmark_none)); return }
        if (bookmarks.contains(url)) {
            bookmarks.remove(url); toast(getString(R.string.bookmark_removed))
        } else {
            bookmarks.add(tab.title.ifBlank { url }, url); toast(getString(R.string.bookmark_added))
        }
    }

    private fun showNightAdjust() {
        val v = layoutInflater.inflate(R.layout.dialog_night_adjust, null)
        val brightness = v.findViewById<Slider>(R.id.sliderBrightness).apply { value = prefs.nightBrightness.toFloat() }
        val contrast = v.findViewById<Slider>(R.id.sliderContrast).apply { value = prefs.nightContrast.toFloat() }
        brightness.addOnChangeListener { _, value, _ -> prefs.nightBrightness = value.toInt(); night.apply() }
        contrast.addOnChangeListener { _, value, _ -> prefs.nightContrast = value.toInt(); night.apply() }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.menu_night_adjust)
            .setView(v)
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    private fun showSearchEngines() {
        val names = prefs.searchEngines.keys.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.menu_search_engine)
            .setSingleChoiceItems(names, names.indexOf(prefs.searchEngine)) { d, i ->
                prefs.searchEngine = names[i]; d.dismiss()
            }.show()
    }

    private fun showAbout() {
        MaterialAlertDialogBuilder(this)
            .setTitle("ETERNAL ${BuildConfig.VERSION_NAME}")
            .setMessage(R.string.about_text)
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    // ---------- TabManager.Listener ----------

    override fun onTabSelected(tab: Tab) {
        geckoView.releaseSession()
        geckoView.setSession(tab.session)
        // Aba anônima: bloqueia capturas de tela e mostra o aviso na barra.
        if (tab.isPrivate) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        geckoView.alpha = 0f
        geckoView.animate().alpha(1f).setDuration(180).start()
        updateUi(tab)
    }

    override fun onTabUpdated(tab: Tab) {
        if (tab === tabManager.current) {
            if (!tab.loading && tab.progress >= 100 && prefs.startPending) prefs.startPending = false // 1ª página carregou: início OK
            if (!tab.loading && tab.progress >= 100) splash?.onPageReady()
            if (!tab.loading && prefs.navBreadcrumb.isNotEmpty()) prefs.navBreadcrumb = "" // página terminou: não estava em risco
            updateUi(tab)
        }
    }

    override fun onTabListChanged() {
        val old = tabCount.text.toString()
        val now = tabManager.tabs.size.toString()
        tabCount.text = now
        if (old != now) {
            tabCount.animate().scaleX(1.2f).scaleY(1.2f).setDuration(110).withEndAction {
                tabCount.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
            }.start()
        }
    }

    override fun onFullScreen(fullScreen: Boolean) {
        this.fullScreen = fullScreen
        bar.visibility = if (fullScreen) View.GONE else View.VISIBLE
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (fullScreen) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    override fun onPopupBlocked() {
        Snackbar.make(geckoView, R.string.popup_blocked, Snackbar.LENGTH_SHORT).show()
    }

    /** Downloads simples via DownloadManager (não cobre POST/cookies de sessão). */
    override fun onDownload(response: WebResponse) {
        val uri = response.uri
        response.body?.close()
        if (!uri.startsWith("http")) return
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
            Toast.makeText(this, R.string.download_retry, Toast.LENGTH_LONG).show()
            return
        }
        val headers = response.headers
        val disposition = headers.entries.firstOrNull { it.key.equals("content-disposition", true) }?.value
        val mime = headers.entries.firstOrNull { it.key.equals("content-type", true) }?.value
        val name = URLUtil.guessFileName(uri, disposition, mime)
        val req = DownloadManager.Request(Uri.parse(uri))
            .setTitle(name)
            .setNotificationVisibility(
                if (prefs.getBool(PrefsKeys.DOWNLOAD_NOTIFICATIONS, true)) DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                else DownloadManager.Request.VISIBILITY_HIDDEN
            )
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
        (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
        Toast.makeText(this, getString(R.string.downloading, name), Toast.LENGTH_SHORT).show()
    }

    // ---------- UI ----------

    private fun updateUi(tab: Tab) {
        urlInput.hint = getString(if (tab.isPrivate) R.string.url_hint_private else R.string.url_hint)
        if (!urlInput.hasFocus()) urlInput.setText(UrlUtils.display(tab.url))
        val isStart = UrlUtils.isStartPage(tab.url) || tab.url.isEmpty()
        lockIcon.visibility = if (isStart) View.GONE else View.VISIBLE
        lockIcon.setColorFilter(getColor(if (tab.secure) R.color.eternal_primary else R.color.eternal_text_tertiary))
        btnBack.isEnabled = tab.canGoBack; btnBack.alpha = if (tab.canGoBack) 1f else 0.35f
        btnForward.isEnabled = tab.canGoForward; btnForward.alpha = if (tab.canGoForward) 1f else 0.35f
        btnReload.setImageResource(if (tab.loading) R.drawable.ic_close else R.drawable.ic_refresh)
        if (tab.loading) {
            progress.visibility = View.VISIBLE
            progress.setProgressCompat(tab.progress.coerceAtLeast(5), true)
        } else {
            progress.setProgressCompat(100, true)
            progress.postDelayed({ if (tabManager.current?.loading != true) progress.visibility = View.GONE }, 250)
        }
        tabCount.text = tabManager.tabs.size.toString()
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlInput.windowToken, 0)
    }
}
