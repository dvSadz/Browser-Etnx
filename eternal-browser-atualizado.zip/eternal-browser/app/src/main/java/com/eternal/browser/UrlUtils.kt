package com.eternal.browser

import android.net.Uri

object UrlUtils {
    /** Página inicial do ETERNAL, empacotada em assets/start/. */
    const val START_PAGE = "resource://android/assets/start/index.html"

    fun isStartPage(url: String?): Boolean =
        url != null && url.startsWith("resource://android/assets/start")

    private fun searchUri(query: String, prefix: String): String {
        val safePrefix = prefix.takeIf { it.startsWith("https://", true) || it.startsWith("http://", true) }
            ?: "https://www.google.com/search?q="
        val encoded = Uri.encode(query)
        return when {
            safePrefix.contains("{query}") -> safePrefix.replace("{query}", encoded)
            safePrefix.contains("%s") -> safePrefix.replace("%s", encoded)
            else -> safePrefix + encoded
        }
    }

    private val blockedSchemes = listOf("javascript:", "data:", "file:", "eternal:", "resource:", "chrome:", "jar:", "blob:")

    private fun hasBlockedScheme(t: String): Boolean {
        val lower = t.lowercase()
        return blockedSchemes.any { lower.startsWith(it) }
    }

    private fun hasExplicitScheme(t: String): Boolean =
        t.contains("://") || t.startsWith("about:") || t.startsWith("mailto:") || t.startsWith("tel:")

    private fun looksLikeHost(t: String): Boolean = !t.contains(' ') &&
        (t.contains('.') || t.startsWith("localhost") || Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?.*").matches(t))

    /** Converte o que o usuário digitou em uma URL ou em uma busca. */
    fun toUri(input: String, searchPrefix: String): String {
        val t = input.trim()
        if (t.isEmpty()) return START_PAGE
        // javascript:/data:/file:/eternal: digitados na barra viram busca (evita auto-XSS por engenharia social).
        if (hasBlockedScheme(t)) return searchUri(t, searchPrefix)
        if (hasExplicitScheme(t)) return t
        return if (looksLikeHost(t)) "https://$t" else searchUri(t, searchPrefix)
    }

    /** Texto curto exibido na barra quando ela não está em edição. */
    fun display(url: String?): String {
        if (url.isNullOrEmpty() || isStartPage(url) || url == "about:blank") return ""
        return url.removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')
    }
}
