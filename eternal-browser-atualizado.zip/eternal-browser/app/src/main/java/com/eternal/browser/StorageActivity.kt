package com.eternal.browser

import android.os.Bundle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date

/** Cookies do site atual (lidos pela extensão embutida). Permite copiar, remover e limpar. */
class StorageActivity : ToolActivity() {
    private var url = ""
    private var current: JSONArray = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        url = intent.getStringExtra("url") ?: ""
        setTitleText("Cookies")
        setStatus(url)
        setAction1("Limpar tudo") { clearAll() }
        onRowClick = { row -> (row.tag as? JSONObject)?.let { options(it) } }
        DevToolsHub.cookiesCallback = { list, err -> ui { show(list, err) } }
        request()
    }

    override fun onDestroy() {
        DevToolsHub.cookiesCallback = null
        super.onDestroy()
    }

    private fun request() {
        showMessage("Carregando…")
        if (!DevToolsHub.send(JSONObject().put("cmd", "cookies").put("url", url))) {
            showMessage("Extensão de DevTools não conectada. Ela não roda no modo seguro; desligue-o no menu e reabra o app.")
        }
    }

    private fun show(list: JSONArray, err: String) {
        current = list
        val rows = (0 until list.length()).mapNotNull { list.optJSONObject(it) }.map {
            val flags = listOfNotNull(
                if (it.optBoolean("s")) "Secure" else null,
                if (it.optBoolean("h")) "HttpOnly" else null,
                it.optDouble("e", 0.0).takeIf { e -> e > 0 }?.let { e -> "expira " + DateFormat.getDateInstance().format(Date((e * 1000).toLong())) } ?: "sessão",
            ).joinToString(" · ")
            ToolRow(it.optString("n"), it.optString("v").take(120).ifBlank { "(vazio)" } + "\n" + flags, it.optString("d"), tag = it)
        }
        showRows(rows, if (err.isNotBlank()) "Não foi possível ler os cookies: $err" else "Nenhum cookie para este site.")
    }

    private fun options(c: JSONObject) {
        MaterialAlertDialogBuilder(this)
            .setTitle(c.optString("n"))
            .setItems(arrayOf("Copiar valor", "Remover")) { _, i ->
                if (i == 0) copyToClipboard("cookie", c.optString("v")) else remove(c.optString("n"))
            }.show()
    }

    private fun remove(name: String) {
        DevToolsHub.send(JSONObject().put("cmd", "rmcookie").put("url", url).put("name", name))
        window.decorView.postDelayed({ if (!isFinishing) request() }, 400)
    }

    private fun clearAll() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Remover todos os cookies deste site?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Remover") { _, _ ->
                for (i in 0 until current.length()) current.optJSONObject(i)?.let {
                    DevToolsHub.send(JSONObject().put("cmd", "rmcookie").put("url", url).put("name", it.optString("n")))
                }
                window.decorView.postDelayed({ if (!isFinishing) request() }, 500)
            }.show()
    }
}
