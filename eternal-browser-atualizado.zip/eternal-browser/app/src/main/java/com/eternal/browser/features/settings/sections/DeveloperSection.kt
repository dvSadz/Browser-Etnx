package com.eternal.browser.features.settings.sections

import com.eternal.browser.features.settings.SettingItem
import com.eternal.browser.features.settings.SettingSection

import com.eternal.browser.core.storage.PrefsKeys
import com.eternal.browser.core.storage.Prefs
object DeveloperSection {
    fun build(prefs: Prefs) = SettingSection("DESENVOLVEDOR", listOf(
        SettingItem.Toggle(PrefsKeys.REMOTE_DEBUG, "Depuração remota por USB", "Inspeção pelo Firefox em um computador", false, restart = true),
        SettingItem.Toggle(PrefsKeys.CONSOLE_OUTPUT, "Console das páginas no logcat", "Pode gerar muitos registros", false, restart = true),
        SettingItem.Toggle(PrefsKeys.ABOUT_CONFIG, "Habilitar about:config", "Opção avançada; alterações incorretas podem afetar o navegador", false, restart = true),
    ))
}
