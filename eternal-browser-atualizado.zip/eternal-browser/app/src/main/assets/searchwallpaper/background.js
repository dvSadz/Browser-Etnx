// Ponte entre o app (Kotlin) e os content scripts.
// O app envia { enabled, dim, dataUrl } pela porta nativa "eternal". O wallpaper (data URL, pode passar de
// 500 KB) fica só na memória daqui; as páginas de busca o pedem por mensagem. Quando o app manda uma
// configuração nova, "ver" muda em storage.local e as páginas abertas pedem de novo.
let state = { enabled: false, dim: 40, dataUrl: "" };
let port = null;

function connect() {
  try {
    port = browser.runtime.connectNative("eternal");
    port.onMessage.addListener((msg) => {
      if (msg && typeof msg === "object") state = msg;
      browser.storage.local.set({ ver: Date.now() });
    });
    port.onDisconnect.addListener(() => {
      port = null;
      setTimeout(connect, 1500);
    });
  } catch (e) {
    port = null;
    setTimeout(connect, 1500);
  }
}

browser.runtime.onMessage.addListener((m) => {
  if (m && m.type === "get") return Promise.resolve(state);
  return undefined;
});

connect();
