// Wallpaper nas páginas de resultados de busca.
//
// Override GENÉRICO: nenhuma cor ou classe do Google (ou de outro buscador) é usada. O fundo de html/body
// é trocado pelo wallpaper e QUALQUER elemento grande com fundo sólido vira transparente (ícones, botões,
// campos e imagens pequenos ficam como estão). Tudo é reversível: a folha de estilo e o atributo
// data-eternal-wp são removidos ao desligar ou ao sair de uma página de busca.
(() => {
 try {
  if (window.top !== window) return;

  const STYLE_ID = "eternal-search-wallpaper";
  const ATTR = "data-eternal-wp";
  const SKIP = new Set(["HTML", "BODY", "INPUT", "TEXTAREA", "BUTTON", "SELECT", "IMG", "PICTURE",
                        "VIDEO", "CANVAS", "SVG", "IFRAME", "HEAD", "STYLE", "SCRIPT"]);

  // Hosts de buscadores (o Google tem um domínio por país: google.com, google.com.br…).
  const ENGINE_HOST = /(^|\.)(google\.[a-z.]+|bing\.com|duckduckgo\.com|search\.brave\.com|ecosia\.org|startpage\.com|qwant\.com)$/;

  function isSearchEngineUrl(href) {
    let u;
    try { u = new URL(href); } catch (e) { return false; }
    const h = u.hostname.toLowerCase();
    const p = u.pathname;
    if (/(^|\.)google\.[a-z.]+$/.test(h)) return p.startsWith("/search");
    if (/(^|\.)bing\.com$/.test(h)) return p.startsWith("/search");
    if (/(^|\.)duckduckgo\.com$/.test(h)) return u.searchParams.has("q");
    if (/(^|\.)search\.brave\.com$/.test(h)) return p.startsWith("/search");
    if (/(^|\.)ecosia\.org$/.test(h)) return p.startsWith("/search");
    if (/(^|\.)startpage\.com$/.test(h)) return p.startsWith("/sp");
    if (/(^|\.)qwant\.com$/.test(h)) return u.searchParams.has("q");
    return false;
  }

  // Páginas que não são de buscadores nunca pagam o custo de nada disto.
  if (!ENGINE_HOST.test(location.hostname.toLowerCase())) return;

  let cfg = null;          // { enabled, dim, dataUrl } vindo do app (null = ainda não pedido)
  let requesting = false;
  let active = false;
  let pageIsLight = null;  // medido ANTES de limpar os fundos
  let lastHref = location.href;
  let observer = null;
  let debounce = null;
  const pending = new Set();

  function luminance(rgb) {
    const m = rgb.match(/rgba?\(([^)]+)\)/);
    if (!m) return null;
    const [r, g, b, a = 1] = m[1].split(",").map((v) => parseFloat(v));
    if (a < 0.5) return null;
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  }

  // Tema da página pela COR DO TEXTO (corpo + primeiros links), que não depende do fundo: o script roda cedo,
  // antes do CSS do site, e depois que o fundo vira transparente ele não é mais medível.
  // Texto escuro = página clara. Sem texto medível, vale o prefers-color-scheme.
  function measureLight() {
    const samples = [];
    if (document.body) samples.push(document.body);
    document.querySelectorAll("a").forEach((el, i) => { if (i < 5) samples.push(el); });
    let sum = 0, n = 0;
    for (const el of samples) {
      const l = luminance(getComputedStyle(el).color);
      if (l !== null) { sum += l; n++; }
    }
    if (n > 0) return sum / n < 0.5;
    return !(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
  }

  // Remede (o site termina de carregar o CSS depois) e redesenha o véu se o tema da página mudou.
  function refreshTheme() {
    if (!active) return;
    const light = measureLight();
    if (light === pageIsLight) return;
    pageIsLight = light;
    const st = document.getElementById(STYLE_ID);
    if (st && cfg && cfg.dataUrl) st.textContent = css();
  }

  // Overlay: escuro nas páginas escuras. Em páginas claras (texto escuro) um véu escuro deixaria o texto
  // ilegível, então o véu é claro: assim os resultados continuam legíveis em qualquer tema.
  function overlayColor(dim) {
    const d = Math.max(0, Math.min(80, Number(dim) || 0)) / 100;
    return pageIsLight ? `rgba(255,255,255,${(0.55 + d * 0.3).toFixed(2)})` : `rgba(0,0,0,${d})`;
  }

  function css() {
    return `
      html {
        background-image: url("${cfg.dataUrl}") !important;
        background-size: cover !important;
        background-position: center !important;
        background-attachment: fixed !important;
        background-repeat: no-repeat !important;
        background-color: transparent !important;
      }
      body { background: transparent !important; }
      html::before {
        content: ""; position: fixed; inset: 0; pointer-events: none; z-index: -1;
        background: ${overlayColor(cfg.dim)};
      }
      [${ATTR}] { background-color: transparent !important; background-image: none !important; }
    `;
  }

  function considerElement(el) {
    if (el.nodeType !== 1 || el.hasAttribute(ATTR) || SKIP.has(el.tagName.toUpperCase())) return;
    const bg = getComputedStyle(el).backgroundColor;
    if (!bg || bg === "transparent" || /^rgba\(\s*0,\s*0,\s*0,\s*0\s*\)$/.test(bg)) return;
    const r = el.getBoundingClientRect();
    if (r.width > 200 && r.height > 100) el.setAttribute(ATTR, "1"); // fundo grande: some
  }

  // Varre em lotes para não travar a página.
  function clearBackgrounds(root) {
    const list = [root, ...root.querySelectorAll("*")];
    let i = 0;
    (function chunk() {
      if (!active) return;
      const end = Math.min(i + 400, list.length);
      for (; i < end; i++) { try { considerElement(list[i]); } catch (e) { /* segue */ } }
      if (i < list.length) setTimeout(chunk, 0);
    })();
  }

  function flushPending() {
    debounce = null;
    if (!active) { pending.clear(); return; }
    const nodes = Array.from(pending);
    pending.clear();
    for (const n of nodes) { if (n.isConnected) clearBackgrounds(n); }
  }

  function onMutations(muts) {
    if (location.href !== lastHref) { lastHref = location.href; evaluate(); }
    if (!active) return;
    for (const m of muts) m.addedNodes.forEach((n) => { if (n.nodeType === 1) pending.add(n); });
    if (pending.size && !debounce) debounce = setTimeout(flushPending, 150);
  }

  function startObserver() {
    if (observer) return;
    observer = new MutationObserver(onMutations);
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function apply() {
    if (pageIsLight === null) pageIsLight = measureLight();
    let st = document.getElementById(STYLE_ID);
    if (!st) {
      st = document.createElement("style");
      st.id = STYLE_ID;
      (document.head || document.documentElement).appendChild(st);
    }
    st.textContent = css();
    const first = !active;
    active = true;
    if (first || document.readyState !== "loading") clearBackgrounds(document.documentElement);
    // O buscador injeta elementos depois do carregamento: repete a limpeza (e remede o tema).
    setTimeout(() => { if (active) { refreshTheme(); clearBackgrounds(document.documentElement); } }, 500);
    setTimeout(() => { if (active) { refreshTheme(); clearBackgrounds(document.documentElement); } }, 1500);
  }

  function remove() {
    active = false;
    pageIsLight = null;
    pending.clear();
    const st = document.getElementById(STYLE_ID);
    if (st) st.remove();
    document.querySelectorAll(`[${ATTR}]`).forEach((el) => el.removeAttribute(ATTR));
  }

  function request() {
    if (requesting) return;
    requesting = true;
    browser.runtime.sendMessage({ type: "get" })
      .then((r) => { cfg = r || { enabled: false }; })
      .catch(() => { cfg = { enabled: false }; })
      .then(() => { requesting = false; evaluate(); });
  }

  function evaluate() {
    if (!isSearchEngineUrl(location.href)) { remove(); return; }
    if (cfg === null) { request(); return; }
    if (!cfg.enabled || !cfg.dataUrl) { remove(); return; }
    apply();
  }

  // O app mudou a configuração (wallpaper, escurecimento ou ligado/desligado): pede de novo.
  browser.storage.onChanged.addListener((changes) => {
    if (changes.ver) { cfg = null; evaluate(); }
  });

  startObserver();
  window.addEventListener("popstate", () => { lastHref = location.href; evaluate(); });
  document.addEventListener("DOMContentLoaded", () => { if (active) { refreshTheme(); clearBackgrounds(document.documentElement); } }, { once: true });
  window.addEventListener("load", () => { if (active) { refreshTheme(); clearBackgrounds(document.documentElement); } }, { once: true });
  evaluate();
 } catch (e) { /* nunca quebrar a página */ }
})();
