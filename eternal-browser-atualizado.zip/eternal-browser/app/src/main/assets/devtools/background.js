// Ponte das ferramentas de desenvolvedor: envia ao app (porta nativa "eternaldev") cada requisição
// http(s) concluída e atende pedidos de cookies. Tudo em try/catch: nunca pode derrubar o navegador.
const starts = {};
let port = null;

function send(m) { try { if (port) port.postMessage(m); } catch (e) {} }

function connect() {
  try {
    port = browser.runtime.connectNative("eternaldev");
    port.onMessage.addListener(onCmd);
    port.onDisconnect.addListener(() => { port = null; setTimeout(connect, 1500); });
  } catch (e) { port = null; setTimeout(connect, 1500); }
}

function onCmd(m) {
  try {
    if (m.cmd === "cookies") {
      browser.cookies.getAll({ url: m.url }).then(
        (l) => send({ k: "cookies", list: l.map((c) => ({ n: c.name, v: c.value, d: c.domain, p: c.path, s: !!c.secure, h: !!c.httpOnly, e: c.expirationDate || 0 })) }),
        (e) => send({ k: "cookies", list: [], err: String(e) })
      );
    } else if (m.cmd === "rmcookie") {
      browser.cookies.remove({ url: m.url, name: m.name }).then(() => send({ k: "removed", n: m.name }), () => {});
    }
  } catch (e) { send({ k: "cookies", list: [], err: String(e) }); }
}

function size(h) {
  try {
    for (const x of h || []) if (x.name.toLowerCase() === "content-length") return parseInt(x.value, 10) || 0;
  } catch (e) {}
  return 0;
}

const filter = { urls: ["http://*/*", "https://*/*"] };

browser.webRequest.onBeforeRequest.addListener((d) => {
  starts[d.requestId] = Date.now();
  if (d.type === "main_frame") send({ k: "nav", u: d.url });
}, filter);

browser.webRequest.onCompleted.addListener((d) => {
  const t0 = starts[d.requestId] || Date.now();
  delete starts[d.requestId];
  send({
    k: "req", m: d.method, u: d.url, s: d.statusCode, ty: d.type, ms: Date.now() - t0, sz: size(d.responseHeaders),
    h: (d.responseHeaders || []).slice(0, 40).map((x) => [x.name, String(x.value || "").slice(0, 300)]),
  });
}, filter, ["responseHeaders"]);

browser.webRequest.onErrorOccurred.addListener((d) => {
  const t0 = starts[d.requestId] || Date.now();
  delete starts[d.requestId];
  send({ k: "req", m: d.method, u: d.url, s: 0, ty: d.type, ms: Date.now() - t0, sz: 0, h: [], err: d.error });
}, filter);

connect();
