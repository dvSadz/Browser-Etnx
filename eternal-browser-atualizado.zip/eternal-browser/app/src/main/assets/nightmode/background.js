// Ponte entre o app (Kotlin) e os content scripts.
// O app envia { enabled, brightness, contrast } pela porta nativa "eternal";
// guardamos em storage.local e cada página reage via storage.onChanged.
let port = null;

function connect() {
  try {
    port = browser.runtime.connectNative("eternal");
    port.onMessage.addListener((cfg) => browser.storage.local.set({ cfg }));
    port.onDisconnect.addListener(() => {
      port = null;
      setTimeout(connect, 1500);
    });
  } catch (e) {
    port = null;
    setTimeout(connect, 1500);
  }
}

connect();
