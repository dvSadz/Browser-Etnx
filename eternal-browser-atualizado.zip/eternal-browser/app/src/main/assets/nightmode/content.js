// Modo noturno inteligente:
//  - inverte páginas claras (invert + hue-rotate mantém as cores reconhecíveis);
//  - reinverte imagens, vídeos e canvas para não ficarem em negativo;
//  - NÃO mexe em páginas que já são escuras;
//  - brilho e contraste ajustáveis.
(() => {
 try {
  const STYLE_ID = "eternal-night-style";
  let cfg = { enabled: false, brightness: 100, contrast: 100 };
  let pageIsDark = false;

  function css(c) {
    const b = c.brightness / 100;
    const k = c.contrast / 100;
    return `
      html { filter: invert(1) hue-rotate(180deg) brightness(${b}) contrast(${k}) !important; background: #fff !important; }
      img, picture, video, canvas, svg image, embed, object,
      [style*="background-image"] { filter: invert(1) hue-rotate(180deg) !important; }
    `;
  }

  function luminance(rgbString) {
    const m = rgbString.match(/rgba?\(([^)]+)\)/);
    if (!m) return null;
    const [r, g, b, a = 1] = m[1].split(",").map((v) => parseFloat(v));
    if (a < 0.5) return null; // transparente
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  }

  function detectDark() {
    const els = [document.body, document.documentElement];
    for (const el of els) {
      if (!el) continue;
      const l = luminance(getComputedStyle(el).backgroundColor);
      if (l !== null) {
        pageIsDark = l < 0.4;
        return;
      }
    }
    pageIsDark = false; // sem fundo definido = branco
  }

  function render() {
    let el = document.getElementById(STYLE_ID);
    if (!cfg.enabled || pageIsDark) {
      if (el) el.remove();
      return;
    }
    if (!el) {
      el = document.createElement("style");
      el.id = STYLE_ID;
      (document.head || document.documentElement).appendChild(el);
    }
    el.textContent = css(cfg);
  }

  browser.storage.local.get("cfg").then((r) => {
    if (r.cfg) cfg = r.cfg;
    render();
  });

  browser.storage.onChanged.addListener((changes) => {
    if (changes.cfg && changes.cfg.newValue) {
      cfg = changes.cfg.newValue;
      detectDark();
      render();
    }
  });

  const onReady = () => { detectDark(); render(); };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", onReady, { once: true });
  } else {
    onReady();
  }
 } catch (e) { /* nunca quebrar a página */ }
})();
