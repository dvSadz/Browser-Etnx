# Patches de extensões — instruções de integração

## Importante

Não aplique substituições globais automáticas de `BUILDFLAG(ENABLE_EXTENSIONS)` por
`BUILDFLAG(ENABLE_EXTENSIONS_CORE)`. Esses flags não são intercambiáveis em todos os
contextos: alguns componentes e recursos são exclusivos de desktop. Faça alterações
por arquivo, confira os includes gerados e compile/teste cada patch.

A revisão Chromium e os patches existentes no fork determinam quais hunks se aplicam.
O repositório Kiwi Next é um repositório de controle de mudanças e não necessariamente
contém a árvore Chromium compilável inteira.

## Procedimento recomendado

1. Prepare o checkout Chromium na revisão compatível com o Kiwi Next.
2. Aplique primeiro os patches oficiais/atuais do fork e confirme que a compilação base funciona.
3. Confira `extensions/buildflags/buildflags.gni`, `chrome/browser/ui/webui/chrome_web_ui_configs.cc`
   e os arquivos Android de WebUI/Extensions na revisão usada.
4. Aplique mudanças mínimas para que o código necessário a extensões seja compilado no Android.
5. Compile e teste cada recurso isoladamente. Não remova asserts sem provar que as dependências
   requeridas estão habilitadas.
6. Teste permissões, ciclo de vida, service workers, armazenamento, instalação/atualização e
   segurança antes de distribuir.

## Matriz de validação

- MV3: instalação, permissões, service worker, suspensão/retomada e atualização.
- MV2: verifique a política e o suporte real da revisão Chromium; uma flag não restaura APIs
  removidas upstream.
- Chrome Web Store: fluxo de instalação, compatibilidade de user-agent e tratamento de avisos.
- CRX/ZIP: validação de assinatura, origem e instalação; ZIP não é equivalente a CRX assinado.
- Unpacked: seletor de arquivos Android, permissões e persistência após reinício.
- APIs tabs/windows/bookmarks: confira implementação, permissões e diferenças de plataforma.
- Opera/Edge Add-ons: não existe garantia de instalação direta; teste a compatibilidade e os
  fluxos de download separadamente.

## Por que não há um patch universal aqui?

Os caminhos e contextos variam entre revisões Chromium. Um patch inventado com hunks
genéricos pode não aplicar ou, pior, pode compilar parcialmente e enfraquecer as garantias
de segurança. Gere o diff contra a revisão concreta e registre a origem de cada alteração.
