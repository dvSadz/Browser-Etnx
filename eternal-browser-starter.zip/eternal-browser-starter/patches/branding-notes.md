# Branding Eternal Browser

Os caminhos abaixo são pontos de partida, não uma garantia de que todos existam na revisão:

- `chrome/android/java/res/values/strings.xml`: procure a string de nome da aplicação.
- `AndroidManifest.xml`: o package Android costuma ser definido em `build.gradle`, GN,
  `manifest` gerado ou configuração de produto; não altere um `package` aleatório.
- `chrome/android/java/res/values/colors.xml` e `styles.xml`: os caminhos e nomes de recursos
  variam. Prefira adicionar recursos próprios e substituir referências de forma consistente.
- O applicationId `com.eternal.browser` deve ser atualizado em todas as configurações de build,
  manifestos, serviços, deep links, provedores e assinaturas pertinentes.

Paleta sugerida:
- Fundo: `#000000`
- Texto: `#FFFFFF`
- Acento cinza: `#CCCCCC`

Faça a alteração em uma branch isolada e compile antes de remover recursos existentes.
