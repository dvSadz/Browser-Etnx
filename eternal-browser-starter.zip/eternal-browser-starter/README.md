# Eternal Browser — starter de build Android

Base de automação para um fork do Kiwi Next, com branding preto e branco e scripts iniciais.

## Antes de executar

Este pacote é um **starter**, não um fork Chromium completo nem uma garantia de suporte total
a extensões. O repositório `kiwibrowser/src.next` documenta um fluxo de build próprio; para
reproduzir esse fluxo, adapte o workflow aos scripts e à revisão Chromium realmente usada pelo
seu fork.

### O que está incluído

- `.github/workflows/build-eternal.yml`: jobs `setup`, `build` e `release`, cache e artefato.
- `.github/scripts/setup-deps.sh`: dependências básicas e `depot_tools`.
- `.github/scripts/build-apk.sh`: geração GN e compilação com Ninja, com validação do checkout.
- `args.gn`: configuração inicial Android ARM.
- `patches/`: notas para integração segura de extensões e branding.
- `assets/eternal-icon.svg`: conceito monocromático de ícone.

## Como adaptar

1. Crie/prepare a branch `eternal` do fork.
2. Confirme a revisão Chromium e o processo de sincronização/patches do Kiwi Next.
3. Integre o conteúdo deste pacote à estrutura real do repositório.
4. Garanta que o build seja executado no diretório da árvore Chromium completa.
5. Faça primeiro um build de desenvolvimento (`is_official_build = false`).
6. Ajuste a localização dos APKs se a revisão gerar os artefatos em outro caminho.
7. Teste instalação, atualização, assinatura, WebUI e extensões antes de publicar.

## GitHub Actions e espaço em disco

Chromium pode exceder o espaço livre de runners hospedados. O workflow mostra o espaço disponível,
mas não apaga SDKs automaticamente. Remover `/usr/local/lib/android` ou `/usr/share/dotnet`
pode quebrar dependências e só deve ser feito depois de confirmar que o build não usa esses pacotes.

Para compilações completas, prefira um runner `self-hosted` com armazenamento SSD amplo, RAM
suficiente e espaço de swap. O cache de `out/` pode acelerar builds subsequentes, mas é grande,
pode ser invalidado por mudanças de toolchain e não substitui um checkout consistente.

## Extensões

Não assuma que `enable_extensions`, `enable_extensions_core`, `enable_desktop_android_extensions`
e `enable_extension_manifests_v3` existem simultaneamente ou possuem a semântica indicada em toda
revisão. Confirme com `gn args out/android_arm --list` e com os `.gni` da revisão.

O suporte MV2/MV3, loja, CRX, ZIP, unpacked e APIs `tabs/windows/bookmarks` exige alterações
de plataforma e testes específicos. Consulte `patches/README.md`; não use substituições globais
de buildflags nem remova asserts indiscriminadamente.

## Segurança e publicação

- Não publique chaves de assinatura no repositório ou nos logs.
- Use GitHub Secrets ou um sistema de assinatura separado.
- A release criada é draft/prerelease e deve ser testada antes de distribuir.
- Respeite as licenças do Chromium/Kiwi e mantenha avisos de terceiros exigidos.
