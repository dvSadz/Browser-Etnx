#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel)"
cd "${ROOT}"

export PATH="${HOME}/depot_tools:${PATH}"
export DEPOT_TOOLS_UPDATE=0
export GYP_CHROMIUM_NO_ACTION=1
export CCACHE_DIR="${HOME}/.ccache"
mkdir -p "${CCACHE_DIR}"

# Chromium normalmente exige uma árvore de código completa, preparada por
# fetch/gclient. O repositório src.next é um repositório de controle/patches;
# não presuma que sua raiz já seja o checkout Chromium compilável.
if [[ ! -f "build/config/BUILDCONFIG.gn" || ! -d "chrome" ]]; then
  echo "::error::A raiz atual não parece ser um checkout Chromium completo."
  echo "Prepare o checkout Chromium compatível com Kiwi Next e aplique os patches"
  echo "antes de executar este script. Veja README.md."
  exit 2
fi

if [[ ! -f "args.gn" ]]; then
  echo "::error::args.gn não encontrado na raiz."
  exit 2
fi

mkdir -p out/android_arm
cp args.gn out/android_arm/args.gn

# Ajuda a reduzir recompilações C/C++; não substitui o cache do diretório out.
if command -v ccache >/dev/null 2>&1; then
  ccache --max-size=8G
  export CC="ccache clang"
  export CXX="ccache clang++"
fi

gn gen out/android_arm
ninja -C out/android_arm chrome_public_apk

echo "Build finalizado. Procure o APK em out/android_arm/apks/."
