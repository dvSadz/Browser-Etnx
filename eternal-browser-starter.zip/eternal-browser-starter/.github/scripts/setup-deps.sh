#!/usr/bin/env bash
set -euo pipefail

# Instala ferramentas básicas. A versão do JDK/Android SDK exigida depende
# da revisão Chromium exata; confirme os requisitos da base antes do build.
sudo apt-get update
sudo apt-get install -y --no-install-recommends \
  ca-certificates curl git python3 python3-venv python3-pip \
  openjdk-11-jdk nodejs npm ccache ninja-build pkg-config \
  build-essential unzip zip xz-utils

# depot_tools é a ferramenta oficial de checkout/build do Chromium.
# Para compilar um checkout completo, use o depot_tools correspondente à
# revisão e ao processo de checkout da sua árvore Chromium.
if [[ ! -d "${HOME}/depot_tools" ]]; then
  git clone https://chromium.googlesource.com/chromium/tools/depot_tools.git \
    "${HOME}/depot_tools"
fi

export PATH="${HOME}/depot_tools:${PATH}"
export DEPOT_TOOLS_UPDATE=0
export GYP_CHROMIUM_NO_ACTION=1

echo 'Dependências básicas instaladas.'
echo 'ATENÇÃO: este script não baixa nem prepara sozinho toda a árvore Chromium, SDK e NDK.'
